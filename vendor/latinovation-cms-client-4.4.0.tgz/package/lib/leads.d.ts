import { type TrackingContext } from './tracking/core.js';
export interface LeadInput {
    slug: string;
    apiUrl?: string;
    fetch?: typeof fetch;
    /** Id del formulario `form.custom` publicado (p. ej. `cotizacion`). */
    formId?: string;
    /** Nombre legible del formulario (por defecto el formId o «Contacto General»). */
    formName?: string;
    /** Respuestas por clave de campo del formulario. */
    payload?: Record<string, unknown>;
    fullName?: string;
    email?: string;
    phone?: string;
    message?: string;
    /** Ruta y sección de origen (para el portal). Por defecto la ruta actual. */
    sourcePage?: string;
    sourceSection?: string;
    /** Datos extra (UTM, producto…). */
    metadata?: Record<string, unknown>;
    /** Trampa para bots: déjalo vacío (input oculto). */
    website?: string;
    /** false: no emite `generate_lead` ni adjunta el contexto de medición. */
    tracking?: boolean | TrackingContext;
}
export interface LeadResult {
    received: boolean;
    leadId: string | null;
    createdAt: string;
    /** event_id del `generate_lead` (deduplicación con Meta). */
    eventId?: string;
    [k: string]: unknown;
}
export declare class LeadError extends Error {
    status: number;
    constructor(message: string, status: number);
}
export declare function submitLead(input: LeadInput): Promise<LeadResult>;
