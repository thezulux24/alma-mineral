import type { ComposerColumn, ComposerData, ComposerElement, ComposerElementDef, ComposerElementType, ComposerFieldDef, ComposerRow, ComposerSpan } from './types.js';
/** Id corto y estable (`r_ab12cd`, `c_…`, `e_…`). */
export declare function composerId(prefix: 'r' | 'c' | 'e'): string;
export declare const COMPOSER_ICONS: Array<[string, string]>;
export declare const ELEMENT_DEFS: Record<ComposerElementType, ComposerElementDef>;
export declare const ELEMENT_TYPES: ComposerElementType[];
export declare const ELEMENT_GROUPS: Array<{
    id: ComposerElementDef['group'];
    label: string;
}>;
export declare function isElementType(t: unknown): t is ComposerElementType;
/** Campos de estilo comunes a todos los elementos. */
export declare const ELEMENT_STYLE_FIELDS: ComposerFieldDef[];
export declare const COLUMN_STYLE_FIELDS: ComposerFieldDef[];
export declare const ROW_STYLE_FIELDS: ComposerFieldDef[];
export declare function createElement(type: ComposerElementType, props?: Record<string, any>): ComposerElement;
export declare function clampSpan(n: unknown, fallback?: number): number;
export declare function normalizeSpan(span: unknown, fallback?: number): ComposerSpan;
export declare function createColumn(span?: number | ComposerSpan, elements?: ComposerElement[]): ComposerColumn;
/** `createRow([6, 6])` → dos columnas a la mitad (en celular, una debajo de otra). */
export declare function createRow(spans?: number[], columns?: ComposerColumn[]): ComposerRow;
/** Plantillas de fila del botón «Añadir fila». */
export declare const ROW_LAYOUTS: Array<{
    id: string;
    label: string;
    spans: number[];
}>;
/** Copia profunda con ids nuevos (duplicar, pegar, insertar diseños). */
export declare function withFreshIds<T>(node: T): T;
/**
 * Datos seguros para renderizar: ids presentes, spans 1–12, props por defecto del tipo.
 * No muta la entrada. Los elementos de tipo desconocido se conservan (el renderer los omite).
 * Los ids que faltan se derivan de la posición (`e_x0_1_2`) para que sean estables entre renders.
 */
export declare function normalizeComposer(input: unknown): ComposerData;
export interface ComposerIssue {
    path: string;
    level: 'error' | 'warning';
    message: string;
}
/** Revisa estructura, spans, ids duplicados, enlaces y accesibilidad (alt, niveles de título). */
export declare function validateComposer(input: unknown): {
    ok: boolean;
    issues: ComposerIssue[];
};
/** Cuenta filas, columnas y elementos (resúmenes en el inspector y en agentes). */
export declare function composerStats(input: unknown): {
    rows: number;
    columns: number;
    elements: number;
};
/** Texto corto que identifica un elemento (árbol de estructura). */
export declare function elementSummary(el: ComposerElement | undefined | null): string;
