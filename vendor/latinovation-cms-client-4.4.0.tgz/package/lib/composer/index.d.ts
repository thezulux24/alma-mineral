/**
 * Compositor libre (`layout.composer`): núcleo puro + renderer React.
 *
 *   import { Composer } from '@latinovation/cms-client/composer';
 *   <Composer data={section.data} sectionKey={section.key} sectionId={section.id} host={{ projectSlug }} />
 *
 * Con <CmsProvider>, usa `CmsComposer` de '@latinovation/cms-client/composer/react'.
 */
export * from './core.js';
export * from './render.js';
export { ComposerIcon, COMPOSER_ICON_NAMES, hasComposerIcon } from './icons.js';
export { COMPOSER_CSS } from './css.js';
