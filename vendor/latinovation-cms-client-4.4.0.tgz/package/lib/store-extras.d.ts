import type { CollectionItem } from './types.js';
export interface ReviewSummary {
    average: number;
    count: number;
    distribution: Record<'1' | '2' | '3' | '4' | '5', number>;
}
export interface PublicReview {
    id: string;
    productId: string;
    name: string;
    rating: number;
    title: string;
    body: string;
    photos: Array<{
        url: string;
        alt: string;
    }>;
    verifiedPurchase: boolean;
    /** Respuesta pública de la tienda ('' si no hay). */
    reply: string;
    repliedAt?: string | null;
    createdAt: string;
    product?: {
        id: string;
        title: string;
        slug: string;
    } | null;
}
export interface ReviewsPage {
    enabled: boolean;
    product?: {
        id: string;
        slug: string;
        title: string;
    } | null;
    items: PublicReview[];
    total: number;
    page: number;
    totalPages: number;
    summary: ReviewSummary;
}
export interface ReviewInput {
    /** Id o slug del producto (no hace falta con `token`). */
    productId?: string;
    rating: number;
    body: string;
    title?: string;
    name: string;
    /** Obligatorio sin `token` ni cuenta de cliente; nunca se publica. */
    email?: string;
    /** Ids devueltos por `reviews.uploadPhoto`. */
    photos?: string[];
    /** Enlace firmado del correo de solicitud (`?resena=`): marca la reseña como compra verificada. */
    token?: string;
    /** Trampa para bots: déjalo vacío (input oculto). */
    website?: string;
}
export interface ReviewSubmitResult {
    received: boolean;
    id?: string;
    status: 'PENDING' | 'APPROVED' | 'REJECTED';
    verifiedPurchase?: boolean;
    message: string;
}
export interface DigitalDownload {
    id: string;
    orderId: string;
    productId: string;
    title: string;
    downloads: number;
    maxDownloads: number;
    expiresAt: string;
    active: boolean;
    /** Enlace firmado nuevo (vence según la tienda); null si se agotaron las descargas o venció el acceso. */
    url: string | null;
}
export interface StoreExtrasStorage {
    getItem(key: string): string | null;
    setItem(key: string, value: string): void;
}
export interface StoreExtrasOptions {
    slug: string;
    /** URL del CMS (por defecto https://webproai.tech). */
    apiUrl?: string;
    fetch?: typeof fetch;
    /** Token del cliente de la tienda (createShopClient().getToken) para favoritos y descargas. */
    getToken?: () => string | null;
    /** Dónde guardar favoritos sin cuenta y vistos recientemente (por defecto localStorage o memoria). */
    storage?: StoreExtrasStorage | null;
}
export declare class StoreExtrasError extends Error {
    status: number;
    code: string;
    constructor(message: string, status: number, code: string);
}
/** Claves de almacenamiento (las mismas del renderer de /site, para compartir favoritos). */
export declare const wishlistStorageKey: (slug: string) => string;
export declare const recentlyViewedStorageKey: (slug: string) => string;
export declare function createStoreExtrasClient(opts: StoreExtrasOptions): {
    slug: string;
    apiUrl: string;
    reviews: {
        /** Reseñas aprobadas de un producto (id o slug) o, sin producto, de toda la tienda. */
        list: (product?: string | null, q?: {
            page?: number;
            limit?: number;
            sort?: "highest" | "lowest" | "photos";
            rating?: number;
        }) => Promise<ReviewsPage>;
        /** Promedio y conteo de varios productos (tarjetas): `{ [idOSlug]: { average, count } }`. */
        summaries: (products: string[]) => Promise<Record<string, {
            average: number;
            count: number;
        }>>;
        submit: (input: ReviewInput) => Promise<ReviewSubmitResult>;
        uploadPhoto: (file: Blob, fileName?: string) => Promise<{
            id: string;
            url: string;
        }>;
        /** Datos del enlace del correo (`?resena=<token>`): producto y nombre para prellenar. */
        invite: (token: string) => Promise<{
            product: {
                id: string;
                slug: string;
                title: string;
                imageUrl: string;
            };
            name: string;
            alreadyReviewed: boolean;
        }>;
    };
    backInStock: {
        subscribe: (input: {
            productId: string;
            email: string;
            variant?: string;
            name?: string;
            website?: string;
        }) => Promise<{
            subscribed: boolean;
            message?: string;
        }>;
    };
    wishlist: {
        /** Favoritos guardados en este navegador. */
        local: () => string[];
        setLocal: (ids: string[]) => void;
        /** Agrega o quita en este navegador; devuelve si quedó guardado. */
        toggleLocal(id: string): boolean;
        list: () => Promise<{
            productIds: string[];
            items: Array<{
                productId: string;
                addedAt: string;
            }>;
        }>;
        add: (productId: string) => Promise<{
            productIds: string[];
        }>;
        remove: (productId: string) => Promise<{
            productIds: string[];
        }>;
        /** Sube los favoritos del navegador a la cuenta (al iniciar sesión). */
        merge: (productIds: string[]) => Promise<{
            productIds: string[];
        }>;
    };
    downloads: {
        /** Descargas de la cuenta del cliente (enlaces firmados nuevos en cada llamada). */
        mine: () => Promise<{
            items: DigitalDownload[];
        }>;
        /** Descargas de un pedido de invitado (número de pedido + correo de la compra). */
        forOrder: (orderNumber: string, email: string) => Promise<{
            items: DigitalDownload[];
            pendingPayment?: boolean;
        }>;
    };
    recentlyViewed: {
        list: () => string[];
        /** Guarda el producto al frente (máx. `max`, 12 por defecto). */
        add(id: string, max?: number): string[];
        clear: () => void;
    };
};
export type StoreExtrasClient = ReturnType<typeof createStoreExtrasClient>;
/**
 * Productos relacionados: primero los elegidos en el campo de relación del producto (`related`,
 * `relatedProducts` o `crossSell`: ids o slugs), luego los de la misma categoría y, solo si no hay
 * relación manual, el resto. Misma regla que el bloque `products.related`.
 */
export declare function relatedProducts<T extends Partial<CollectionItem> & Record<string, any>>(item: T | null | undefined, list: T[], count?: number): T[];
/** URLs de los catálogos de un sitio (`https://tienda.com` → /feeds/meta.xml y /feeds/google.xml). */
export declare function feedUrls(siteUrl: string): {
    meta: string;
    google: string;
};
/**
 * URLs de los catálogos servidos por el CMS (`GET /api/v1/feeds/:slug/meta.xml|google.xml`). Útil
 * para un storefront headless en otro dominio; `base` (un dominio del sitio) fija los enlaces.
 */
export declare function apiFeedUrls(slug: string, opts?: {
    apiUrl?: string;
    base?: string;
}): {
    meta: string;
    google: string;
};
/**
 * Enlace del correo de solicitud de reseña: `<producto>?resena=<token>&estrellas=N#resenas`.
 * Devuelve el token y las estrellas elegidas (1-5) para abrir el formulario prellenado.
 */
export declare function readReviewInvite(search?: string): {
    token: string;
    stars: number;
} | null;
/** Calificación que el delivery entrega con cada producto (ratingAverage / ratingCount). */
export declare function productRating(item: Record<string, any> | null | undefined): {
    average: number;
    count: number;
};
