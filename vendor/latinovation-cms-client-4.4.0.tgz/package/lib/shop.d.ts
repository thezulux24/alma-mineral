import { type TrackingContext } from './tracking/core.js';
export interface ShopAddress {
    id: string;
    label?: string;
    recipientName?: string;
    phone?: string;
    address: string;
    city: string;
    department?: string;
    country?: string;
    postalCode?: string;
    notes?: string;
    isDefault?: boolean;
}
/** Dirección para crear o editar (el backend asigna `id`). */
export type ShopAddressInput = Omit<ShopAddress, 'id'> & {
    id?: string;
};
export interface ShopCustomer {
    id: string;
    email: string;
    name: string;
    phone?: string | null;
    documentType?: string | null;
    documentId?: string | null;
    addresses: ShopAddress[];
    acceptsMarketing: boolean;
    createdAt: string;
}
export type ShopOrderStatus = 'PENDING' | 'PENDING_PAYMENT' | 'PENDING_WHATSAPP' | 'PAYMENT_FAILED' | 'PROCESSING' | 'PAID_PROCESSING' | 'IN_PRODUCTION' | 'SHIPPED' | 'IN_TRANSIT' | 'OUT_FOR_DELIVERY' | 'DELIVERED'
/** Novedad en la entrega (el envío está en EXCEPTION). */
 | 'SHIPPING_EXCEPTION'
/** Devuelto al remitente (el envío llegó RETURNED). */
 | 'RETURNED' | 'CANCELLED' | 'REFUNDED' | (string & {});
/** Estado normalizado de un envío (docs/LOGISTICS.md §3), igual para Dropi, Interrapidísimo, webhook y manual. */
export type ShipmentStatus = 'DRAFT' | 'CREATED' | 'LABEL_CREATED' | 'PICKED_UP' | 'IN_TRANSIT' | 'OUT_FOR_DELIVERY' | 'DELIVERED' | 'EXCEPTION' | 'RETURNING' | 'RETURNED' | 'CANCELLED';
export declare const SHIPMENT_STATUSES: readonly ShipmentStatus[];
export type ShipmentProvider = 'manual' | 'dropi' | 'interrapidisimo' | 'webhook' | (string & {});
/** Evento de un envío (lo que reporta la transportadora o la tienda). */
export interface ShopShipmentEvent {
    timestamp: string;
    status: ShipmentStatus | (string & {});
    title: string;
    location?: string;
    description?: string;
}
/** Envío público de un pedido (rastreo): sin borradores ni anulados. */
export interface ShopShipment {
    /** Puede no venir en el rastreo público. */
    provider?: ShipmentProvider | null;
    carrier: string | null;
    trackingNumber: string | null;
    trackingUrl: string | null;
    status: ShipmentStatus;
    deliveredAt?: string | null;
    events: ShopShipmentEvent[];
}
type Locale = 'es' | 'en' | (string & {});
/** Etiqueta legible de un estado de envío (`es` por defecto; `en` disponible). Un estado desconocido se devuelve tal cual. */
export declare function shipmentStatusLabel(status: ShipmentStatus | (string & {}) | null | undefined, locale?: Locale): string;
/** Etiqueta legible de un estado de pedido (`es` por defecto). */
export declare function orderStatusLabel(status: ShopOrderStatus | null | undefined, locale?: Locale): string;
/** true si el envío ya no cambia (entregado, devuelto o anulado). */
export declare function isShipmentFinal(status: ShipmentStatus | (string & {}) | null | undefined): boolean;
export type ShopPaymentStatus = 'PENDING' | 'PAID' | 'FAILED' | 'REFUNDED' | (string & {});
export interface ShopOrderLine {
    /** Id de la línea del pedido (para `account.returns.request({ items: [{ lineId, quantity }] })`). */
    lineId?: string | null;
    productId?: string | null;
    productSlug?: string | null;
    sku?: string | null;
    title: string;
    quantity: number;
    unitPrice?: number;
    imageUrl?: string | null;
    variantLabel?: string | null;
    [k: string]: unknown;
}
export interface ShopOrderSummary {
    orderNumber: string;
    status: ShopOrderStatus;
    paymentStatus: ShopPaymentStatus;
    totalAmount: number;
    currency: string;
    createdAt: string;
    itemsCount: number;
    items: ShopOrderLine[];
    carrierName?: string | null;
    trackingNumber?: string | null;
    trackingUrl?: string | null;
    /** true si el pago está pendiente o fue rechazado y se puede reintentar. */
    canRetry: boolean;
}
export interface ShopTrackingEvent {
    id?: string;
    status: string;
    title?: string;
    description?: string;
    location?: string;
    timestamp?: string;
}
export interface ShopOrder extends ShopOrderSummary {
    trackingEvents: ShopTrackingEvent[];
    shippingAddress?: Partial<ShopAddress> & Record<string, unknown>;
    subtotal?: number;
    shippingCost?: number;
    /** v5 precios: impuestos del pedido (incluidos o agregados). */
    taxAmount?: number;
    discountAmount?: number;
    giftCardAmount?: number;
    paymentMethod?: string | null;
    estimatedDelivery?: string | null;
    customerName?: string;
    customerEmail?: string;
    customerPhone?: string | null;
    updatedAt?: string;
    [k: string]: unknown;
}
export interface ShopPage<T> {
    items: T[];
    total: number;
    page: number;
    totalPages: number;
}
export interface ShopCustomerAccountsConfig {
    enabled: boolean;
    allowGuestCheckout: boolean;
    privacyPolicyUrl?: string | null;
}
/** Método de pago tal como lo publica `GET …/config` (sin secretos). */
export interface ShopPublicPaymentMethod {
    /** Activo Y con llaves (y, en BNPL, del país y la moneda de la tienda): el checkout nunca ofrece uno que fallaría. */
    enabled: boolean;
    label: string;
    /** gateway | bnpl | manual. */
    kind?: string;
    countries?: string[];
    sandbox?: boolean;
    checkout?: 'redirect' | (string & {});
    description?: string;
    logoUrl?: string;
    /** Texto de cuotas (BNPL: «Paga en 3 cuotas sin interés»). */
    installments?: string;
    /** BNPL: montos permitidos por la pasarela. */
    minAmount?: number;
    maxAmount?: number;
    publicKey?: string;
    publishableKey?: string;
    country?: string;
    bankDetails?: string;
    instructions?: string;
    [k: string]: unknown;
}
/** Ubicación de retiro en tienda (`storeExtras.checkout.pickup.locations`). */
export interface ShopPickupLocation {
    id: string;
    name: string;
    address: string;
    hours: string;
}
/** Franja horaria de entrega (`storeExtras.checkout.deliverySlots.windows`). */
export interface ShopDeliveryWindow {
    id: string;
    label: string;
}
/** Opciones del checkout que edita la tienda (docs/REVIEWS-AND-CHANNELS.md §6). */
export interface ShopCheckoutOptionsConfig {
    orderNotes: {
        enabled: boolean;
    };
    deliverySlots: {
        enabled: boolean;
        required: boolean;
        minDaysAhead?: number;
        maxDaysAhead?: number;
        closedWeekdays?: number[];
        windows: ShopDeliveryWindow[];
    };
    pickup: {
        enabled: boolean;
        locations: ShopPickupLocation[];
    };
}
/** Extras públicos de la tienda: reseñas, avisos, favoritos y opciones del checkout. */
export interface ShopStoreExtrasConfig {
    reviews: {
        enabled: boolean;
        allowPhotos: boolean;
        maxPhotos: number;
        minBodyLength: number;
    };
    backInStock: {
        enabled: boolean;
    };
    wishlist: {
        enabled: boolean;
    };
    checkout: ShopCheckoutOptionsConfig;
    /** Fechas (YYYY-MM-DD) que el checkout puede ofrecer para la franja de entrega. */
    deliveryDates: string[];
}
export interface ShopPublicConfig {
    enabled?: boolean;
    currency?: string;
    /** Tasa de impuesto por defecto (sin tarifas configuradas) y si los precios ya lo incluyen. */
    taxRatePercent?: number;
    taxIncludedInPrices?: boolean;
    /** Envío plano (tiendas sin zonas) y umbral de envío gratis. */
    freeShippingThreshold?: number;
    flatShippingRate?: number;
    defaultCarrier?: string;
    shippingZones?: Array<{
        id: string;
        name: string;
        rate: number;
        eta: string;
    }>;
    carriers?: unknown[];
    /** wompi, stripe, mercadopago, bold, transfer, cod, addi, sistecredito, kueski, aplazo. */
    paymentMethods?: Record<string, ShopPublicPaymentMethod>;
    /** v5 F2.3/F2.11: reseñas, avisos, lista de deseos y opciones del checkout (retiro, franjas, notas). */
    storeExtras?: ShopStoreExtrasConfig;
    /** v5 (docs/PRICING.md): formato de precios del proyecto (es-CO, es-MX…). */
    locale?: string;
    /** Pedido mínimo sobre productos ya descontados (0 = sin mínimo). */
    minOrderAmount?: number;
    /** Hay cupones activos: muestra el campo de cupón. */
    coupons?: {
        enabled: boolean;
    };
    /** Hay tarjetas de regalo con saldo: muestra el campo de tarjeta. */
    giftCards?: {
        enabled: boolean;
    };
    customerAccounts?: ShopCustomerAccountsConfig;
    /** v5 F2.8: país del selector, mensajes de confianza, logos y orden de métodos (editables en /portal). */
    checkoutDisplay?: ShopCheckoutDisplay;
    [k: string]: unknown;
}
export interface ShopCheckoutDisplay {
    country?: 'CO' | 'MX' | null;
    trustMessages?: string[];
    showPaymentLogos?: boolean;
    order?: string[];
    methods?: Record<string, {
        description?: string;
        logoUrl?: string;
        kind?: string;
        countries?: string[];
        methods?: string[];
    }>;
}
/** Método de pago listo para pintar el selector del checkout (`paymentOptions(config)`). */
export interface ShopPaymentOption {
    /** Id para `checkout({ provider })`: wompi, mercadopago, bold, stripe, addi, kueski, aplazo, transfer, cod. */
    id: string;
    label: string;
    description: string;
    logoUrl: string;
    /** Texto de cuotas (BNPL). */
    installments: string;
    /** gateway | bnpl | manual. */
    kind: string;
    /** Medios visibles (Wompi: CARD, PSE, NEQUI…). */
    methods: string[];
    /** BNPL: montos permitidos (si la tienda los fijó). */
    minAmount?: number;
    maxAmount?: number;
    /** false si el monto del pedido está fuera de [minAmount, maxAmount] (se muestra deshabilitado). */
    available: boolean;
    /** Modo de pruebas de la pasarela. */
    sandbox: boolean;
    /** Transferencia: datos bancarios e instrucciones que editó la tienda. */
    bankDetails?: string;
    instructions?: string;
}
/** v5 F2.4: solicitud de devolución del comprador. */
export type ShopReturnStatus = 'REQUESTED' | 'APPROVED' | 'REJECTED' | 'REFUNDED' | 'CANCELLED';
export interface ShopReturnRequest {
    id: string;
    orderNumber?: string;
    status: ShopReturnStatus;
    reason: string;
    items: Array<{
        lineId: string;
        quantity: number;
        title?: string;
        variant?: string | null;
    }>;
    customerNote?: string | null;
    resolution?: string | null;
    createdAt: string;
    [k: string]: unknown;
}
/** Reembolso de un pedido (docs/PAYMENTS.md §7): llega en los webhooks `refund.*` y en el portal. */
export interface ShopRefund {
    id: string;
    orderId?: string;
    orderNumber?: string;
    amount: number;
    currency: string;
    status: 'PENDING' | 'SUCCEEDED' | 'FAILED' | (string & {});
    /** Pasarela, tarjeta de regalo o manual. */
    method?: 'gateway' | 'gift_card' | 'manual' | (string & {});
    reason?: string | null;
    items?: Array<{
        lineId: string;
        quantity: number;
        title?: string;
    }>;
    restock?: boolean;
    createdAt: string;
    [k: string]: unknown;
}
export type ShopDiscountKind = 'PERCENT' | 'FIXED' | 'FREE_SHIPPING' | 'BUY_X_GET_Y' | (string & {});
export interface ShopPricingDiscount {
    code: string | null;
    title: string;
    kind: ShopDiscountKind;
    automatic: boolean;
    /** Ahorro en productos. */
    amount: number;
    /** Ahorro en el envío (envío gratis). */
    shippingAmount: number;
}
export interface ShopPricingTax {
    name: string;
    rate: number;
    /** true: ya estaba en el precio (solo se informa); false: se suma al total. */
    inclusive: boolean;
    amount: number;
}
export interface ShopPricingLine {
    productId: string;
    title?: string;
    variantLabel?: string | null;
    quantity: number;
    unitPrice: number;
    compareAtPrice?: number | null;
    lineSubtotal: number;
    discount: number;
    tax: number;
    taxRate: number;
    taxInclusive: boolean;
    total: number;
}
export interface ShopRejectedCode {
    code: string;
    reason: string;
    message: string;
}
/** Cotización del servidor: el navegador nunca calcula el total final. */
export interface ShopPricing {
    currency: string;
    locale: string;
    subtotal: number;
    discounts: ShopPricingDiscount[];
    discountAmount: number;
    shipping: {
        base: number;
        discount: number;
        cost: number;
        zoneId?: string | null;
        zoneName?: string | null;
        eta?: string | null;
        freeByThreshold: boolean;
    };
    shippingCost: number;
    taxes: ShopPricingTax[];
    taxAmount: number;
    taxIncluded: number;
    taxAdded: number;
    /** Total antes de tarjetas de regalo. */
    total: number;
    giftCards: Array<{
        code: string;
        amount: number;
        balanceAfter: number;
    }>;
    giftCardAmount: number;
    /** Lo que se cobra con la pasarela. */
    amountDue: number;
    lines: ShopPricingLine[];
    appliedCodes: string[];
    rejectedCodes: ShopRejectedCode[];
    rejectedGiftCards: ShopRejectedCode[];
    minOrderAmount: number | null;
    belowMinimum: boolean;
    purchaseLimitIssues: Array<{
        productId: string;
        title: string;
        limit: number;
        alreadyBought: number;
        requested: number;
    }>;
}
export interface ShopQuoteInput {
    items: ShopCheckoutItem[];
    /** Cupones escritos por el comprador. */
    codes?: string[];
    giftCardCodes?: string[];
    /** Algunos cupones dependen del comprador (primera compra, lista de correos, usos por cliente). */
    customerEmail?: string;
    shippingAddress?: {
        city?: string;
        department?: string;
        state?: string;
        country?: string;
        postalCode?: string;
        daneCode?: string;
    };
    shippingZoneId?: string;
    /** v5 F2.9: opción de `quoteShipping()`; la cotización usa su monto (zonas o transportadora). */
    shippingOptionId?: string;
    /** v5 F2.11: `pickup` = retiro en tienda (envío 0, si la tienda lo ofrece). */
    fulfillment?: ShopFulfillment;
    /** Método de pago elegido (algunos descuentos dependen del método). */
    paymentMethod?: string;
}
/** Entrega a domicilio o retiro en tienda. */
export type ShopFulfillment = 'shipping' | 'pickup';
/** Franja elegida en el checkout (no cambia el total). */
export interface ShopDeliverySlot {
    /** YYYY-MM-DD, una de `storeExtras.deliveryDates`. */
    date: string;
    windowId: string;
}
export interface ShopDiscountValidation {
    valid: boolean;
    applied: boolean;
    code: string;
    reason?: string;
    message?: string;
    amount?: number;
    title?: string;
    kind?: ShopDiscountKind;
    pricing: ShopPricing;
}
export interface ShopCheckoutItem {
    productId: string;
    quantity: number;
    variant?: string;
    variantLabel?: string;
    sku?: string;
    title?: string;
}
export interface ShopCheckoutInput {
    customerName: string;
    customerEmail: string;
    customerPhone?: string;
    documentType?: string;
    documentId?: string;
    shippingAddress: {
        address: string;
        city: string;
        department?: string;
        country?: string;
        postalCode?: string;
        notes?: string;
        [k: string]: unknown;
    };
    billingAddress?: Record<string, unknown>;
    items: ShopCheckoutItem[];
    notes?: string;
    /** wompi, stripe, mercadopago, bold, transfer, cod (por defecto wompi). */
    provider?: string;
    /** Vuelta tras pagar; debe ser un origen permitido del proyecto. */
    redirectUrl?: string;
    shippingZoneId?: string;
    /** v5 (docs/PRICING.md): cupones y tarjetas de regalo; el servidor los valida de nuevo. */
    couponCodes?: string[];
    giftCardCodes?: string[];
    /** v5 F2.9: id de una opción de `quoteShipping()`; el servidor re-cotiza y cobra su propio monto. */
    shippingOptionId?: string;
    /** Monto que mostraste (solo para detectar cambios: si difiere, 409 SHIPPING_AMOUNT_CHANGED). */
    shippingAmount?: number;
    /** Medición (docs/TRACKING.md): event_id y cookies de Meta para la API de conversiones. El cliente lo llena solo. */
    tracking?: TrackingContext;
    /** v5 F2.11: retiro en tienda (`pickup` + `pickupLocationId`) o envío (por defecto). */
    fulfillment?: ShopFulfillment;
    pickupLocationId?: string;
    /** v5 F2.11: franja de entrega (si la tienda agenda entregas). */
    deliverySlot?: ShopDeliverySlot;
    [k: string]: unknown;
}
export interface ShopCheckoutResult {
    orderId: string;
    orderNumber: string;
    transactionId?: string;
    reference?: string;
    status: ShopOrderStatus;
    totalAmount: number;
    currency: string;
    checkoutUrl?: string;
    clientSecret?: string;
    redirectUrl?: string | null;
    /** Datos públicos de la pasarela (Bold: `widget` con la firma de integridad del botón embebido). */
    gatewayData?: Record<string, unknown>;
    /** Solo en checkout de invitado: permite vincular la orden al crear la cuenta (se guarda solo). */
    claimToken?: string;
    /** v5: desglose del servidor (descuentos, impuestos, tarjetas de regalo). */
    pricing?: ShopPricing;
    discountAmount?: number;
    taxAmount?: number;
    giftCardAmount?: number;
    [k: string]: unknown;
}
/** Dirección para cotizar envíos (CO: ciudad + departamento o daneCode; MX: código postal). */
export interface ShopShippingAddress {
    address?: string;
    city?: string;
    department?: string;
    state?: string;
    country?: string;
    postalCode?: string;
    daneCode?: string;
    [k: string]: unknown;
}
export interface ShopShippingOption {
    id: string;
    name: string;
    amount: number;
    currency: string;
    free: boolean;
    etaDays: number | null;
    etaDaysMax: number | null;
    /** Texto listo para mostrar: "2 a 4 días hábiles". */
    estimatedDelivery: string;
    carrier: string | null;
    /** false = no se puede pagar contraentrega con esta opción. */
    codAllowed: boolean;
    type: 'FLAT' | 'BY_WEIGHT' | 'BY_SUBTOTAL' | 'FREE_OVER' | 'CARRIER_QUOTE' | 'LEGACY_FLAT' | 'LEGACY_ZONE' | (string & {});
}
export interface ShopShippingQuote {
    /** `flat` = la tienda no tiene zonas (tarifa plana + envío gratis desde el umbral). */
    mode: 'zones' | 'flat';
    currency: string;
    subtotal: number;
    weightKg: number;
    zone: {
        id: string;
        name: string;
    } | null;
    options: ShopShippingOption[];
    /** La opción que el servidor usa si no eliges (la más barata). */
    defaultOptionId: string | null;
    /** Sin opciones: NO_ZONE (no se envía a esa dirección) o NO_RATE. */
    reason?: 'NO_ZONE' | 'NO_RATE';
    message?: string;
}
/** Resumen público de la orden: sin correo, teléfono, documento ni dirección completa. */
export interface ShopPublicOrder {
    orderNumber: string;
    status: ShopOrderStatus;
    paymentStatus: ShopPaymentStatus;
    totalAmount: number;
    currency: string;
    destinationCity?: string | null;
    items: ShopOrderLine[];
}
export interface ShopConfirmResult {
    orderNumber: string;
    paymentStatus: ShopPaymentStatus;
    gatewayStatus: 'APPROVED' | 'DECLINED' | 'VOIDED' | 'ERROR' | 'PENDING' | (string & {});
    canRetry: boolean;
    order: ShopPublicOrder;
    duplicatePayment?: boolean;
    [k: string]: unknown;
}
/** Lo que trae la URL de retorno de cada pasarela (ver `readPaymentReturn`). */
export interface ShopPaymentReturn {
    provider?: 'wompi' | 'mercadopago' | 'bold' | 'stripe';
    /** Wompi: `?id=`. */
    transactionId?: string;
    /** MercadoPago: `?payment_id=` / `?collection_id=`. */
    paymentId?: string;
    /** Stripe: `?payment_intent=`. */
    paymentIntentId?: string;
    /** MercadoPago `external_reference` (= referencia de la transacción). */
    reference?: string;
    /** Estado informado por la pasarela en la URL: solo orientativo, el backend verifica. */
    status?: string;
}
/** Pedido con pago en curso que este navegador recuerda tras `checkout()`. */
export interface ShopPendingPayment {
    orderNumber: string;
    reference: string;
    provider: string;
    at: number;
}
export interface ShopRetryResult {
    orderNumber: string;
    reference: string;
    totalAmount: number;
    currency: string;
    checkoutUrl: string;
    redirectUrl?: string | null;
}
export interface ShopTrackResult {
    orderNumber: string;
    status: ShopOrderStatus;
    paymentStatus?: ShopPaymentStatus;
    paymentMethod?: string;
    carrierName?: string | null;
    trackingNumber?: string | null;
    trackingUrl?: string | null;
    estimatedDelivery?: string | null;
    trackingEvents?: ShopTrackingEvent[];
    /** v4.3: envíos del pedido (Dropi, Interrapidísimo, webhook o manual), del más antiguo al más reciente. */
    shipments?: ShopShipment[];
    [k: string]: unknown;
}
export interface ShopRegisterInput {
    email: string;
    password: string;
    name: string;
    phone?: string;
    acceptsMarketing?: boolean;
    /** Debe ser true (aceptación de términos y tratamiento de datos). */
    acceptsTerms: true;
    /** Por defecto: las órdenes de invitado de este navegador (guardadas al hacer checkout). */
    claimOrders?: {
        orderNumber: string;
        claimToken: string;
    }[];
}
export interface ShopAuthResult {
    token: string;
    customer: ShopCustomer;
}
export interface ShopProfilePatch {
    name?: string;
    phone?: string;
    documentType?: string;
    documentId?: string;
    acceptsMarketing?: boolean;
}
/** Almacenamiento compatible con localStorage. */
export interface ShopStorage {
    getItem(key: string): string | null;
    setItem(key: string, value: string): void;
    removeItem(key: string): void;
}
export interface ShopClientOptions {
    /** Slug del proyecto en el CMS. */
    slug: string;
    /** URL del CMS (por defecto https://webproai.tech). */
    apiUrl?: string;
    /** Dónde guardar el token (por defecto localStorage si existe; si no, memoria). `null` = solo memoria. */
    storage?: ShopStorage | null;
    fetch?: typeof fetch;
}
export interface ShopClient {
    readonly slug: string;
    readonly apiUrl: string;
    config(): Promise<ShopPublicConfig>;
    /** Cotiza el carrito en el servidor (descuentos, envío, impuestos, tarjetas de regalo). */
    quote(input: ShopQuoteInput): Promise<ShopPricing>;
    /** Valida un cupón contra el carrito; nunca lanza por un cupón inválido (`valid: false` + `message`). */
    validateDiscount(code: string, input: ShopQuoteInput): Promise<ShopDiscountValidation>;
    checkout(input: ShopCheckoutInput, opts?: {
        saveAddress?: boolean;
    }): Promise<ShopCheckoutResult>;
    confirmPayment(input: {
        transactionId?: string;
        paymentIntentId?: string;
        paymentId?: string;
        reference?: string;
        orderNumber?: string;
    }, opts?: {
        provider?: string;
    }): Promise<ShopConfirmResult>;
    /** Estado del pago para la página de retorno; `reference` es la que devolvió `checkout()`. */
    paymentStatus(orderNumber: string, reference: string): Promise<ShopConfirmResult>;
    /** Confirma (si la URL trae datos de la pasarela) y sondea hasta PAID/FAILED o el tiempo límite. */
    waitForPayment(input: {
        orderNumber: string;
        reference: string;
        provider?: string;
        returnParams?: ShopPaymentReturn;
    }, opts?: {
        intervalMs?: number;
        timeoutMs?: number;
        signal?: AbortSignal;
    }): Promise<ShopConfirmResult>;
    /** Retoma el pago pendiente guardado por `checkout()`; null si no hay ninguno. */
    resumePayment(opts?: {
        search?: string;
        intervalMs?: number;
        timeoutMs?: number;
        signal?: AbortSignal;
    }): Promise<ShopConfirmResult | null>;
    /** Pedido pendiente guardado en este navegador (o null). */
    pendingPayment(): ShopPendingPayment | null;
    clearPendingPayment(): void;
    retryPayment(orderNumber: string, opts?: {
        email?: string;
        redirectUrl?: string;
    }): Promise<ShopRetryResult>;
    track(code: string): Promise<ShopTrackResult>;
    /** v5 F2.9: opciones de envío para una dirección y un carrito (POST /shipping/quote, con límite de peticiones). */
    quoteShipping(input: {
        address: ShopShippingAddress;
        items: ShopCheckoutItem[];
    }): Promise<ShopShippingQuote>;
    account: {
        register(input: ShopRegisterInput): Promise<ShopAuthResult & {
            claimedOrders: string[];
        }>;
        login(input: {
            email: string;
            password: string;
        }): Promise<ShopAuthResult>;
        /** Cierra la sesión en este navegador (borra el token local). */
        logout(): void;
        /** Invalida todos los tokens de la cuenta (todos los dispositivos) y borra el local. */
        logoutAll(): Promise<void>;
        /** Siempre responde `{ sent: true }`. `resetUrl` por defecto: <origen actual>/cuenta/restablecer. */
        forgotPassword(input: {
            email: string;
            resetUrl?: string;
        }): Promise<{
            sent: boolean;
        }>;
        resetPassword(input: {
            token: string;
            password: string;
        }): Promise<ShopAuthResult>;
        me(): Promise<ShopCustomer>;
        update(patch: ShopProfilePatch): Promise<ShopCustomer>;
        changePassword(input: {
            currentPassword: string;
            newPassword: string;
        }): Promise<ShopAuthResult>;
        addresses: {
            list(): Promise<ShopAddress[]>;
            add(address: ShopAddressInput): Promise<ShopAddress[]>;
            update(id: string, patch: Partial<ShopAddressInput>): Promise<ShopAddress[]>;
            remove(id: string): Promise<ShopAddress[]>;
        };
        orders: {
            list(opts?: {
                page?: number;
                limit?: number;
            }): Promise<ShopPage<ShopOrderSummary>>;
            get(orderNumber: string): Promise<ShopOrder>;
        };
        /** v5 F2.4: «Solicitar devolución» de un pedido pagado y sus solicitudes. */
        returns: {
            list(): Promise<ShopReturnRequest[]>;
            /** `items` vacío = el pedido completo; `lineId` de cada línea de `orders.get()`. */
            request(orderNumber: string, input: {
                reason: string;
                items?: Array<{
                    lineId: string;
                    quantity: number;
                }>;
                note?: string;
            }): Promise<ShopReturnRequest>;
        };
        deleteAccount(input: {
            password: string;
        }): Promise<{
            deleted: boolean;
        }>;
    };
    getToken(): string | null;
    setToken(token: string | null): void;
    /** Avisa cuando el token cambia (login, logout o 401 por sesión vencida). Devuelve la función para desuscribirse. */
    onTokenChange(listener: (token: string | null) => void): () => void;
}
/** Error de la tienda con el `code` del backend (EMAIL_TAKEN, INVALID_CREDENTIALS, PAYMENT_FAILED, OUT_OF_STOCK…). */
export declare class ShopError extends Error {
    status: number;
    code: string;
    /** Cuerpo completo de la respuesta (p. ej. `canRetry`, `orderNumber`, lista de agotados). */
    body: Record<string, unknown>;
    constructor(message: string, status: number, code: string, body?: Record<string, unknown>);
}
/**
 * Métodos de pago para el selector de un checkout headless (v5 F2.8): solo los que el backend marca
 * activos y del país de la tienda, en el orden y con los textos, logos y cuotas que editó la tienda.
 * Con `amount`, los BNPL fuera de su rango quedan con `available: false` (se muestran deshabilitados).
 *   const opts = paymentOptions(await shop.config(), { amount: pricing.amountDue });
 */
export declare function paymentOptions(config: ShopPublicConfig | null | undefined, opts?: {
    amount?: number;
    country?: 'CO' | 'MX' | null;
    includeUnavailable?: boolean;
}): ShopPaymentOption[];
/** true para los métodos «compra ahora, paga después» (Addi, Kueski Pay, Aplazo). */
export declare const isBnplOption: (o: Pick<ShopPaymentOption, "kind"> | null | undefined) => boolean;
/** Opciones del checkout de la tienda (retiro, franjas y notas) con valores por defecto seguros. */
export declare function checkoutOptions(config: ShopPublicConfig | null | undefined): ShopCheckoutOptionsConfig & {
    deliveryDates: string[];
};
/** Campos del checkout para retiro y franja (solo los que aplican a la configuración de la tienda). */
export declare function checkoutExtrasBody(config: ShopPublicConfig | null | undefined, value: {
    fulfillment?: ShopFulfillment;
    pickupLocationId?: string;
    deliverySlot?: Partial<ShopDeliverySlot> | null;
}): Pick<ShopCheckoutInput, 'fulfillment' | 'pickupLocationId' | 'deliverySlot'>;
/** Etiqueta de una fecha de entrega (`2026-11-12` → «jueves, 12 de noviembre»). */
export declare function deliveryDateLabel(iso: string, locale?: string): string;
/** Fila del resumen de totales (`pricingRows`), lista para pintar en el carrito o el checkout. */
export interface ShopPricingRow {
    kind: 'subtotal' | 'discount' | 'shipping' | 'tax' | 'total' | 'giftCard' | 'amountDue';
    label: string;
    amount: number;
    /** Monto con signo: descuentos y tarjetas en negativo; impuestos incluidos en 0 (no suman). */
    signed: number;
    /** Texto formateado (−$ 10.000, «Gratis»). */
    text: string;
    code?: string | null;
    /** Impuesto ya incluido en el precio (solo informativo). */
    inclusive?: boolean;
    /** Envío: el precio antes del descuento de envío (para tacharlo). */
    was?: number;
}
/** Rótulos de `pricingRows` (los mismos de `global.ui` del sitio: ver `SHOP_UI`). */
export interface ShopPricingLabels {
    subtotal: string;
    discount: string;
    shipping: string;
    shippingFree: string;
    taxIncluded: string;
    total: string;
    giftCardPaid: string;
    amountDue: string;
}
/**
 * Desglose de impuestos de una cotización: los incluidos en el precio (informativos) y los
 * agregados (suman al total), con el total de cada grupo.
 */
export declare function taxBreakdown(pricing: Pick<ShopPricing, 'taxes'> | null | undefined): {
    included: ShopPricingTax[];
    added: ShopPricingTax[];
    includedAmount: number;
    addedAmount: number;
};
/**
 * Filas del resumen de una cotización del servidor (mismo orden que el carrito de /site): subtotal,
 * descuentos, envío, impuestos (los incluidos como nota), total, tarjetas de regalo y total a pagar.
 *   pricingRows(cart.pricing, { labels: ui }).map((r) => <div key={r.kind + r.label}>{r.label} {r.text}</div>)
 */
export declare function pricingRows(pricing: ShopPricing | null | undefined, opts?: {
    labels?: Partial<ShopPricingLabels>;
    currency?: string;
    locale?: string;
}): ShopPricingRow[];
/**
 * Formateador de dinero con la moneda y el formato del proyecto. Acepta el delivery (`payload`), la
 * config de la tienda (`shop.config()`), una cotización (`pricing`) o `{ currency, locale }`.
 *   const money = moneyFormatter(payload); money(125000) → "$ 125.000"
 */
export declare function moneyFormatter(source?: {
    currency?: string;
    locale?: string;
    ecommerce?: {
        currency?: string;
        locale?: string;
    } | null;
} | null): (amount: number) => string;
/** Etiqueta legible del estado de pago de un pedido (`PAID` → «Pagado»). */
export declare function paymentStatusLabel(status: ShopPaymentStatus | null | undefined): string;
/** Etiqueta legible del estado de una devolución. */
export declare function returnStatusLabel(status: ShopReturnStatus | (string & {}) | null | undefined): string;
/**
 * Lee los parámetros que cada pasarela añade al volver al sitio:
 * Wompi `?id=…`, MercadoPago `?payment_id=…&status=…&external_reference=…`,
 * Stripe `?payment_intent=…&redirect_status=…`, Bold `?bold-order-id=…&bold-tx-status=…`.
 */
export declare function readPaymentReturn(search?: string): ShopPaymentReturn;
/**
 * Formato de dinero de la tienda: COP sin decimales, MXN/USD con 2, locale del proyecto
 * (`config().locale` o `pricing.locale`) o el de la moneda.
 *   formatMoney(125000, 'COP') → "$ 125.000" · formatMoney(1250.5, 'MXN') → "$1,250.50"
 */
export declare function formatMoney(amount: number, currency?: string, locale?: string): string;
export declare function createShopClient(opts: ShopClientOptions): ShopClient;
export type Customer = ShopCustomer;
export type Address = ShopAddress;
export type OrderSummary = ShopOrderSummary;
export type Shipment = ShopShipment;
export {};
