import type { CmsPage, CmsSectionRef, CollectionItem, DeliveryPayload, Product, SectionData } from './types.js';
export declare const DEFAULT_CMS_URL = "https://webproai.tech";
export declare class CmsDeliveryError extends Error {
    status: number;
    url: string;
    constructor(message: string, status: number, url: string);
}
export interface FetchDeliveryOptions {
    /** Slug del proyecto (o usa `host`). */
    slug?: string;
    /** Dominio propio: usa /api/v1/delivery/by-domain/:host. */
    host?: string;
    /** URL del CMS (por defecto https://webproai.tech). */
    baseUrl?: string;
    /** Pide borradores. Sin previewToken válido el servidor devuelve lo publicado (contrato 2.6). */
    preview?: boolean;
    previewToken?: string;
    /** Segundos de ISR en Next.js (por defecto 60). `false` = sin caché. Se ignora en preview. */
    revalidate?: number | false;
    /** Etiquetas de caché de Next.js (por defecto `cms:<slug>`), para revalidateTag desde el webhook. */
    tags?: string[];
    fetch?: typeof fetch;
    init?: RequestInit;
    timeoutMs?: number;
}
export declare function normalizeBaseUrl(url?: string): string;
/** Construye la URL de delivery. */
export declare function deliveryUrl(opts: FetchDeliveryOptions): string;
/**
 * Descarga el contenido del sitio. Lanza CmsDeliveryError si falla.
 * En Next.js cachea con ISR (`revalidate`) y etiquetas; en preview usa `no-store`.
 */
export declare function fetchDelivery(opts: FetchDeliveryOptions): Promise<DeliveryPayload>;
/** Igual que fetchDelivery pero devuelve null ante cualquier error (útil para no romper el render). */
export declare function tryFetchDelivery(opts: FetchDeliveryOptions): Promise<DeliveryPayload | null>;
export declare function normalizePageSlug(slug?: string): string;
export declare function getPage(p: DeliveryPayload | null | undefined, slug?: string): CmsPage | undefined;
/**
 * Página del CMS para una ruta del sitio: coincidencia exacta o el prefijo más largo
 * (`/producto/creatina` → `/producto` si existe esa página). Sin coincidencia: `/`.
 * `basePath` se quita antes (p. ej. "/site/demo").
 */
export declare function pageSlugFromPath(pathname: string | undefined | null, p?: DeliveryPayload | null, basePath?: string): string;
/** Secciones visibles de una página, en orden. `includeHidden` para el editor. */
export declare function getSections(p: DeliveryPayload | null | undefined, pageSlug?: string, { includeHidden }?: {
    includeHidden?: boolean | undefined;
}): CmsSectionRef[];
/**
 * Sección por clave. Si no existe devuelve una referencia vacía con `isVisible: false`
 * para que el componente pueda decidir no renderizar.
 */
export declare function getSection<T extends SectionData = SectionData>(p: DeliveryPayload | null | undefined, pageSlug: string, key: string): CmsSectionRef<T>;
/** Secciones de un tipo de bloque (contrato 2.3), en una página o en todas. */
export declare function findSectionsByBlock(p: DeliveryPayload | null | undefined, block: string, pageSlug?: string): CmsSectionRef[];
export declare function sectionVisible(p: DeliveryPayload | null | undefined, pageSlug: string, key: string): boolean;
/** Valor de `global` con ruta con puntos (ej. "ui.addToCart"). */
export declare function getGlobal<T = any>(p: DeliveryPayload | null | undefined, dotted: string, fallback?: T): T;
export declare function getCollection(p: DeliveryPayload | null | undefined, slug: string): CollectionItem[];
/** Slug de la colección de tienda (isStore o productos/products/catalogo). */
export declare function getStoreCollectionSlug(p: DeliveryPayload | null | undefined): string | undefined;
/** Número desde texto de precio con formato colombiano ("$ 45.000" → 45000). */
export declare function toNumber(v: unknown): number | undefined;
export declare function splitList(v?: string | string[], sep?: RegExp): string[];
export declare function normalizeProduct(raw: CollectionItem): Product;
/** Peso por unidad en kg: `weightKg`, o `weight` + `weightUnit` (g | kg | lb). Misma regla que el backend. */
export declare function unitWeightKg(data: Record<string, any> | null | undefined): number | undefined;
/** true si el precio anterior (`compareAtPrice`) es mayor que el actual (badge «Oferta»). */
export declare function isOnSale(product: Pick<Product, 'price' | 'compareAtPrice'> | null | undefined): boolean;
/** Porcentaje de descuento frente a `compareAtPrice` (0 si no está en oferta). */
export declare function discountPercent(product: Pick<Product, 'price' | 'compareAtPrice'> | null | undefined): number;
export interface GetProductsOptions {
    collection?: string;
    category?: string;
    featured?: boolean;
    /** Incluir ítems no publicados (solo llegan en preview). */
    includeUnpublished?: boolean;
}
export declare function getProducts(p: DeliveryPayload | null | undefined, opts?: GetProductsOptions): Product[];
export declare function getProduct(p: DeliveryPayload | null | undefined, slugOrId: string, collection?: string): Product | undefined;
/** Categorías del filtro: las del esquema de la colección, o las presentes en los productos. */
export declare function getCategories(p: DeliveryPayload | null | undefined, collection?: string): string[];
/** Precio efectivo (de la variante si tiene precio propio). */
export declare function productPrice(product: Product, variantLabel?: string): number;
/**
 * @deprecated Desde 4.4: usa `formatMoney(amount, currency, locale)` o `moneyFormatter(payload)` (respetan
 * el locale del proyecto y los decimales de cada moneda). Se mantiene por compatibilidad.
 */
export declare function formatPrice(amount: number, currency?: string, locale?: string): string;
/** URL absoluta para medios del CMS (`/uploads/...` → `https://webproai.tech/uploads/...`). */
export declare function mediaUrl(url: string | undefined, baseUrl?: string): string;
