/**
 * Rótulos de la tienda y dinero con el formato del proyecto, editables desde /portal.
 *
 *   const ui = useShopUi();                      // global.ui > SHOP_UI
 *   <button><CmsUiText k="addToCart" /></button>  // en el editor: clic → editar el global
 *   const money = useMoney(); money(125000)       // "$ 125.000" (moneda y locale del proyecto)
 */
import React from 'react';
import { type ShopUi, type ShopUiKey } from '../ui.js';
/** Rótulos de la tienda: `overrides` > `global.ui` del sitio > `SHOP_UI` (español neutro). */
export declare function useShopUi(overrides?: Partial<ShopUi>): ShopUi;
/**
 * Un rótulo de `global.ui` con su valor por defecto. Emite `data-cms-global="ui.<clave>"`: en el
 * editor del portal, un clic abre el global para editarlo (regla de editabilidad).
 */
export declare function CmsUiText({ k, n, as: Tag, fallback, ...rest }: {
    k: ShopUiKey | (string & {});
    n?: string | number;
    as?: React.ElementType;
    fallback?: string;
} & Omit<React.HTMLAttributes<HTMLElement>, 'children'>): React.JSX.Element;
/**
 * Formateador de dinero con la moneda y el locale del proyecto (delivery `ecommerce`), o los que pases.
 * Sin <CmsProvider> usa COP / es-CO.
 */
export declare function useMoney(source?: {
    currency?: string;
    locale?: string;
} | null): (amount: number) => string;
