import React from 'react';
import { type Cart, type CartContact, type CartLine, type CartLineInput, type CartOptions, type CartRecovery, type WhatsAppOrderInput, type WhatsAppOrderResult } from '../cart.js';
import { ShopError, type ShopCheckoutInput, type ShopCheckoutResult, type ShopClient, type ShopPricing, type ShopStorage } from '../shop.js';
/** Alias de compatibilidad (v5 F2 precios): una línea del carrito. */
export type CartItem = CartLine;
export interface CartCodeResult {
    ok: boolean;
    /** true si el código cambió el total (un cupón válido puede no ahorrar hoy). */
    applied?: boolean;
    message?: string;
    reason?: string;
}
export interface CartValue {
    items: CartLine[];
    count: number;
    /** Estimación local (precio × cantidad); el total real está en `pricing`. */
    subtotal: number;
    /** Igual que `subtotal` (nombre anterior). */
    estimatedSubtotal: number;
    contact: CartContact;
    couponCodes: string[];
    giftCardCodes: string[];
    /** Cotización del servidor; null sin líneas o mientras llega la primera. */
    pricing: ShopPricing | null;
    loading: boolean;
    error: ShopError | null;
    /** Agrega una línea (`quantity` como 2.º argumento o dentro de la línea; por defecto 1). */
    add(line: CartLineInput, quantity?: number): void;
    setQuantity(index: number, quantity: number): void;
    remove(index: number): void;
    /** Vacía el carrito (y empieza un carrito nuevo en el CMS). */
    clear(): void;
    applyCoupon(code: string): Promise<CartCodeResult>;
    removeCoupon(code: string): void;
    applyGiftCard(code: string): Promise<CartCodeResult>;
    removeGiftCard(code: string): void;
    /** Desde el checkout: con correo o teléfono el carrito se guarda en el CMS (con espera). Re-cotiza. */
    setContact(contact: CartContact): void;
    /** Atajo de setContact({ email }) (algunos cupones dependen del correo). */
    setCustomerEmail(email: string): void;
    /** Guarda ya en el CMS (sin esperar). */
    flush(): Promise<void>;
    /** Restaura el carrito de un enlace de recuperación y aplica su cupón si lo trae. */
    recover(token: string): Promise<CartRecovery>;
    /** Última recuperación (enlace /carrito/recuperar), con el cupón de la tienda si lo hay. */
    recovered: CartRecovery | null;
    /** Vuelve a cotizar ya (p. ej. tras cambiar la ciudad). */
    refresh(): Promise<ShopPricing | null>;
    /** Checkout con las líneas y códigos del carrito; lo vacía si el pedido se crea. */
    checkout(input: Omit<ShopCheckoutInput, 'items'>, opts?: {
        saveAddress?: boolean;
    }): Promise<ShopCheckoutResult>;
    /**
     * «Pedir por WhatsApp»: crea el pedido PENDING_WHATSAPP con las líneas, cupones y tarjetas del
     * carrito (precios del servidor) y devuelve `whatsappUrl`. Vacía el carrito salvo `keepCart`.
     */
    buildWhatsAppOrder(input?: Partial<Omit<WhatsAppOrderInput, 'slug' | 'apiUrl' | 'fetch' | 'items'>> & {
        keepCart?: boolean;
    }): Promise<WhatsAppOrderResult>;
    client: ShopClient;
    cart: Cart;
}
/** `slug` (o un `client` de createShopClient, o un `cart` de createCart) identifica la tienda. */
type SourceProps = {
    client?: ShopClient;
    slug?: string;
    apiUrl?: string;
};
export type CartProviderProps = {
    children?: React.ReactNode;
    /** Carrito ya creado con createCart() (se comparte fuera de React). */
    cart?: Cart;
    /** Espera antes de re-cotizar (ms). */
    quoteDelayMs?: number;
    /** `false` no cotiza en el servidor (solo estimación local). */
    quote?: boolean;
    /** Dónde se guarda el carrito (por defecto `storage` o localStorage; null = solo memoria). */
    cartStorage?: ShopStorage | null;
    /** Restaura el carrito en /carrito/recuperar?token=… al montar (por defecto sí). */
    recoverOnMount?: boolean;
    /** Ruta de recuperación (por defecto /carrito/recuperar). */
    recoverPath?: RegExp;
} & SourceProps & Omit<Partial<CartOptions>, 'slug' | 'apiUrl'>;
/** Reinicia la caché de instantáneas (pruebas). */
export declare function __resetCartSnapshots(): void;
export declare function CartProvider(props: CartProviderProps): React.JSX.Element;
/** Carrito de la tienda. Requiere <CartProvider>. */
export declare function useCart(): CartValue;
/** Igual que useCart() pero devuelve null fuera del provider. */
export declare function useOptionalCart(): CartValue | null;
export {};
