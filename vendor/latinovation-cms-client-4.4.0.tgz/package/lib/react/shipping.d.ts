import { type ShopCheckoutItem, type ShopClient, type ShopError, type ShopShippingAddress, type ShopShippingOption, type ShopShippingQuote } from '../shop.js';
export interface UseShippingOptionsInput {
    address: ShopShippingAddress | null | undefined;
    items: ShopCheckoutItem[];
    client?: ShopClient;
    slug?: string;
    apiUrl?: string;
    /** Espera antes de cotizar tras un cambio (por defecto 400 ms). */
    debounceMs?: number;
    /** false pausa la cotización (p. ej. mientras el carrito está cerrado). */
    enabled?: boolean;
}
export interface UseShippingOptionsValue {
    quote: ShopShippingQuote | null;
    options: ShopShippingOption[];
    selectedId: string | null;
    selected: ShopShippingOption | null;
    select(id: string): void;
    loading: boolean;
    error: ShopError | null;
    /** Cotiza ya (sin esperar). */
    refresh(): Promise<ShopShippingQuote | null>;
}
/** true cuando la dirección permite cotizar: ciudad o código DANE, o código postal. */
export declare function canQuoteAddress(a: ShopShippingAddress | null | undefined): boolean;
export declare function useShippingOptions(input: UseShippingOptionsInput): UseShippingOptionsValue;
