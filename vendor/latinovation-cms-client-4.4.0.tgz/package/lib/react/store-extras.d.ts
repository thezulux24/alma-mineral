/**
 * Reseñas, favoritos, avisos de stock, relacionados y vistos recientemente para storefronts React
 * (docs/REVIEWS-AND-CHANNELS.md). Funcionan dentro de <CmsProvider> (toman slug y URL del CMS) y,
 * si hay <ShopAccountProvider>, usan la cuenta del cliente para los favoritos.
 *
 *   const { items, summary, submit } = useReviews(product.id);
 *   <CmsRatingStars value={product.ratingAverage} count={product.ratingCount} />
 *   <CmsReviews productId={product.id} />
 *   const wl = useWishlist(); wl.toggle(product.id)
 *   const { subscribe } = useBackInStock(product.id)
 *   const recent = useRecentlyViewed(product.id)
 *
 * Los rótulos salen de `global.ui` (los mismos que el renderer de /site; se editan en
 * Tienda › Más opciones › Textos) con respaldo en español neutro, o de la prop `labels`.
 */
import React from 'react';
import { type PublicReview, type ReviewInput, type ReviewsPage, type StoreExtrasClient } from '../store-extras.js';
import type { CollectionItem } from '../types.js';
/**
 * Rótulos de reseñas (subconjunto de `SHOP_UI`).
 * @deprecated Desde 4.4: usa `SHOP_UI` / `useShopUi()`, que cubren toda la tienda con las mismas claves.
 */
export declare const REVIEW_LABELS: {
    reviewsCount: string;
    ratingOutOf: string;
    noReviews: string;
    verifiedPurchase: string;
    storeReply: string;
    moreReviews: string;
    yourRating: string;
    reviewTitle: string;
    reviewBody: string;
    reviewName: string;
    reviewEmail: string;
    reviewSubmit: string;
    reviewThanks: string;
    reviewPublished: string;
    reviewError: string;
    sending: string;
    loading: string;
};
export type ReviewLabels = typeof REVIEW_LABELS;
/** Cliente de extras ligado al <CmsProvider> (slug + URL) y a la sesión de la tienda si existe. */
export declare function useStoreExtras(opts?: {
    slug?: string;
    apiUrl?: string;
}): StoreExtrasClient | null;
/** Rótulos: `labels` > global.ui del sitio > valores por defecto. */
export declare function useReviewLabels(labels?: Partial<ReviewLabels>): ReviewLabels;
export interface UseReviews {
    items: PublicReview[];
    summary: ReviewsPage['summary'] | null;
    total: number;
    loading: boolean;
    error: Error | null;
    hasMore: boolean;
    loadMore(): void;
    reload(): void;
    /** Envía la reseña (con `photos`: ids de `uploadPhoto`; con `token`: compra verificada del correo). */
    submit(input: Omit<ReviewInput, 'productId'> & {
        productId?: string;
    }): Promise<{
        status: string;
        message: string;
    }>;
    /** Sube una foto (máx. 6 MB; se convierte a WebP) y devuelve su id para `submit({ photos })`. */
    uploadPhoto(file: Blob, fileName?: string): Promise<{
        id: string;
        url: string;
    }>;
}
/** Reseñas aprobadas de un producto (o de toda la tienda con `null`), paginadas. */
export declare function useReviews(productId: string | null | undefined, opts?: {
    pageSize?: number;
    sort?: 'highest' | 'lowest' | 'photos';
    client?: StoreExtrasClient;
}): UseReviews;
/**
 * Enlace del correo «Califica tu compra» (`?resena=<token>&estrellas=N`): datos del producto para
 * prellenar el formulario. `token` va en `submit({ token })` y marca la compra como verificada.
 */
export declare function useReviewInvite(opts?: {
    search?: string;
    client?: StoreExtrasClient;
}): {
    token: string | null;
    stars: number;
    product: {
        id: string;
        slug: string;
        title: string;
        imageUrl: string;
    } | null;
    name: string;
    alreadyReviewed: boolean;
    error: Error | null;
};
/** Promedio y conteo de reseñas de varios productos (tarjetas que no vienen del delivery). */
export declare function useReviewSummaries(productIds: string[], opts?: {
    client?: StoreExtrasClient;
}): Record<string, {
    average: number;
    count: number;
}>;
/** Estrellas con relleno parcial (accesibles: role=img + aria-label). Colores con --cms-*. */
export declare function CmsRatingStars({ value, count, size, label, className, showValue }: {
    value: number | null | undefined;
    count?: number;
    size?: number;
    label?: string;
    className?: string;
    showValue?: boolean;
}): React.JSX.Element;
export interface CmsReviewsProps {
    productId: string | null;
    pageSize?: number;
    showForm?: boolean;
    showSummary?: boolean;
    labels?: Partial<ReviewLabels>;
    className?: string;
    /** Pinta cada reseña a tu manera (por defecto, un <article> sencillo con las clases data-cms-review). */
    renderReview?: (r: PublicReview, labels: ReviewLabels) => React.ReactNode;
    /** Fotos en el formulario (máximo por reseña; 0 = sin fotos). Usa `storeExtras.reviews.maxPhotos`. */
    maxPhotos?: number;
    /** v4.4: lee `?resena=<token>&estrellas=N` del correo y prellena (por defecto true). */
    invite?: boolean;
    sort?: 'highest' | 'lowest' | 'photos';
}
/** Lista + resumen + formulario sin estilos propios (atributos data-cms-review-* para tu CSS). */
export declare function CmsReviews({ productId, pageSize, showForm, showSummary, labels: overrides, className, renderReview, maxPhotos, invite, sort }: CmsReviewsProps): React.JSX.Element;
/** Favoritos: con sesión de cliente se guardan en la cuenta (y se suben los del navegador); sin sesión, en este navegador. */
export declare function useWishlist(opts?: {
    client?: StoreExtrasClient;
}): {
    ids: string[];
    loading: boolean;
    has: (id: string) => boolean;
    toggle: (productId: string) => Promise<boolean>;
    synced: boolean;
};
/** "Avísame cuando llegue" de un producto (o variante) agotado. */
export declare function useBackInStock(productId: string, opts?: {
    client?: StoreExtrasClient;
}): {
    subscribe: (email: string, variant?: string) => Promise<boolean>;
    status: "error" | "sending" | "done" | "idle";
    error: string | null;
};
/** Vistos recientemente (en este navegador). Pasa el producto actual para registrarlo. */
export declare function useRecentlyViewed(currentId?: string | null, opts?: {
    max?: number;
    client?: StoreExtrasClient;
}): {
    ids: string[];
    clear: () => void;
};
/** Productos relacionados del payload en vivo (relación manual `related` y misma categoría). */
export declare function useRelatedProducts<T extends CollectionItem = CollectionItem>(item: T | null | undefined, opts?: {
    collection?: string;
    count?: number;
}): T[];
/**
 * Corazón de favoritos (aria-pressed). Textos de `global.ui` (addToWishlist / removeFromWishlist).
 * Pasa `wishlist` (de useWishlist) si pintas muchos: comparten una sola lista.
 */
export declare function CmsWishlistButton({ productId, wishlist, className, children, }: {
    productId: string;
    wishlist?: ReturnType<typeof useWishlist>;
    className?: string;
    /** Contenido propio (p. ej. un ícono); recibe si está guardado. */
    children?: (saved: boolean) => React.ReactNode;
}): React.JSX.Element;
/** «Avísame cuando llegue» para un producto o variante agotado (correo + trampa para bots). */
export declare function CmsBackInStockForm({ productId, variant, className }: {
    productId: string;
    variant?: string;
    className?: string;
}): React.JSX.Element;
