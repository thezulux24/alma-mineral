/**
 * Checkout completo para storefronts headless React / Next.js (mismo flujo que el carrito de /site):
 * datos del comprador, dirección, envío a domicilio o retiro en tienda, franja de entrega, opciones
 * de envío por zona, métodos de pago del país (incluidos BNPL), cupones y tarjetas de regalo con la
 * cotización del servidor, medición (event_id) y redirección a la pasarela.
 *
 *   <CmsProvider initial={initial} slug="mi-tienda">
 *     <ShopAccountProvider slug="mi-tienda"><CartProvider slug="mi-tienda">…</CartProvider></ShopAccountProvider>
 *   </CmsProvider>
 *
 *   const co = useCheckout();
 *   <input value={co.form.customerEmail} onChange={(e) => co.setField('customerEmail', e.target.value)} />
 *   co.shipping.options.map((o) => …co.shipping.select(o.id))
 *   co.paymentMethods.map((m) => …co.setProvider(m.id))
 *   <CmsPricingTotals pricing={co.pricing} />
 *   <button disabled={co.submitting} onClick={co.submit}>…</button>
 *
 *   // página de retorno de la pasarela:
 *   const ret = usePaymentReturn();   // ret.status: 'checking' | 'paid' | 'failed' | 'pending' | 'none'
 *
 * Todos los textos salen de `global.ui` (useShopUi); el total final siempre lo calcula el servidor.
 */
import React from 'react';
import { ShopError, type ShopCheckoutItem, type ShopCheckoutOptionsConfig, type ShopCheckoutResult, type ShopClient, type ShopConfirmResult, type ShopDeliverySlot, type ShopFulfillment, type ShopPaymentOption, type ShopPricing, type ShopPublicConfig, type ShopRetryResult } from '../shop.js';
import type { ShopUi } from '../ui.js';
import { type CartCodeResult } from './cart.js';
import { type UseShippingOptionsValue } from './shipping.js';
export interface ShopSourceOptions {
    client?: ShopClient;
    slug?: string;
    apiUrl?: string;
}
/**
 * Cliente de la tienda del árbol: el que pases, el del <CartProvider>, el del <ShopAccountProvider>
 * o uno nuevo con el slug y la URL del <CmsProvider>. null si no hay de dónde sacarlo.
 */
export declare function useShopClient(opts?: ShopSourceOptions): ShopClient | null;
/** Vacía la caché de `useShopConfig` (pruebas, o tras cambiar la tienda en el portal). */
export declare function clearShopConfigCache(): void;
export interface UseShopConfig {
    config: ShopPublicConfig | null;
    loading: boolean;
    error: ShopError | null;
    reload(): Promise<ShopPublicConfig | null>;
}
/** Config pública de la tienda (métodos de pago, envío, extras, moneda), una sola petición por tienda. */
export declare function useShopConfig(opts?: ShopSourceOptions & {
    config?: ShopPublicConfig | null;
}): UseShopConfig;
export interface UsePaymentMethods {
    /** Métodos del país de la tienda, en su orden; los BNPL fuera de rango con `available: false`. */
    options: ShopPaymentOption[];
    /** Solo los que se pueden elegir con el monto actual. */
    available: ShopPaymentOption[];
    config: ShopPublicConfig | null;
    loading: boolean;
}
/** Métodos de pago para el selector del checkout (`paymentOptions` con la config de la tienda). */
export declare function usePaymentMethods(opts?: ShopSourceOptions & {
    amount?: number;
    country?: 'CO' | 'MX' | null;
    config?: ShopPublicConfig | null;
}): UsePaymentMethods;
export interface CheckoutForm {
    customerName: string;
    customerEmail: string;
    customerPhone: string;
    documentType: string;
    documentId: string;
    address: string;
    city: string;
    department: string;
    country: string;
    postalCode: string;
    daneCode: string;
    /** Indicaciones para la entrega (van en `shippingAddress.notes`). */
    notes: string;
}
export type CheckoutErrors = Partial<Record<keyof CheckoutForm | 'provider' | 'shipping' | 'pickup' | 'deliverySlot' | 'pricing' | 'items', string>>;
export interface UseCheckoutOptions extends ShopSourceOptions {
    /** Líneas si no usas <CartProvider> (por defecto, las del carrito). */
    items?: ShopCheckoutItem[];
    /** Cupones y tarjetas sin <CartProvider>. */
    couponCodes?: string[];
    giftCardCodes?: string[];
    /** Valores iniciales (por defecto, los del cliente con sesión y su dirección predeterminada). */
    initial?: Partial<CheckoutForm>;
    /** Vuelta tras pagar (por defecto la página actual); debe ser un origen permitido del proyecto. */
    redirectUrl?: string;
    /** true (por defecto): con `checkoutUrl` lleva al comprador a la pasarela. */
    autoRedirect?: boolean;
    /** Guarda la dirección en la cuenta del cliente. */
    saveAddress?: boolean;
    /** Espera antes de re-cotizar (ms, por defecto 300). */
    quoteDelayMs?: number;
    /** Config ya cargada (evita la petición). */
    config?: ShopPublicConfig | null;
    /** Rótulos propios (por defecto global.ui). */
    labels?: Partial<ShopUi>;
}
export interface UseCheckout {
    form: CheckoutForm;
    setField<K extends keyof CheckoutForm>(key: K, value: CheckoutForm[K]): void;
    setForm(patch: Partial<CheckoutForm>): void;
    config: ShopPublicConfig | null;
    /** Retiro, franjas y notas que ofrece la tienda. */
    options: ShopCheckoutOptionsConfig & {
        deliveryDates: string[];
    };
    fulfillment: ShopFulfillment;
    setFulfillment(f: ShopFulfillment): void;
    pickupLocationId: string;
    setPickupLocation(id: string): void;
    deliverySlot: Partial<ShopDeliverySlot>;
    setDeliverySlot(slot: Partial<ShopDeliverySlot>): void;
    /** Opciones de envío por zona (vacías con retiro en tienda). */
    shipping: UseShippingOptionsValue;
    paymentMethods: ShopPaymentOption[];
    provider: string;
    setProvider(id: string): void;
    /** El comprador aceptó recordatorios del carrito (se guarda con el contacto). */
    reminderConsent: boolean;
    setReminderConsent(v: boolean): void;
    couponCodes: string[];
    giftCardCodes: string[];
    applyCoupon(code: string): Promise<CartCodeResult>;
    removeCoupon(code: string): void;
    applyGiftCard(code: string): Promise<CartCodeResult>;
    removeGiftCard(code: string): void;
    /** Cotización del servidor con envío, retiro, método de pago, cupones y tarjetas. */
    pricing: ShopPricing | null;
    quoting: boolean;
    /** Errores por campo de la última validación. */
    errors: CheckoutErrors;
    validate(): CheckoutErrors;
    submitting: boolean;
    error: string | null;
    result: ShopCheckoutResult | null;
    /** Instrucciones de pago (transferencia, contraentrega) del resultado. */
    instructions: string;
    /** event_id del último intento (el mismo del Purchase de la API de conversiones si es contraentrega). */
    eventId: string | null;
    /** Crea el pedido; null si la validación falla o el servidor lo rechaza (ver `errors` / `error`). */
    submit(e?: {
        preventDefault?: () => void;
    }): Promise<ShopCheckoutResult | null>;
    reset(): void;
    client: ShopClient | null;
}
export declare function useCheckout(opts?: UseCheckoutOptions): UseCheckout;
export interface UsePaymentReturn {
    /** none: no hay pago pendiente en este navegador. */
    status: 'none' | 'checking' | 'paid' | 'failed' | 'pending' | 'error';
    result: ShopConfirmResult | null;
    error: ShopError | null;
    orderNumber: string | null;
    /** Nuevo intento de pago (pedido rechazado o pendiente): lleva a la pasarela salvo `redirect: false`. */
    retry(opts?: {
        email?: string;
        redirectUrl?: string;
        redirect?: boolean;
    }): Promise<ShopRetryResult | null>;
    /** Vuelve a consultar el estado. */
    check(): Promise<ShopConfirmResult | null>;
}
/**
 * Página de retorno de Wompi, MercadoPago, Bold, Stripe o BNPL: lee la URL (`readPaymentReturn`),
 * confirma con el backend y sondea hasta que el pago deja de estar pendiente (`resumePayment`).
 * Emite `purchase` cuando el servidor responde PAID.
 */
export declare function usePaymentReturn(opts?: ShopSourceOptions & {
    search?: string;
    intervalMs?: number;
    timeoutMs?: number;
    auto?: boolean;
}): UsePaymentReturn;
export interface CmsPricingTotalsProps {
    pricing: ShopPricing | null | undefined;
    /** Respaldo sin cotización: subtotal y envío estimados. */
    subtotal?: number;
    shipping?: number;
    loading?: boolean;
    className?: string;
    labels?: Partial<ShopUi>;
}
/**
 * Resumen de totales sin estilos propios (`<dl data-cms-totals>`): descuentos, envío, impuestos
 * incluidos o agregados, tarjetas de regalo, total a pagar, pedido mínimo y límites por cliente.
 */
export declare function CmsPricingTotals({ pricing, subtotal, shipping, loading, className, labels }: CmsPricingTotalsProps): React.JSX.Element;
/**
 * Botón «Pedir por WhatsApp» del carrito: crea el pedido PENDING_WHATSAPP con los precios del
 * servidor y abre wa.me. Solo se pinta si la tienda lo activó (`globalData.site.whatsappOrders`).
 */
export declare function CmsWhatsAppOrderButton({ className, onError, keepCart, children }: {
    className?: string;
    onError?: (e: Error) => void;
    keepCart?: boolean;
    children?: React.ReactNode;
}): React.JSX.Element | null;
