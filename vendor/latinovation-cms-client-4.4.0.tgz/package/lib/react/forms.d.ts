import { type CookieBannerConfig } from '../consent.js';
import { type LeadInput, type LeadResult } from '../leads.js';
import { type ConsentState } from '../tracking/core.js';
export interface UseLeadForm {
    status: 'idle' | 'sending' | 'done' | 'error';
    error: string | null;
    result: LeadResult | null;
    submit(input: Omit<LeadInput, 'slug' | 'apiUrl'>): Promise<LeadResult | null>;
    reset(): void;
}
/** Envía leads a `POST /api/public/leads/:slug` (con `generate_lead` y el contexto para Meta). */
export declare function useLeadForm(opts?: {
    formId?: string;
    formName?: string;
    slug?: string;
    apiUrl?: string;
    fetch?: typeof fetch;
}): UseLeadForm;
export interface UseTrackingConsent {
    /** granted | denied | pending (aún no decide). `pending` también en SSR. */
    state: ConsentState;
    /** El banner está activo y el visitante no ha decidido. */
    visible: boolean;
    banner: CookieBannerConfig;
    accept(): void;
    reject(): void;
}
/** Banner de cookies headless: mismo almacenamiento y evento que el renderer (la medición reacciona sola). */
export declare function useTrackingConsent(opts?: {
    slug?: string;
}): UseTrackingConsent;
