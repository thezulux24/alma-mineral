import type { ShopAddress, ShopAddressInput, ShopAuthResult, ShopClient, ShopCustomer, ShopError, ShopOrder, ShopOrderSummary, ShopProfilePatch, ShopRegisterInput, ShopRetryResult, ShopReturnRequest, ShopTrackResult } from '../shop.js';
import type { DigitalDownload } from '../store-extras.js';
import { type ShopSourceOptions } from './checkout.js';
type Section = 'orders' | 'returns' | 'downloads' | 'addresses';
interface ListState<T> {
    items: T[];
    loading: boolean;
    error: ShopError | null;
}
export interface UseCustomerAccount {
    customer: ShopCustomer | null;
    /** Validando la sesión guardada. */
    loading: boolean;
    /** Hay sesión de cliente. */
    signedIn: boolean;
    login(input: {
        email: string;
        password: string;
    }): Promise<ShopCustomer>;
    register(input: ShopRegisterInput): Promise<ShopAuthResult & {
        claimedOrders: string[];
    }>;
    logout(): void;
    logoutAll(): Promise<void>;
    /** Envía el correo para restablecer (siempre responde `sent: true`). */
    forgotPassword(email: string, resetUrl?: string): Promise<{
        sent: boolean;
    }>;
    /** Restablece con el token del enlace (`?token=` en /cuenta/restablecer) e inicia sesión. */
    resetPassword(token: string, password: string): Promise<ShopCustomer>;
    updateProfile(patch: ShopProfilePatch): Promise<ShopCustomer>;
    changePassword(currentPassword: string, newPassword: string): Promise<void>;
    deleteAccount(password: string): Promise<void>;
    addresses: ListState<ShopAddress> & {
        load(): Promise<void>;
        add(a: ShopAddressInput): Promise<ShopAddress[]>;
        update(id: string, patch: Partial<ShopAddressInput>): Promise<ShopAddress[]>;
        remove(id: string): Promise<ShopAddress[]>;
    };
    orders: ListState<ShopOrderSummary> & {
        page: number;
        totalPages: number;
        total: number;
        load(page?: number): Promise<void>;
    };
    getOrder(orderNumber: string): Promise<ShopOrder>;
    /** Nuevo intento de pago de un pedido rechazado o pendiente (lleva a la pasarela salvo `redirect: false`). */
    retryPayment(orderNumber: string, opts?: {
        redirectUrl?: string;
        redirect?: boolean;
    }): Promise<ShopRetryResult>;
    returns: ListState<ShopReturnRequest> & {
        load(): Promise<void>;
    };
    /** «Solicitar devolución» de un pedido pagado; `items` vacío = el pedido completo. */
    requestReturn(orderNumber: string, input: {
        reason: string;
        items?: Array<{
            lineId: string;
            quantity: number;
        }>;
        note?: string;
    }): Promise<ShopReturnRequest>;
    downloads: ListState<DigitalDownload> & {
        load(): Promise<void>;
    };
    client: ShopClient;
}
/** Cuenta completa del cliente. `load` elige qué listas se cargan solas al tener sesión. */
export declare function useCustomerAccount(opts?: {
    load?: Section[];
    pageSize?: number;
}): UseCustomerAccount;
/**
 * Detalle de un pedido con su rastreo. Con sesión lee el pedido de la cuenta (líneas con `lineId`
 * para devoluciones); el rastreo (`shipments`, eventos normalizados) es el público por número.
 */
export declare function useOrder(orderNumber: string | null | undefined, opts?: ShopSourceOptions & {
    tracking?: boolean;
}): {
    order: ShopOrder | null;
    tracking: ShopTrackResult | null;
    shipments: import("../shop.js").ShopShipment[];
    loading: boolean;
    error: ShopError | null;
    reload: () => Promise<void>;
};
/** Rastreo público por número de pedido o de guía (formulario «Rastrear pedido»). */
export declare function useOrderTracking(opts?: ShopSourceOptions): {
    track: (code: string) => Promise<ShopTrackResult | null>;
    result: ShopTrackResult | null;
    loading: boolean;
    error: ShopError | null;
    notFound: boolean;
};
/**
 * Descargas digitales: las de la cuenta (con sesión) o las de un pedido de invitado
 * (`orderNumber` + correo de la compra). Cada llamada trae enlaces firmados nuevos.
 */
export declare function useDownloads(opts?: {
    orderNumber?: string;
    email?: string;
    auto?: boolean;
}): {
    items: DigitalDownload[];
    pendingPayment: boolean;
    loading: boolean;
    error: Error | null;
    reload: () => Promise<void>;
};
export {};
