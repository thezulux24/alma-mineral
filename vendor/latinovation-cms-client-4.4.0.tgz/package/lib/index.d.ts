/**
 * @latinovation/cms-client — SDK para sitios y storefronts que consumen WebProAI / Latinovation CMS.
 *
 *   import { fetchDelivery, getSections, getProducts, buildSectionCss } from '@latinovation/cms-client';
 *   import { CmsProvider, CmsPage, CmsText, CmsImage } from '@latinovation/cms-client/react';
 *   import { auditEditability } from '@latinovation/cms-client/audit';
 *   import { createShopClient } from '@latinovation/cms-client';   // tienda + cuentas de cliente (v4.2)
 *   import { track, resolveTracking } from '@latinovation/cms-client'; // medición (v5, docs/TRACKING.md)
 *   import { createStoreExtrasClient } from '@latinovation/cms-client'; // reseñas, favoritos, avisos (v5 F2)
 *   import { pricingRows, paymentOptions, resolveShopUi, submitLead } from '@latinovation/cms-client'; // v4.4
 */
export * from './types.js';
export * from './delivery.js';
export * from './live.js';
export * from './paths.js';
export * from './fields.js';
export * from './attrs.js';
export * from './css.js';
export * from './design-system.js';
export * from './collections.js';
export * from './dom.js';
export { BUILDER_CSS } from './builder-css.js';
export { BLOCK_SCHEMAS, CATALOG_VERSION } from './catalog.js';
export * from './shop.js';
export * from './tracking/core.js';
export * from './cart.js';
export * from './store-extras.js';
export * from './ui.js';
export * from './leads.js';
export * from './consent.js';
