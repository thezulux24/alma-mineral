import type { BlockSchema } from './types.js';
export declare const CATALOG_VERSION = 1;
export declare const BLOCK_SCHEMAS: Record<string, BlockSchema>;
