import { type ShopStorage } from './shop.js';
export interface CartLine {
    productId: string;
    title: string;
    /** Solo para mostrar mientras llega la cotización; el servidor usa el precio del catálogo. */
    unitPrice: number;
    quantity: number;
    variant?: string;
    imageUrl?: string;
    collectionSlug?: string;
    sku?: string;
}
/** Lo que recibe `add()`: título y precio son opcionales (el servidor cotiza con el catálogo). */
export type CartLineInput = Omit<CartLine, 'quantity' | 'title' | 'unitPrice'> & {
    title?: string;
    unitPrice?: number;
    quantity?: number;
};
export interface CartContact {
    email?: string;
    phone?: string;
    name?: string;
    /** El comprador aceptó que le recuerden el carrito (la tienda puede exigirlo: requireConsent). */
    consent?: boolean;
}
export interface CartRecovery {
    cartKey: string;
    items: CartLine[];
    currency: string;
    subtotal: number;
    email: string | null;
    phone: string | null;
    name: string | null;
    /** Cupón configurado en la secuencia de recuperación (o null). */
    couponCode: string | null;
    /** El carrito ya terminó en un pedido. */
    alreadyOrdered: boolean;
}
export interface CartOptions {
    slug: string;
    apiUrl?: string;
    /** Por defecto localStorage si existe; `null` = solo memoria. */
    storage?: ShopStorage | null;
    fetch?: typeof fetch;
    /** Espera antes de sincronizar con el CMS (ms). Por defecto 1500. */
    debounceMs?: number;
    /** `false` desactiva la sincronización (el carrito sigue funcionando en el navegador). */
    sync?: boolean;
    /** Origen del guardado (`sdk` por defecto). */
    source?: 'site' | 'sdk';
}
export interface Cart {
    readonly slug: string;
    readonly items: CartLine[];
    readonly count: number;
    readonly subtotal: number;
    readonly contact: CartContact;
    /** Cupones del carrito (docs/PRICING.md); el servidor los valida al cotizar y al crear el pedido. */
    readonly couponCodes: string[];
    /** Tarjetas de regalo del carrito. */
    readonly giftCardCodes: string[];
    /** Clave aleatoria de este carrito (la envía el sincronizador). */
    readonly cartKey: string;
    /** `quantity` (o `line.quantity`) por defecto 1; misma línea (producto + variante) suma cantidades. */
    add(line: CartLineInput, quantity?: number): void;
    setQuantity(index: number, quantity: number): void;
    remove(index: number): void;
    clear(): void;
    /** Reemplaza cupones o tarjetas de regalo (en MAYÚSCULAS, sin espacios). */
    setCodes(codes: {
        couponCodes?: string[];
        giftCardCodes?: string[];
    }): void;
    /** Datos de contacto del checkout: con correo o teléfono el carrito se guarda en el CMS. */
    setContact(contact: CartContact): void;
    /** Sincroniza ya (sin esperar el debounce). */
    flush(): Promise<void>;
    /** Restaura el carrito del enlace firmado; reemplaza los ítems locales. */
    recover(token: string): Promise<CartRecovery>;
    /** Lee `?token=` de la URL actual y restaura; null si no hay token. */
    recoverFromUrl(search?: string): Promise<CartRecovery | null>;
    /** Avisa cada vez que cambian ítems o contacto. */
    subscribe(listener: () => void): () => void;
}
/** Código de cupón o tarjeta normalizado (MAYÚSCULAS, sin espacios). */
export declare const normalizeCode: (c: string) => string;
/** Token del enlace de recuperación en la URL (`?token=`). */
export declare function readCartRecoveryToken(search?: string): string | null;
export declare function createCart(opts: CartOptions): Cart;
export interface WhatsAppOrderInput {
    slug: string;
    apiUrl?: string;
    fetch?: typeof fetch;
    items: Array<Pick<CartLine, 'productId' | 'quantity' | 'variant'>>;
    customerName?: string;
    customerPhone?: string;
    customerEmail?: string;
    notes?: string;
    shippingAddress?: {
        address?: string;
        city?: string;
        department?: string;
        country?: string;
        postalCode?: string;
        daneCode?: string;
        notes?: string;
    };
    shippingZoneId?: string;
    /** v5 F2.9: opción de `quoteShipping()` (el servidor la re-cotiza). */
    shippingOptionId?: string;
    /** v5 F2 (docs/PRICING.md): el pedido se cotiza con cupones e impuestos igual que el checkout. */
    couponCodes?: string[];
    giftCardCodes?: string[];
}
export interface WhatsAppOrderResult {
    orderNumber: string;
    /** PENDING_WHATSAPP; PROCESSING si una tarjeta de regalo cubrió todo. */
    status: 'PENDING_WHATSAPP' | (string & {});
    paymentStatus?: string;
    /** Lo que falta por pagar (total − tarjetas de regalo). */
    totalAmount: number;
    subtotal: number;
    shippingCost: number;
    discountAmount?: number;
    taxAmount?: number;
    giftCardAmount?: number;
    currency: string;
    /** Desglose del servidor (descuentos, impuestos, tarjetas). */
    pricing?: unknown;
    /** Página para ver el pedido (?pedido=ORD-…). */
    orderUrl: string;
    /** Mensaje prellenado (ítems, total y link). */
    message: string;
    /** https://wa.me/<número de la tienda>?text=… */
    whatsappUrl: string;
    claimToken?: string;
}
/**
 * «Pedir por WhatsApp»: crea el pedido en el CMS (estado PENDING_WHATSAPP, precios del servidor) y
 * devuelve el enlace wa.me con el mensaje listo. La tienda debe tenerlo activo
 * (globalData.site.whatsappOrders.enabled) y un número de WhatsApp en el sitio.
 */
export declare function buildWhatsAppOrder(input: WhatsAppOrderInput): Promise<WhatsAppOrderResult>;
/** Mensaje de pedido sin crear pedido (alternativa sin API): `wa.me` con ítems y total estimado. */
export declare function whatsappOrderText(items: CartLine[], opts?: {
    intro?: string;
    currency?: string;
    locale?: string;
}): string;
export declare function waMeUrl(number: string, text: string): string;
/** `globalData.site.whatsappOrders` del delivery: si mostrar «Pedir por WhatsApp» en la ficha y el carrito. */
export declare function whatsappOrdersConfig(global: Record<string, any> | null | undefined): {
    enabled: boolean;
    product: boolean;
    cart: boolean;
    number: string;
    intro: string;
};
/**
 * Baja de los recordatorios de carrito desde un storefront headless (el token es el del enlace de
 * baja del correo o del WhatsApp). Responde 404 si el enlace no es válido.
 */
export declare function unsubscribeCartReminders(input: {
    slug: string;
    token: string;
    apiUrl?: string;
    fetch?: typeof fetch;
}): Promise<{
    unsubscribed: true;
    [k: string]: unknown;
}>;
