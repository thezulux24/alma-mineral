export interface CookieBannerConfig {
    enabled: boolean;
    text: string;
    acceptLabel: string;
    rejectLabel: string;
    policyLabel: string;
    policyHref: string;
}
/** `globalData.site.cookieBanner` con los mismos textos por defecto del renderer (y `global.ui`). */
export declare function cookieBannerConfig(global: Record<string, any> | null | undefined): CookieBannerConfig;
/**
 * Guarda la decisión del visitante (`bk-cookies:<slug>` = accepted | rejected) y emite
 * `cms:cookie-consent`, que `initTracking` / `<CmsTracking>` escuchan para cargar o frenar píxeles.
 */
export declare function saveConsent(slug: string, granted: boolean): void;
