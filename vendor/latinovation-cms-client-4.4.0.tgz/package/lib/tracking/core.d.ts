/**
 * Medición (v5 F1.1, docs/TRACKING.md): píxeles y etiquetas reales con consentimiento.
 *
 * Fuente única del despachador: la usan el renderer de /site/[slug] (copia en
 * frontend/src/sdk-generated/tracking, ver frontend/scripts/sync-sdk.mjs) y los storefronts headless
 * (`CmsTracking` / `useTrack` en `@latinovation/cms-client/react`). Sin dependencias: solo DOM.
 *
 *   const cfg = resolveTracking(payload.global, payload.seo);       // globalData.site.tracking (+ seoConfig viejo)
 *   const t = initTracking({ config: cfg, slug: 'demo', apiBase: 'https://webproai.tech' });
 *   t.scripts → [{ provider: 'ga4', id, src }]   // el cargador (next/script o DOM) los inserta
 *   track('add_to_cart', { value: 89000, currency: 'COP', items: [{ item_id: 'i1', item_name: 'Creatina' }] });
 *
 * Consentimiento (globalData.site.tracking.consentMode):
 *   - gdpr:    Google carga con Consent Mode v2 en "denied" hasta aceptar; Meta, TikTok y Clarity solo tras aceptar.
 *   - opt-out: todo carga con consentimiento concedido; si el visitante rechaza, se revoca.
 *   - none:    todo carga, sin señales de consentimiento.
 * El banner de cookies del sitio guarda la decisión en localStorage `bk-cookies:<slug>` y emite el
 * evento `cms:cookie-consent` (detail: 'accepted' | 'rejected'); un sitio headless puede emitir el
 * mismo evento o llamar a `setTrackingConsent(true|false)`.
 */
export type TrackingProvider = 'ga4' | 'gtm' | 'googleAds' | 'meta' | 'tiktok' | 'clarity';
export type ConsentMode = 'gdpr' | 'opt-out' | 'none';
export type ConsentState = 'granted' | 'denied' | 'pending';
export interface TrackingConfig {
    ga4?: string;
    gtm?: string;
    metaPixel?: string;
    tiktokPixel?: string;
    googleAds?: {
        id?: string;
        purchaseLabel?: string;
        leadLabel?: string;
    };
    clarity?: string;
    consentMode: ConsentMode;
}
export type StandardEvent = 'page_view' | 'view_item' | 'add_to_cart' | 'begin_checkout' | 'purchase' | 'generate_lead' | 'contact' | 'schedule';
export interface TrackItem {
    item_id: string;
    item_name?: string;
    item_variant?: string;
    item_category?: string;
    price?: number;
    quantity?: number;
}
export interface TrackParams {
    value?: number;
    currency?: string;
    /** Número de pedido en `purchase` (también es el event_id que deduplica con la API de conversiones). */
    transaction_id?: string;
    items?: TrackItem[];
    /** `contact`: 'whatsapp' | 'phone' | 'email'. `generate_lead`: id del formulario. */
    method?: string;
    form_id?: string;
    page_path?: string;
    page_location?: string;
    page_title?: string;
    /** Id del evento para deduplicar navegador ↔ servidor (se genera si falta). */
    event_id?: string;
    [key: string]: unknown;
}
export interface TrackingScript {
    provider: TrackingProvider;
    /** id estable del <script> (cms-trk-<proveedor>). */
    id: string;
    src: string;
}
/** Validación de ids (la misma que aplica el backend al guardar, backend/src/tracking/tracking-config.ts). */
export declare const TRACKING_ID_PATTERNS: {
    readonly ga4: RegExp;
    readonly gtm: RegExp;
    readonly metaPixel: RegExp;
    readonly tiktokPixel: RegExp;
    readonly googleAdsId: RegExp;
    readonly googleAdsLabel: RegExp;
    readonly clarity: RegExp;
};
/**
 * Configuración de medición a partir de los globales del delivery: `global.site.tracking` y, como
 * respaldo, los campos viejos `seo.googleTagManagerId` / `seo.metaPixelId`. Ids inválidos se ignoran.
 * Devuelve null si no hay ningún proveedor configurado.
 */
export declare function resolveTracking(global: unknown, seo?: unknown): TrackingConfig | null;
/** Proveedores con id en la configuración. */
export declare function configuredProviders(cfg: TrackingConfig | null | undefined): TrackingProvider[];
export declare const consentStorageKey: (slug: string) => string;
/** Decisión guardada por el banner de cookies: granted | denied | pending (aún no decide). */
export declare function readConsent(slug: string): ConsentState;
/** Consentimiento efectivo según el modo: `none` siempre concede; `opt-out` concede hasta que rechacen. */
export declare function effectiveConsent(mode: ConsentMode, state: ConsentState): 'granted' | 'denied';
/** Proveedores que pueden cargarse ahora: Google siempre (Consent Mode decide qué guarda); el resto con consentimiento. */
export declare function allowedProviders(cfg: TrackingConfig | null, state: ConsentState): TrackingProvider[];
export declare const META_EVENTS: Record<StandardEvent, string>;
/** TikTok: `page_view` usa ttq.page(). */
export declare const TIKTOK_EVENTS: Record<Exclude<StandardEvent, 'page_view'>, string>;
/** Parámetros de Meta (ViewContent/AddToCart/…): content_ids, contents, value, currency. */
export declare function metaParams(event: StandardEvent, p: TrackParams): Record<string, unknown>;
/** Parámetros de TikTok: contents [{ content_id, content_name, quantity, price }], value, currency. */
export declare function tiktokParams(p: TrackParams): Record<string, unknown>;
export interface TrackLogEntry {
    event: StandardEvent;
    eventId: string;
    providers: TrackingProvider[];
    params: TrackParams;
    at: number;
}
/** Id de evento para deduplicar (navegador ↔ API de conversiones). */
export declare function newEventId(prefix?: string): string;
export interface InitTrackingOptions {
    config: TrackingConfig | null;
    slug: string;
    /** URL del CMS para el aviso "vimos un evento" (`POST /api/public/tracking/:slug/seen`). Vacío: sin aviso. */
    apiBase?: string;
    /** Sin medición (editor, vista previa). */
    disabled?: boolean;
}
export interface TrackingHandle {
    scripts: TrackingScript[];
    /** Avisa cuando cambian los scripts a cargar (p. ej. tras aceptar cookies). Devuelve la baja. */
    onScripts(fn: (scripts: TrackingScript[]) => void): () => void;
    /** El cargador lo llama en el `onload` del script. */
    markLoaded(provider: TrackingProvider): void;
    destroy(): void;
}
/**
 * Instala el rastreador en `window` (idempotente por proyecto) y aplica el consentimiento guardado.
 * Devuelve los scripts que el cargador debe insertar.
 */
export declare function initTracking(opts: InitTrackingOptions): TrackingHandle;
/**
 * Cambia el consentimiento (lo llama el banner vía `cms:cookie-consent`, o un sitio headless).
 * Al aceptar se cargan Meta/TikTok/Clarity y reciben el page_view de la página actual.
 */
export declare function setTrackingConsent(granted: boolean): void;
/**
 * Envía un evento estándar a todos los proveedores activos con su nombre propio
 * (Meta: PageView/ViewContent/AddToCart/InitiateCheckout/Purchase/Lead/Contact; TikTok equivalentes).
 * Devuelve el event_id (pásalo al backend para deduplicar con la API de conversiones).
 * `purchase` se envía una sola vez por transaction_id en este navegador. Sin rastreador: no hace nada.
 */
export declare function track(event: StandardEvent, params?: TrackParams): string;
/** Últimos eventos despachados (para depurar y para pruebas). */
export declare function trackingLog(): TrackLogEntry[];
/** Proveedores activos ahora mismo. */
export declare function activeProviders(): TrackingProvider[];
/** Contraentrega: la compra cuenta al hacer el pedido (no hay pago en línea que confirmar). */
export declare function purchaseOnPlacement(provider: unknown): boolean;
/**
 * Parámetros de begin_checkout / purchase desde la respuesta del checkout o de confirm-order
 * (precios calculados por el servidor). Con `purchase`, transaction_id = número de pedido.
 */
export declare function orderTrackParams(order: Record<string, any> | null | undefined, purchase: boolean): TrackParams;
export interface TrackingContext {
    eventId?: string;
    fbp?: string;
    fbc?: string;
    sourceUrl?: string;
}
/**
 * Datos que el backend necesita para la API de conversiones de Meta: event_id (deduplicación),
 * cookies _fbp/_fbc (o fbclid de la URL) y la URL de origen. Se adjunta como `tracking` en
 * POST /api/public/leads/:slug y en el checkout. Sin consentimiento efectivo no lleva cookies.
 */
export declare function trackingContext(eventId?: string): TrackingContext;
/** Inserta los scripts en <head> (async) y avisa `markLoaded` al cargar. Idempotente por id. */
export declare function loadTrackingScripts(handle: TrackingHandle, scripts?: TrackingScript[]): void;
