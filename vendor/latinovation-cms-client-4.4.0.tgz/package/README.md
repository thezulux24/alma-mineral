# @latinovation/cms-client — cómo hacer un sitio 100 % editable

SDK para sitios y storefronts headless (Next.js, React o JavaScript sin framework) que leen su contenido de WebProAI / Latinovation CMS. Con él, un sitio propio se edita desde `/portal` igual que un sitio renderizado por el CMS: textos en línea, imágenes con la mediateca, enlaces, repetidores, productos, globales y menú, estilos por sección y por elemento, mover, duplicar, borrar y agregar bloques, y pedirle cambios a Art.

| Entrada | Qué trae |
|---|---|
| `@latinovation/cms-client` | Núcleo sin dependencias (servidor o navegador): delivery, páginas, secciones, colecciones, rutas con puntos, CSS de sección, design system, marcado §8.1, puente con el portal y runtime del lienzo. |
| `@latinovation/cms-client/react` | Provider, hooks y primitivos editables (`react >= 18`, peer opcional). Todo es componente cliente y seguro en SSR. |
| `@latinovation/cms-client/audit` | Auditoría de editabilidad (la usa `bin/audit-editability.mjs`). |
| `@latinovation/cms-client/builder.css` | Estilos del editor como archivo (el provider ya los inyecta solo en modo editor). |

Contrato del protocolo: [docs/LIVE-PREVIEW.md](../../docs/LIVE-PREVIEW.md) (§8 es v4.1). Contratos de personalización: [docs/EDITING-V4.1.md](../../docs/EDITING-V4.1.md).

## 1. Instalar

El paquete vive en una subcarpeta del monorepo, así que `npm install github:…` no sirve. Dos opciones:

```bash
# A) tarball (recomendado para repos externos y CI)
cd cms-landings/packages/cms-client && npm pack          # → latinovation-cms-client-4.1.0.tgz
cd ../../../mi-sitio && npm install ../cms-landings/packages/cms-client/latinovation-cms-client-4.1.0.tgz

# B) ruta local, copiando (no enlazando) el paquete
npm install --install-links ../cms-landings/packages/cms-client
# o en package.json: "@latinovation/cms-client": "file:../cms-landings/packages/cms-client" + .npmrc con install-links=true
```

Usa `--install-links` (o el tarball) para que no se cargue la copia de React de desarrollo del SDK: con un enlace simbólico `file:` Next resuelve `react` desde `packages/cms-client/node_modules` y aparecen dos Reacts (errores de hooks). `lib/` está versionado: no hace falta compilar para instalar. Requiere Node 18.17+.

## 2. Montar el provider (Next.js App Router)

```tsx
// app/layout.tsx — Server Component
import { fetchDelivery } from '@latinovation/cms-client';
import { CmsProvider } from '@latinovation/cms-client/react';

export default async function Layout({ children }: { children: React.ReactNode }) {
  const initial = await fetchDelivery({ slug: 'mi-sitio', revalidate: 60 }); // ISR + tag "cms:mi-sitio"
  return (
    <html lang="es">
      <body>
        <CmsProvider initial={initial} slug="mi-sitio" allowedOrigins={['http://localhost:3005']}>
          {children}
        </CmsProvider>
      </body>
    </html>
  );
}
```

`<CmsProvider>`:
- Detecta `?preview=1&builder=1&previewToken=…` del portal, descarga borradores con el token (o `previewToken` como prop) y aplica el estado en vivo (`CMS_LIVE_PREVIEW_STATE`). Acepta mensajes solo de `window.parent` con el origen del CMS o de `allowedOrigins`, y responde a ese origen (nunca `*`).
- Emite las variables `--cms-*` del design system (v2 y campos planos v1), los `<link>` de Google Fonts, los `@font-face` propios y `globalCss` saneado. Desactívalo con `designSystem={false}`.
- Solo en modo editor (dentro del iframe del portal) marca `<html data-cms-builder>`, inyecta los estilos del editor y arranca el runtime del lienzo. Para los visitantes no cambia nada: no hay `contentEditable`, listeners ni toolbars.
- Registra la visita (`trackPageview`, por defecto `true`) fuera del editor.
- `pageSlug` / `pathname` / `basePath`: página activa. `<CmsPage pageSlug>` la fija automáticamente; si usas hooks sueltos en rutas dinámicas pasa `pathname={usePathname()}` desde un componente cliente o `pageSlug="/producto"`.

El sitio debe poder embeberse: no envíes `X-Frame-Options: DENY` y, si usas CSP, `frame-ancestors https://webproai.tech`.

## 3. Renderizar páginas con un registro de bloques

```tsx
// components/Blocks.tsx
'use client'; // los componentes del registro no se pueden pasar desde un Server Component
import { CmsPage, CmsContainer, CmsText, CmsImage, CmsLink, CmsList, CmsRichText, defaultRegistry, type CmsRegistry } from '@latinovation/cms-client/react';

function Hero() {
  return (
    <CmsContainer className="hero">
      <CmsText f="headline" as="h1" />
      <CmsText f="subheadline" as="p" />
      <CmsLink f="primaryCta" className="btn" />
      <CmsImage f="image" priority />
    </CmsContainer>
  );
}

function Faq() {
  return (
    <CmsContainer>
      <CmsText f="heading" as="h2" />
      <CmsList f="items" itemAs="details" renderItem={() => (<><CmsText f="question" as="summary" /><CmsRichText f="answer" /></>)} />
    </CmsContainer>
  );
}

const registry: CmsRegistry = { ...defaultRegistry, hero: Hero, 'faq.accordion': Faq };

export function SitePage({ pageSlug }: { pageSlug: string }) {
  return <CmsPage pageSlug={pageSlug} registry={registry} fallback={GenericSection} />;
}
```

`<CmsPage>` pinta las secciones visibles de la página en el orden del CMS. Cada una queda envuelta en `<CmsSection>`. El componente se busca por **clave de sección** (`hero`), luego por **tipo de bloque** (`hero.split`) y luego por **familia** (`hero`), primero en `registry` y después en `defaultRegistry` (ahí se registran bloques compartidos como `layout.composer` con `registerBlock('layout.composer', ComposerBlock)`). Cada componente recibe `{ section, data, index, pageSlug }`. Sin componente: en el editor aparece un aviso; en público no se pinta nada.

`<CmsSection>` (también utilizable solo, con `s={useSection('hero')}`):
- raíz con `id="cms-section-<key>"`, `data-section-key`, `data-section-id`, `data-cms-block`;
- `<style>` con `buildSectionCss`: `_style` (§8.3: colores, fondo con `overlayOpacity`, paddings, `textAlign`, `fontFamily`, `borderRadius`, `minHeight`, `contentWidth`/`maxWidth` vía `data-cms-container`, `hideOnMobile`/`hideOnDesktop`), `_elementStyles` y `_customCss` saneado y acotado a la sección;
- ancla `_style.anchorId` (o el campo `anchor` del catálogo) para enlaces `#…`;
- en el editor: barra con arrastrar (→ `REORDER_DROP`), nombre, subir/bajar (`MOVE_SECTION`), duplicar, eliminar, agregar bloque después (`OPEN_ADD_BLOCK_MODAL { afterSectionId }`) y Art; resaltado al pasar el mouse por la capa en el portal (`CMS_HOVER_SECTION`).

Usa `<CmsContainer>` (o `data-cms-container`) en el contenedor interno para que `contentWidth` funcione.

## 4. Primitivos editables

Todos emiten siempre los atributos §8.1 (`data-cms-field`, `data-cms-type`, `data-el-id`, `data-cms-item`, `data-cms-global`, `data-cms-nav`) y, en el editor, la acción §8.2 correcta. `f` admite rutas con puntos y es relativa dentro de `<CmsList>` (`/ruta` la vuelve absoluta).

| Componente | Marcado | En el editor |
|---|---|---|
| `<CmsText f as? multiline? format? editable? placeholder?>` | `text` / `textarea` | `contentEditable`; Enter confirma (salvo `multiline`), Esc descarta → `INLINE_FIELD_CHANGE { fieldKey: 'items.2.title' }`. Con `format` se abre el inspector. |
| `<CmsRichText f>` | `richtext` | Markdown seguro; clic → `FOCUS_FIELD richtext`. |
| `<CmsImage f alt? as? priority?>` | `image` | Usa `<campo>Alt` y `<campo>Focal` (→ `object-position`). Insignia “Cambiar imagen”; clic → `FOCUS_FIELD image` (mediateca). `as={Image}` para `next/image`. |
| `<CmsGallery f renderImage?>` | `gallery` | Clic → `FOCUS_FIELD gallery`. |
| `<CmsLink f>` o `<CmsLink labelField hrefField>` | `link` + `f.label` | Etiqueta en línea; botón 🔗 → `FOCUS_FIELD link`. Los enlaces no navegan dentro del editor. |
| `<CmsList f renderItem itemAs? wrap? max?>` | `array` + `item` por elemento | Mini barra subir/bajar/duplicar/agregar/quitar → `ARRAY_ITEM_ACTION`; vacío: “Agregar elemento”. |
| `<CmsField f type?>` | según esquema | Despacha por el tipo del catálogo (o inferido del valor). |
| `<CmsItem item collection?>`, `<CmsItemText item? f format?>`, `<CmsItemImage item? f?>` | `data-cms-item="col:id"` | Texto en línea → `INLINE_COLLECTION_ITEM_CHANGE`; imagen o campo con formato → `FOCUS_COLLECTION_ITEM`. |
| `<CmsAddItem collection? category?>` | — | Solo editor → `CREATE_COLLECTION_ITEM`. |
| `<CmsGlobalText f>`, `<CmsGlobalImage f>` | `data-cms-global` | `INLINE_GLOBAL_CHANGE` / `FOCUS_GLOBAL`. |
| `<CmsNav list>`, `<CmsNavLink link list?>`, `<CmsNavText f promo?>` | `data-cms-nav="2"`, `footer.1`, `headerCtaText`, `promoBanner.title` | `INLINE_NAV_CHANGE` (etiqueta) / `FOCUS_NAV`. |
| `useElementId('tarjeta')` | `data-el-id="<key>::tarjeta"` | Id estable para estilos por elemento en tus propios nodos. |

Los demás elementos de la sección reciben `data-el-id` posicionales (`<key>::div.0>h2.1`, como el renderer del CMS) al montar; al hacer clic se envía `SELECT_SECTION` + `SELECT_ELEMENT` y aparece la barra de estilo por elemento (fondo y opacidad, texto, posición, mover, caja padre, Art, restablecer → `INLINE_ELEMENT_STYLE_CHANGE`). El árbol se envía con `SECTION_DOM_TREE`. Ctrl/Cmd+Z y Ctrl/Cmd+Shift+Z (o Ctrl+Y) → `HISTORY`. Todo cambio se aplica localmente al instante y el portal lo confirma con su estado en vivo.

## 5. Hooks

| Hook | Devuelve |
|---|---|
| `useCms()` | `{ payload, isBuilder, isPreview, pageSlug, slug, cmsUrl, selectedKey, selectedElement, bridge, actions, … }` (más `selectSection`, `commitField`, `commitWidgetField`, `commitGlobal`, `post` de v4.0). |
| `useSection(key)` / `useSection(pageSlug, key)`, `useSections(pageSlug?)`, `useCurrentSection()` | Secciones del payload en vivo. |
| `useProducts(opts)`, `useProduct(slug)`, `useItem(collection, slug)` | Ítems en vivo (reflejan ediciones del portal). |
| `useItemRoute(collection, item, { pattern? })` | `/<routeBase>/<slug>` o el patrón. |
| `useCollectionQuery({ collection, filters, sort, page, pageSize, search })` | `{ items, total, page, pageCount, facets, setFilter, setSearch, setSort, setPage, setQuery, reset }`. Filtros: valor exacto o lista (select), `{ min, max }` (rango), booleano; facetas según `collectionDefinitions[col].filters`. |
| `useGlobal(path, fallback)`, `useNavLinks(list)` | Globales y menú. |
| `useLivePreview(initial, opts)` | El estado del provider sin provider. |
| Tienda (v4.4, §8e) | `useCart`, `useCheckout`, `useShippingOptions`, `usePaymentMethods`, `useShopConfig`, `usePaymentReturn`, `useReviews`, `useReviewInvite`, `useReviewSummaries`, `useWishlist`, `useBackInStock`, `useRelatedProducts`, `useRecentlyViewed`, `useCustomerAccount`, `useOrder`, `useOrderTracking`, `useDownloads`, `useLeadForm`, `useTrackingConsent`, `useShopUi`, `useMoney`, `useTrack`. |

## 6. Núcleo (sin React)

```ts
import {
  fetchDelivery, tryFetchDelivery, getSections, getSection, getProducts, getCategories, formatPrice, mediaUrl,
  pageSlugFromPath, getItemRoute, matchItemRoute, queryCollection, fetchItem,
  getPath, setPath, deletePath, applyArrayOp, imageField, normalizeLink, fieldSchema,
  buildSectionCss, scopeCss, sanitizeCss, sectionAnchor, editAttrs, sectionAttrs,
  designSystemToCssVars, designSystemFontLinks, designSystemToCss,
  createLivePreviewBridge, createBuilderRuntime, applyLiveState, readPreviewParams,
} from '@latinovation/cms-client';
```

| Grupo | Funciones |
|---|---|
| Delivery | `fetchDelivery({ slug \| host, baseUrl, preview, previewToken, revalidate, tags })` (lanza `CmsDeliveryError`), `tryFetchDelivery`, `deliveryUrl`. |
| Páginas | `getPage`, `getSections(p, page, { includeHidden })` (visibles y ordenadas), `getSection`, `findSectionsByBlock`, `pageSlugFromPath(pathname, p, basePath)`. |
| Colecciones | `getCollection`, `getStoreCollectionSlug`, `getProducts`, `getProduct`, `getCategories`, `normalizeProduct`, `productPrice`, `formatPrice`, `getItem`, `getItemRoute`, `matchItemRoute`, `queryCollection`, `fetchItem` (`GET /api/v1/delivery/:slug/collections/:col/:item`). |
| Campos | `getPath`, `setPath`, `deletePath`, `joinPath`, `applyArrayOp`, `imageField` (Alt/Focal §8.4), `galleryField`, `normalizeLink`, `safeHref`, `fieldSchema(block, path)`, `resolveFieldType`, `markdownToHtml`. |
| Estilos | `buildSectionCss(section, { isBuilder })`, `buildSectionsCss`, `buildSectionStyleCss`, `buildElementStylesCss`, `scopeCss`, `sanitizeCss`, `sectionAnchor`. |
| Design system | `designSystemToCssVars(ds)`, `designSystemFontLinks(ds)`, `designSystemFontFaces`, `designSystemToCss(ds, ':root')`. |
| Marcado | `editAttrs({ field, type, item, global, nav, elId })`, `sectionAttrs`, `elementId`, `parseItemAttr`, `parseNavAttr`. |
| Portal | `createLivePreviewBridge` (todas las acciones §3 y §8.2 como métodos), `applyLiveState`, `readPreviewParams`, `applyFieldChange` y demás cambios locales, `createBuilderRuntime({ bridge })`, `tagSectionElements`, `BUILDER_CSS`. |

Sitio sin React: renderiza el HTML con los atributos de `editAttrs`/`sectionAttrs` y en el navegador:

```js
const { builder } = readPreviewParams();
const bridge = createLivePreviewBridge({ cmsUrl: 'https://webproai.tech', onState: (msg) => render(applyLiveState(payload, msg, '/')) });
if (builder && window.parent !== window) {
  document.documentElement.setAttribute('data-cms-builder', '');
  document.head.insertAdjacentHTML('beforeend', `<style>${BUILDER_CSS}</style>`);
  createBuilderRuntime({ bridge }); // clics, edición en línea, FOCUS_*, HISTORY, arrastre, SECTION_DOM_TREE
}
```

## 7. Auditar la editabilidad

```bash
node packages/cms-client/bin/audit-editability.mjs --slug mi-sitio --url https://mi-sitio.com --item-route "/producto/:slug"
# opciones: --min 95 · --json · --pages /,/contacto · --ignore campo,seccion.ruta · --no-extras · --cms https://webproai.tech
```

Hace solo GET públicos: delivery del CMS y el HTML de cada página (más un ítem de muestra por `--item-route` o por `routeBase`). Por cada sección visible compara los campos con valor (esquema del catálogo; sin esquema, inferidos del dato, incluidas referencias a ítems) con el marcado del HTML del servidor; cuenta también globales, menú e ítems de colecciones que se ven en la página. Marca con `*` lo que se ve pero no tiene marcado. Sale con 1 bajo `--min` (95 %) y 2 si no pudo auditar. Los campos de configuración (`tone`, `anchor`, `formName`, `href` sueltos…) no cuentan.

## 8. Revalidar al publicar

Al publicar, el backend hace `POST` a `Project.webhookUrl` con `{ event: 'project.published', projectSlug }` y la cabecera `x-cms-webhook-secret`. Un route handler que verifique el secreto y llame a `revalidateTag('cms:<slug>')` invalida lo que `fetchDelivery` cacheó (ver `examples/next-app/app/api/revalidate/route.ts`).

## 8b. Compositor libre (`layout.composer`)

Secciones armadas por el cliente: filas → columnas (12, ancho por computador/tableta/celular) → 20 tipos de elemento (título, párrafo, texto con formato, imagen, botón, grupo de botones, espacio, separador, video, insertar, ícono, lista, etiqueta, cifra, cita, formulario, colección, mapa, galería, tarjeta). El mismo renderer pinta el sitio del CMS y los headless.

```tsx
import '@latinovation/cms-client/composer/react';   // registra layout.composer en defaultRegistry
<CmsPage pageSlug="/" registry={{ hero: Hero }} />  // las secciones del compositor ya se pintan

// o una sección suelta
import { CmsComposer } from '@latinovation/cms-client/composer/react';
<CmsComposer s={useSection('intro')} />
```

Estilos solo con variables `--cms-*` (incluidos; `styles={false}` + `<ComposerStyles/>` para ponerlos una vez). Sin React: `@latinovation/cms-client/composer/core` (`applyComposerOp`, `validateComposer`, `normalizeComposer`, `ELEMENT_DEFS`, rutas `rows.0.columns.1.elements.2`). En el editor emite `INLINE_FIELD_CHANGE` (ruta con puntos), `FOCUS_FIELD` y `COMPOSER_ACTION { op, path, payload }`.

## 8c. Tienda: checkout, pagos rechazados y cuentas de cliente (v4.2)

Contrato: `docs/SHOP-ACCOUNTS.md`. Las cuentas son por tienda y se activan con `ltn shop config set <slug> --config '{"customerAccounts":{"enabled":true}}'`.

```ts
import { createShopClient, ShopError } from '@latinovation/cms-client';
const shop = createShopClient({ slug: 'arsenal' });             // apiUrl por defecto https://webproai.tech
const { customerAccounts } = await shop.config();
await shop.account.login({ email, password });                   // token en localStorage (clave ltn_shop_arsenal)
const order = await shop.checkout(input, { saveAddress: true }); // Bearer automático; invitado → guarda claimToken
location.href = order.checkoutUrl!;

// al volver de Wompi, SIEMPRE (aprobado o no):
const r = await shop.confirmPayment({ transactionId, orderNumber });
if (r.paymentStatus === 'FAILED' && r.canRetry) location.href = (await shop.retryPayment(r.orderNumber, { email })).checkoutUrl;

try { await shop.track('ORD-…'); } catch (e) { if (e instanceof ShopError && e.code === 'PAYMENT_FAILED') {/* ofrecer reintento */} }
```

`shop.account`: `register` (reclama solas las órdenes de invitado del navegador), `login`, `logout` (local), `logoutAll`, `forgotPassword` (`resetUrl` por defecto `<origen>/cuenta/restablecer`), `resetPassword`, `me`, `update`, `changePassword`, `addresses.{list,add,update,remove}`, `orders.{list,get}`, `deleteAccount`. Un 401 borra el token guardado. Errores: `ShopError { status, code, message, body }` con los códigos del backend (`EMAIL_TAKEN`, `INVALID_CREDENTIALS`, `ACCOUNTS_DISABLED`, `ACCOUNT_REQUIRED`, `OUT_OF_STOCK`, `RETRY_LIMIT`, `PAYMENT_FAILED`).

```tsx
import { ShopAccountProvider, useShopAccount } from '@latinovation/cms-client/react';
<ShopAccountProvider slug="arsenal">{children}</ShopAccountProvider>
const { customer, loading, login, register, logout, refresh, client } = useShopAccount();
```

Los pedidos con pago rechazado (`PAYMENT_FAILED`) no se rastrean: `track` responde 409 sin datos del comprador; ofrece "Reintentar pago".

### Carrito, cupones, tarjetas de regalo e impuestos (v5, docs/PRICING.md)

El total siempre lo calcula el servidor (descuentos → envío → impuestos → tarjetas de regalo):

```ts
const pricing = await shop.quote({ items, codes: ['BIEN10'], giftCardCodes: [], customerEmail });
const v = await shop.validateDiscount('BIEN10', { items }); // { valid, applied, message, pricing }
await shop.checkout({ ...datos, items, couponCodes: ['BIEN10'], giftCardCodes: ['ABCD-…'] });
formatMoney(pricing.amountDue, pricing.currency, pricing.locale); // COP sin decimales, MXN con 2
```

```tsx
import { CartProvider, useCart } from '@latinovation/cms-client/react';
<CartProvider slug="arsenal">{children}</CartProvider>
const { items, add, setQuantity, remove, applyCoupon, removeCoupon, applyGiftCard, removeGiftCard, pricing, loading, checkout } = useCart();
const r = await applyCoupon('BIEN10'); // { ok, applied, message } — message en español si no aplica
```

`pricing` trae `discounts[]`, `taxes[]` (`inclusive: true` = "IVA incluido"), `giftCards[]`, `total` y `amountDue` (lo que se cobra). El carrito se guarda en `localStorage` (`ltn_cart_<slug>`) y se vacía cuando el pedido se crea. Muestra el precio tachado con `compareAtPrice` del producto cuando es mayor que `price`.

## 8d. Rastreo de envíos (v4.3)

Contrato: `docs/LOGISTICS.md`. Con Dropi, Interrapidísimo o un webhook (Venndelo, Mastershop…) conectados, `track()` trae los envíos del pedido con estado normalizado y eventos; el pedido puede quedar en `SHIPPING_EXCEPTION` (novedad) o `RETURNED`.

```ts
import { createShopClient, shipmentStatusLabel, orderStatusLabel, isShipmentFinal } from '@latinovation/cms-client';
const t = await shop.track('ORD-…');                   // o el número de guía
orderStatusLabel(t.status);                             // "Novedad en la entrega", "Devuelto", "En reparto"…
for (const s of t.shipments ?? []) {
  // s: { carrier, trackingNumber, trackingUrl, status: ShipmentStatus, events: [{ timestamp, status, title, location, description }] }
  console.log(s.carrier, s.trackingNumber, shipmentStatusLabel(s.status), isShipmentFinal(s.status));
}
```

`ShipmentStatus`: `DRAFT | CREATED | LABEL_CREATED | PICKED_UP | IN_TRANSIT | OUT_FOR_DELIVERY | DELIVERED | EXCEPTION | RETURNING | RETURNED | CANCELLED` (`SHIPMENT_STATUSES`). `shipmentStatusLabel(status, 'en')` da la versión en inglés. Los textos de la página de rastreo deben seguir saliendo del CMS (campos); las etiquetas sirven para el estado dinámico.

## 8e. Storefront headless completo (v4.4)

Todo lo que hace el carrito de `/site` (docs/PRICING.md, PAYMENTS.md, LOGISTICS.md §8, REVIEWS-AND-CHANNELS.md, ABANDONED-CART.md, WHATSAPP.md, TRACKING.md, SHOP-ACCOUNTS.md) tiene hook o función. Árbol recomendado:

```tsx
<CmsProvider initial={initial} slug="mi-tienda">          {/* slug, URL, global.ui, moneda */}
  <ShopAccountProvider slug="mi-tienda">                  {/* sesión del cliente */}
    <CartProvider slug="mi-tienda">                       {/* único carrito: líneas, cupones, recuperación */}
      <CmsTracking pathname={usePathname()} />            {/* píxeles con consentimiento */}
      {children}
    </CartProvider>
  </ShopAccountProvider>
</CmsProvider>
```

**Textos editables.** Ningún rótulo de control va quemado: `useShopUi()` devuelve `SHOP_UI` (los mismos nombres y valores que el renderer) con lo que el cliente cambió en `global.ui` (Tienda › Más opciones › Textos). `<CmsUiText k="addToCart" />` además emite `data-cms-global="ui.addToCart"` para editarlo con un clic en el portal. Sin React: `resolveShopUi(payload.global)`, `fillUi(ui.reviewsCount, 3)`.

```tsx
const ui = useShopUi();
const money = useMoney();                 // moneda y locale del proyecto (COP sin decimales, MXN con 2)
<button>{ui.addToCart}</button> <span>{money(product.price)}</span>
{isOnSale(product) && <s>{money(product.compareAtPrice!)}</s>} <small>-{discountPercent(product)} %</small>
```

**`useCart`** (una sola implementación, dentro de `<CartProvider>`): líneas, cupones, tarjetas, cotización del servidor, contacto para el carrito abandonado y recuperación automática en `/carrito/recuperar?token=…` (`recovered.couponCode`).

```tsx
const cart = useCart();
cart.add({ productId: p.id, title: p.title, unitPrice: p.price, variant }, 1);
const r = await cart.applyCoupon('BIEN10'); if (!r.ok) setMsg(r.message);
```

**`useCheckout`** reúne el checkout completo: datos y dirección (prellenados con la cuenta), envío a domicilio o **retiro en tienda**, **franja de entrega**, **opciones de envío** por zona (`shipping`), **métodos de pago** del país con **BNPL** por monto (Addi, Kueski Pay, Aplazo), cupones y tarjetas, cotización con todo lo anterior, validación por campo, `event_id` de medición, envío y redirección a la pasarela.

```tsx
const co = useCheckout({ redirectUrl: `${origin}/pago` });
<input value={co.form.customerEmail} onChange={(e) => co.setField('customerEmail', e.target.value)} aria-invalid={!!co.errors.customerEmail} />
{co.options.pickup.enabled && <label><input type="radio" checked={co.fulfillment === 'pickup'} onChange={() => co.setFulfillment('pickup')} /> {ui.fulfillmentPickup}</label>}
{co.options.deliverySlots.enabled && co.options.deliveryDates.map((d) => <option key={d} value={d}>{deliveryDateLabel(d)}</option>)}
{co.shipping.options.map((o) => <label key={o.id}><input type="radio" checked={co.shipping.selectedId === o.id} onChange={() => co.shipping.select(o.id)} /> {o.name} · {o.estimatedDelivery} · {money(o.amount)}</label>)}
{co.paymentMethods.map((m) => <label key={m.id}><input type="radio" disabled={!m.available} checked={co.provider === m.id} onChange={() => co.setProvider(m.id)} /> {m.label} {m.installments}</label>)}
<CmsPricingTotals pricing={co.pricing} loading={co.quoting} />
<button onClick={co.submit} disabled={co.submitting}>{co.submitting ? ui.processing : ui.placeOrder}</button>
{co.result && !co.result.checkoutUrl && <p>{ui.orderReceived} {co.result.orderNumber}. {co.instructions}</p>}
```

Sin `<CartProvider>`: `useCheckout({ client, items, couponCodes })`. El 409 `SHIPPING_AMOUNT_CHANGED` vuelve a cotizar el envío y deja `co.error = ui.shippingChanged`.

**`useShippingOptions`** suelto (p. ej. un estimador en el carrito): `useShippingOptions({ address: { city, department }, items })` → `options`, `selectedId`, `select`, `quote.reason` (`NO_ZONE`).

**`usePaymentMethods`** y **`useShopConfig`** (una sola petición por tienda): `const { options, available } = usePaymentMethods({ amount: pricing?.amountDue })`. Sin React: `paymentOptions(config, { amount })`, `isBnplOption(o)`, `checkoutOptions(config)`, `checkoutExtrasBody(config, { fulfillment, pickupLocationId, deliverySlot })`.

**`usePaymentReturn`** en la página de retorno (Wompi, MercadoPago, Bold, Stripe, Addi, Kueski, Aplazo): confirma con el backend, sondea mientras esté pendiente y emite `purchase` al aprobarse.

```tsx
const ret = usePaymentReturn();
if (ret.status === 'paid') return <p>{ui.paymentApproved} · {ret.orderNumber}</p>;
if (ret.status === 'failed') return <button onClick={() => ret.retry()}>{ui.retryPayment}</button>;
if (ret.status === 'checking' || ret.status === 'pending') return <p>{ui.paymentPending}</p>;
```

**Totales e impuestos.** `<CmsPricingTotals pricing={…} />` pinta (sin estilos, `data-cms-total="…"`) subtotal, descuentos, envío (tachado si hay envío gratis), impuestos incluidos como nota o agregados, tarjetas de regalo, total a pagar, pedido mínimo y límites por cliente. Para tu propio diseño: `pricingRows(pricing, { labels: ui })` y `taxBreakdown(pricing)`.

**`useReviews` / `CmsReviews` / `CmsRatingStars`.** Reseñas paginadas, envío con fotos y enlace del correo (`?resena=<token>&estrellas=N` → compra verificada).

```tsx
<CmsRatingStars value={product.ratingAverage} count={product.ratingCount} />
<CmsReviews productId={product.id} maxPhotos={config?.storeExtras?.reviews.maxPhotos} />
const r = useReviews(product.id); const { id } = await r.uploadPhoto(file); await r.submit({ rating: 5, body, name, email, photos: [id] });
const inv = useReviewInvite();       // { token, stars, product, alreadyReviewed }
const sums = useReviewSummaries(ids); // { [id]: { average, count } } para tarjetas fuera del delivery
```

**`useWishlist`** (navegador sin sesión; en la cuenta con sesión, subiendo los del navegador): `const wl = useWishlist(); <CmsWishlistButton productId={p.id} wishlist={wl} />`.

**`useBackInStock`**: `const { subscribe, status } = useBackInStock(p.id); await subscribe(email, variant)` o `<CmsBackInStockForm productId={p.id} />` (409 `IN_STOCK` si ya hay).

**`useRelatedProducts`** / **`useRecentlyViewed`**: `useRelatedProducts(product, { count: 4 })` (campo `related` y misma categoría) · `const { ids } = useRecentlyViewed(product.id)`.

**`useCustomerAccount`** (dentro de `<ShopAccountProvider>`): login, registro, restablecer, perfil, direcciones, pedidos, reintento de pago, devoluciones y descargas.

```tsx
const acc = useCustomerAccount({ load: ['orders', 'returns', 'downloads'] });
await acc.login({ email, password }); await acc.forgotPassword(email); await acc.resetPassword(token, nueva);
acc.orders.items.map((o) => <a href={`/cuenta/pedidos/${o.orderNumber}`}>{o.orderNumber} · {orderStatusLabel(o.status)} {o.canRetry && <button onClick={() => acc.retryPayment(o.orderNumber)}>{ui.retryPayment}</button>}</a>);
await acc.requestReturn('ORD-…', { reason, items: [{ lineId: line.lineId!, quantity: 1 }] }); // items vacío = pedido completo
acc.downloads.items.map((d) => d.url && <a href={d.url}>{d.title}</a>);
```

**`useOrder`** (detalle con `lineId` por línea + rastreo con `shipments[]`), **`useOrderTracking`** (formulario público «Rastrear pedido», `notFound`) y **`useDownloads({ orderNumber, email })`** (descargas de invitado).

**«Pedir por WhatsApp».** `<CmsWhatsAppOrderButton />` (solo si la tienda activó `globalData.site.whatsappOrders`) o `cart.buildWhatsAppOrder()` → `whatsappUrl`. Sin React: `buildWhatsAppOrder({ slug, items, couponCodes, shippingOptionId })`, `whatsappOrdersConfig(payload.global)`.

**Carrito abandonado.** El contacto que escribe el comprador en `useCheckout` llega solo al carrito (`reminderConsent` = casilla «recordarme»). Baja desde tu página: `unsubscribeCartReminders({ slug, token })`.

**Medición y cookies.** `<CmsTracking />` + `useTrack()`; el checkout envía el `event_id` (`co.eventId`). Banner propio con `useTrackingConsent()` (`visible`, `banner.text|acceptLabel|rejectLabel` de `globalData.site.cookieBanner`, `accept()`, `reject()`), que usa el mismo almacenamiento y evento que el renderer.

**Formularios.** `const lead = useLeadForm({ formId: 'cotizacion' }); await lead.submit({ payload: { nombre, email } })` (o `submitLead(...)` sin React): usa la definición publicada del `form.custom`, emite `generate_lead` y comparte `event_id` con el Lead de Meta.

**Catálogos.** `feedUrls('https://tienda.com')` (los de tu dominio) o `apiFeedUrls(slug, { base })` (los del CMS).

**Tipos.** `Product` trae `ratingAverage`, `ratingCount`, `isDigital`, `weightKg`, `taxCategory`, `maxPerCustomer`, `compareAtPrice`; `ShopPublicConfig` tipa `paymentMethods`, `checkoutDisplay`, `storeExtras` (reseñas, avisos, favoritos, retiro, franjas, `deliveryDates`), moneda e impuestos; además `ShopPricing`, `ShopOrder` (con `lineId`), `ShopReturnRequest`, `ShopRefund`.

**Prueba de punta a punta** contra un backend LOCAL (nunca producción): `CMS_API_URL=http://localhost:4240 CMS_ADMIN_EMAIL=… CMS_ADMIN_PASSWORD=… npm run e2e:storefront`.

Deprecados (siguen funcionando): `formatPrice` → `formatMoney` / `useMoney`; `REVIEW_LABELS` → `SHOP_UI` / `useShopUi`.

## 9. Ejemplo listo para copiar

[`examples/next-app/`](examples/next-app): Next.js 15 App Router con `CmsPage` + registro (portada, preguntas frecuentes y catálogo con filtros/paginación), detalle de producto, cabecera con globales y menú, webhook de revalidación y estilos solo con `--cms-*`.

```bash
cd packages/cms-client/examples/next-app && npm install && CMS_SLUG=mi-sitio npm run dev
```

## Desarrollo del SDK

```bash
npm run build          # limpia lib/, compila (ESM + .d.ts) y escribe lib/builder.css
npm test               # node --test: núcleo, React (renderToString), runtime (linkedom), auditoría (fixtures + servidor local)
npm run sync-catalog   # regenera src/catalog.ts desde shared/blocks.catalog.json
```

Compatibilidad: las exportaciones de v4.0 se mantienen (`CmsSection s`, `CmsText s f widget`, `cmsSectionProps`, `useLivePreview`, `commitField`…). Cambio visible: los atributos de marcado ahora se emiten también fuera del editor, y `INLINE_FIELD_CHANGE` envía la ruta completa (`items.2.title`) como `fieldKey` según §8.2.
