'use client';

/**
 * Renderer de referencia del compositor (`layout.composer`). Lo usan los sitios headless con el SDK
 * y el renderer del CMS (copia generada en frontend/src/sdk-generated/composer), así ambos pintan
 * exactamente el mismo HTML.
 *
 *   <Composer data={section.data} sectionKey="intro" sectionId="…" host={{ projectSlug: 'mi-sitio' }} />
 *
 * En el editor (`host.isBuilder`) cada elemento se selecciona, los textos se editan en línea y una
 * barra flotante permite duplicar, borrar, mover y arrastrar entre columnas. Todo se comunica al
 * portal con `CMS_CANVAS_ACTION` (INLINE_FIELD_CHANGE, FOCUS_FIELD, COMPOSER_ACTION).
 */

import React, { createContext, useContext, useEffect, useMemo, useRef, useState } from 'react';
import type {
  ComposerColumn,
  ComposerData,
  ComposerElement,
  ComposerElementStyle,
  ComposerOp,
  ComposerRow,
} from './types.js';
import { ELEMENT_DEFS, ROW_LAYOUTS, isElementType, normalizeComposer } from './model.js';
import { columnPath, elementPath, rowPath, setPath } from './paths.js';
import { markdownToHtml } from './markdown.js';
import { ComposerIcon, hasComposerIcon } from './icons.js';
import { COMPOSER_CSS } from './css.js';

/* ───────────────────────── host adapter ───────────────────────── */

export interface ResolvedHref {
  href: string;
  external?: boolean;
  onClick?: (e: React.MouseEvent) => void;
}

export interface LeadSubmission {
  fullName: string;
  email: string;
  phone: string;
  message: string;
  formName: string;
  /** Identificador del formulario (el backend valida contra el formulario publicado con ese id). */
  formId: string;
  payload: Record<string, unknown>;
  sourcePage: string;
  sourceSection?: string;
  website: string;
}

/** Lo que el sitio anfitrión (CMS o headless) le presta al compositor. */
export interface ComposerHost {
  /** Dentro del iframe del portal con ?builder=1. */
  isBuilder?: boolean;
  projectSlug?: string;
  /** Origen del CMS para formularios (por defecto https://webproai.tech). */
  apiBase?: string;
  /** Ítems publicados por colección (payload de delivery). */
  collections?: Record<string, any[]>;
  collectionDefinitions?: Record<string, any>;
  /** Número de WhatsApp del sitio para enlaces `whatsapp:`. */
  whatsappNumber?: string;
  /** Prefijo de rutas internas (`/site/<slug>` en el host de la plataforma). */
  basePath?: string;
  /** Resuelve hrefs especiales (`whatsapp:`, `cart:`, rutas). Por defecto `resolveComposerHref`. */
  resolveHref?: (href: string) => ResolvedHref;
  /** URL de detalle de un ítem de colección (o null si no tiene). */
  itemHref?: (item: any, collectionSlug: string) => string | null;
  /** Clic en un ítem (el CMS abre el detalle en un panel). */
  onItemClick?: (item: any, collectionSlug: string, e: React.MouseEvent) => void;
  /** Redimensiona imágenes de CDN (`url`, ancho) y su srcset. */
  imageUrl?: (url: string, width: number) => string;
  imageSrcSet?: (url: string) => string | undefined;
  formatPrice?: (value: unknown) => string;
  /** Envía `CMS_CANVAS_ACTION` al portal. Sin esto, el editor no emite nada. */
  emit?: (action: string, payload: Record<string, unknown>) => void;
  /** Reemplaza el envío del formulario (por defecto POST /api/public/leads/:slug). */
  submitLead?: (lead: LeadSubmission) => Promise<void>;
  /** Formulario publicado del sitio (`form.custom` o un formulario de compositor) por su formId. */
  findForm?: (formId: string) => LinkedForm | null;
}

export interface LinkedForm {
  formId: string;
  fields: any[];
  submitLabel?: string;
  successMessage?: string;
  redirectTo?: string;
}

/** Normaliza un identificador de formulario igual que el backend (`Contacto Obra` → `contacto-obra`). */
export function formIdOf(v: unknown): string {
  return String(v || '')
    .trim()
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9_-]+/g, '-')
    .replace(/(^-|-$)/g, '')
    .slice(0, 80);
}

/**
 * Formularios definidos en las páginas de un payload de delivery: secciones `form.custom` y elementos
 * `form` (modo «aquí») de compositores. Útil para `host.findForm`.
 */
export function formsFromPayload(payload: any): Record<string, LinkedForm> {
  const out: Record<string, LinkedForm> = {};
  const visit = (v: any, depth: number) => {
    if (!v || typeof v !== 'object' || depth > 8) return;
    if (Array.isArray(v)) return v.forEach((x) => visit(x, depth + 1));
    const src = v._block === 'form.custom' ? v : v.type === 'form' && v.props && v.props.mode !== 'linked' ? v.props : null;
    if (src && Array.isArray(src.fields)) {
      const id = formIdOf(src.formId);
      if (id && !out[id]) out[id] = { formId: id, fields: src.fields, submitLabel: src.submitLabel, successMessage: src.successMessage, redirectTo: src.redirectTo };
    }
    for (const [k, x] of Object.entries(v)) if (k !== '_style' && x && typeof x === 'object') visit(x, depth + 1);
  };
  for (const pg of Array.isArray(payload?.pages) ? payload.pages : []) {
    for (const s of Array.isArray(pg?.sectionsList) ? pg.sectionsList : []) if (s?.isVisible !== false) visit(s?.data, 0);
  }
  return out;
}

export interface ComposerProps {
  data: Partial<ComposerData> | Record<string, any>;
  sectionKey: string;
  sectionId?: string;
  host?: ComposerHost;
  className?: string;
  style?: React.CSSProperties;
  /** Etiqueta raíz (por defecto `div`; usa `section` si no hay otro contenedor de sección). */
  as?: any;
  /** Incluye la hoja de estilos del compositor (desactívala si pones <ComposerStyles/> una vez). */
  styles?: boolean;
  id?: string;
}

const SAFE_HREF = /^(https?:\/\/|mailto:|tel:|#|\/(?!\/))/i;

/** Resolución por defecto de enlaces del compositor. */
export function resolveComposerHref(href: string, opts: { basePath?: string; whatsappNumber?: string } = {}): ResolvedHref {
  const raw = String(href || '').trim();
  if (!raw) return { href: '' };
  if (/^whatsapp:/i.test(raw)) {
    const digits = String(opts.whatsappNumber || '').replace(/[^0-9]/g, '');
    if (!digits) return { href: '' };
    const msg = decodeURIComponent(raw.slice(9));
    return { href: `https://wa.me/${digits}${msg ? `?text=${encodeURIComponent(msg)}` : ''}`, external: true };
  }
  if (/^(cart|tracking):/i.test(raw)) return { href: '#' };
  if (!SAFE_HREF.test(raw)) return { href: '' };
  if (/^https?:\/\//i.test(raw)) return { href: raw, external: true };
  if (raw.startsWith('/') && opts.basePath) {
    const base = opts.basePath.replace(/\/$/, '');
    return { href: raw === '/' ? base || '/' : raw.startsWith('/#') ? `${base}${raw.slice(1)}` : `${base}${raw}` };
  }
  return { href: raw };
}

const VIDEO_HOSTS = /^(www\.)?(youtube\.com|youtube-nocookie\.com|youtu\.be|player\.vimeo\.com|vimeo\.com)$/i;
const EMBED_HOSTS = new Set([
  'www.youtube.com',
  'youtube.com',
  'www.youtube-nocookie.com',
  'player.vimeo.com',
  'www.google.com',
  'maps.google.com',
  'calendar.google.com',
  'docs.google.com',
  'calendly.com',
  'form.typeform.com',
  'open.spotify.com',
  'w.soundcloud.com',
  'airtable.com',
  'tally.so',
]);

/** YouTube / Vimeo → URL embebible; null para archivos directos o enlaces desconocidos. */
export function videoEmbedUrl(url: string): string | null {
  const u = String(url || '').trim();
  const yt = u.match(/(?:youtube\.com\/(?:watch\?v=|embed\/|shorts\/)|youtu\.be\/)([A-Za-z0-9_-]{6,})/);
  if (yt) return `https://www.youtube-nocookie.com/embed/${yt[1]}?rel=0`;
  const vm = u.match(/vimeo\.com\/(?:video\/)?(\d+)/);
  if (vm) return `https://player.vimeo.com/video/${vm[1]}`;
  return null;
}

export function safeEmbedUrl(url: string): string | null {
  try {
    const u = new URL(String(url || '').trim());
    if (u.protocol !== 'https:') return null;
    if (!EMBED_HOSTS.has(u.hostname) && !VIDEO_HOSTS.test(u.hostname)) return null;
    return u.toString();
  } catch {
    return null;
  }
}

/* ───────────────────────── runtime context ───────────────────────── */

interface Runtime {
  host: ComposerHost;
  builder: boolean;
  sectionKey: string;
  sectionId: string;
  data: ComposerData;
  selected: string | null;
  select: (path: string | null) => void;
  commit: (path: string, value: unknown) => void;
  action: (op: ComposerOp, path: string, payload?: Record<string, unknown>) => void;
  focus: (fieldPath: string, fieldType: string) => void;
  link: (href: string) => ResolvedHref;
  img: (url: string, width: number) => string;
  drop: { path: string; position: 'before' | 'after' | 'inside' } | null;
  setDrop: (d: Runtime['drop']) => void;
}

const Ctx = createContext<Runtime | null>(null);
const useRt = () => useContext(Ctx) as Runtime;

/** Origen del arrastre en curso (mismo documento). */
let dragging: { sectionKey: string; path: string } | null = null;

const str = (v: unknown): string => (v === null || v === undefined ? '' : typeof v === 'string' ? v : typeof v === 'number' ? String(v) : '');
const num = (v: unknown, d: number): number => (Number.isFinite(Number(v)) && v !== '' && v !== null ? Number(v) : d);

function ratioValue(r: string): string | null {
  const m = /^(\d+(?:\.\d+)?):(\d+(?:\.\d+)?)$/.exec(String(r || ''));
  return m ? `${m[1]} / ${m[2]}` : null;
}

const FONT_TOKENS: Record<string, string> = { xs: '0.8125rem', sm: '0.9375rem', md: '1.0625rem', lg: '1.25rem', xl: '1.5rem', '2xl': '2rem', '3xl': '2.75rem' };
const CSS_LEN = /^-?\d+(\.\d+)?(px|rem|em|%|vw|ch)$/;
const COLOR_OK = /^(#[0-9a-f]{3,8}|(rgb|rgba|hsl|hsla|oklch|oklab|color-mix)\([^;{}<>]*\)|var\(--cms-[a-z0-9-]+\)|[a-z]+)$/i;

function cssColor(v: unknown): string | undefined {
  const s = str(v).trim();
  return s && COLOR_OK.test(s) ? s : undefined;
}

function cssLen(v: unknown): string | undefined {
  const s = str(v).trim();
  if (!s) return undefined;
  if (/^-?\d+(\.\d+)?$/.test(s)) return `${s}px`;
  return CSS_LEN.test(s) ? s : undefined;
}

function maxWidthValue(v: unknown): string | undefined {
  const s = str(v).trim();
  if (s === 'narrow') return '40ch';
  if (s === 'medium') return '60ch';
  return cssLen(s);
}

/** A custom text color also drives the muted/fg variables used by every inner piece. */
function inkVars(color: string): Record<string, string> {
  return { color, '--cmp-fg': color, '--cmp-muted': `color-mix(in srgb, ${color} 78%, transparent)` };
}

/** Estilo de un elemento → atributos + variables CSS (sin CSS arbitrario). */
function elementStyleAttrs(style: ComposerElementStyle | undefined, inheritedAlign: string) {
  const s = style || {};
  const css: Record<string, string | number> = {};
  const attrs: Record<string, string | undefined> = {};
  const align = s.align || inheritedAlign;
  if (align && align !== 'left') attrs['data-align'] = align;
  const color = cssColor(s.color);
  if (color) Object.assign(css, inkVars(color));
  const bg = cssColor(s.background);
  if (bg) css.background = bg;
  if (s.marginTop) css.marginTop = `${num(s.marginTop, 0)}px`;
  if (s.marginBottom) css.marginBottom = `${num(s.marginBottom, 0)}px`;
  if (s.padding) css.padding = `${num(s.padding, 0)}px`;
  if (s.radius) css.borderRadius = `${num(s.radius, 0)}px`;
  if (s.weight) css.fontWeight = Number(s.weight) || 400;
  const fs = FONT_TOKENS[str(s.fontSize)] || cssLen(s.fontSize);
  if (fs) {
    css['--fs'] = fs;
    attrs['data-fs'] = '';
  }
  const mw = maxWidthValue(s.maxWidth);
  if (mw) {
    css['--mw'] = mw;
    attrs['data-mw'] = '';
  }
  const cls = `${s.hideOnMobile ? ' cmp-hide-m' : ''}${s.hideOnDesktop ? ' cmp-hide-d' : ''}`;
  return { css: css as React.CSSProperties, attrs, cls };
}

/* ───────────────────────── editable text ───────────────────────── */

function Editable({
  path,
  value,
  as: Tag = 'span',
  className,
  placeholder,
  multiline = false,
  id,
  extra,
  optional,
}: {
  path: string;
  value: string;
  as?: any;
  className?: string;
  placeholder: string;
  multiline?: boolean;
  id?: string;
  extra?: Record<string, string | undefined>;
  /** Optional text: in the editor its empty placeholder only shows on the selected element. */
  optional?: boolean;
}) {
  const rt = useRt();
  if (!rt.builder) {
    if (!value) return null;
    return (
      <Tag id={id} className={className} data-cms-field={path} data-cms-type={multiline ? 'textarea' : 'text'} {...extra}>
        {value}
      </Tag>
    );
  }
  return (
    <Tag
      id={id}
      className={className}
      {...extra}
      contentEditable
      suppressContentEditableWarning
      spellCheck
      data-cmp-edit=""
      data-cms-field={path}
      data-cms-type={multiline ? 'textarea' : 'text'}
      data-placeholder={placeholder}
      data-empty={value ? undefined : ''}
      data-cmp-optional={optional ? '' : undefined}
      onClick={(e: React.MouseEvent) => {
        // Links and buttons must not navigate while their text is being edited.
        if ((e.currentTarget as HTMLElement).closest('a,button')) e.preventDefault();
      }}
      onKeyDown={(e: React.KeyboardEvent<HTMLElement>) => {
        if (e.key === 'Enter' && !multiline) {
          e.preventDefault();
          e.currentTarget.blur();
        }
        if (e.key === 'Escape') {
          e.currentTarget.innerText = value;
          e.currentTarget.blur();
        }
        e.stopPropagation();
      }}
      onInput={(e: React.FormEvent<HTMLElement>) => {
        const el = e.currentTarget;
        if (plainTextOf(el).trim()) el.removeAttribute('data-empty');
        else el.setAttribute('data-empty', '');
      }}
      onBlur={(e: React.FocusEvent<HTMLElement>) => {
        const next = plainTextOf(e.currentTarget).replace(/ /g, ' ').replace(/\n{3,}/g, '\n\n').trim();
        if (next !== value) rt.commit(path, next);
      }}
    >
      {value}
    </Tag>
  );
}

/* ───────────────────────── link / button ───────────────────────── */

function SmartLink({
  href,
  newTab,
  className,
  children,
  focusPath,
  attrs,
  label,
}: {
  href: string;
  newTab?: boolean;
  className?: string;
  children: React.ReactNode;
  /** Ruta del campo de enlace (FOCUS_FIELD link en el editor). */
  focusPath?: string;
  attrs?: Record<string, any>;
  label?: string;
}) {
  const rt = useRt();
  const res = rt.link(href);
  if (rt.builder) {
    return (
      <a
        href={res.href || '#'}
        className={className}
        aria-label={label}
        data-cms-field={focusPath}
        data-cms-type={focusPath ? 'link' : undefined}
        onClick={(e) => {
          e.preventDefault();
          if (focusPath) rt.focus(focusPath, 'link');
        }}
        {...attrs}
      >
        {children}
      </a>
    );
  }
  if (!res.href) {
    return (
      <span className={className} {...attrs}>
        {children}
      </span>
    );
  }
  return (
    <a
      href={res.href}
      className={className}
      aria-label={label}
      target={newTab || res.external ? '_blank' : undefined}
      rel={res.external || newTab ? 'noopener noreferrer' : undefined}
      onClick={res.onClick}
      data-cms-field={focusPath}
      data-cms-type={focusPath ? 'link' : undefined}
      {...attrs}
    >
      {children}
    </a>
  );
}

function Btn({ label, href, newTab, variant, size, full, labelPath, hrefPath }: {
  label: string;
  href: string;
  newTab?: boolean;
  variant: string;
  size?: string;
  full?: boolean;
  labelPath: string;
  hrefPath: string;
}) {
  const rt = useRt();
  const res = rt.link(href);
  if (!rt.builder && !label) return null;
  const attrs = {
    'data-variant': ['primary', 'secondary', 'outline', 'link'].includes(variant) ? variant : 'primary',
    'data-size': size && size !== 'md' ? size : undefined,
    'data-full': full ? '' : undefined,
  };
  const text = <Editable path={labelPath} value={label} placeholder="Texto del botón" />;
  // Without a destination it is still an honest control: a <button>, never a dead link.
  if (!rt.builder && !res.href) {
    return (
      <button type="button" className="cmp-btn" {...attrs} data-cms-field={labelPath} data-cms-type="text" disabled>
        {label}
      </button>
    );
  }
  return (
    <SmartLink href={href} newTab={newTab} className="cmp-btn" focusPath={hrefPath} attrs={attrs}>
      {text}
      {variant === 'link' ? <ComposerIcon name="arrow-right" size={16} /> : null}
    </SmartLink>
  );
}

/* ───────────────────────── image helpers ───────────────────────── */

/**
 * Plain text of an edited element as the user typed it: keeps <br>/block line breaks and,
 * unlike innerText, ignores CSS text-transform (an uppercase heading must not be saved uppercase).
 */
function plainTextOf(node: Node): string {
  let out = '';
  node.childNodes.forEach((n) => {
    if (n.nodeType === 3) out += n.textContent || '';
    else if (n.nodeName === 'BR') out += '\n';
    else if (n.nodeType === 1) {
      const block = /^(DIV|P|LI|H[1-6]|BLOCKQUOTE)$/.test(n.nodeName);
      if (block && out && !out.endsWith('\n')) out += '\n';
      out += plainTextOf(n);
      if (block && !out.endsWith('\n')) out += '\n';
    }
  });
  return out;
}

function Img({ url, alt, sizes, width, className, style, priority }: { url: string; alt: string; sizes?: string; width?: number; className?: string; style?: React.CSSProperties; priority?: boolean }) {
  const rt = useRt();
  const src = rt.img(url, width || 1600);
  const srcSet = rt.host.imageSrcSet ? rt.host.imageSrcSet(url) : undefined;
  return (
    <img
      src={src}
      srcSet={srcSet}
      sizes={srcSet ? sizes || '(max-width: 640px) 100vw, 50vw' : undefined}
      alt={alt}
      loading={priority ? 'eager' : 'lazy'}
      decoding="async"
      className={className}
      style={style}
    />
  );
}

function ImagePlaceholder({ path, label = 'Elegir imagen' }: { path: string; label?: string }) {
  const rt = useRt();
  if (!rt.builder) return null;
  return (
    <span
      className="cmp-ph cms-builder-ui"
      role="button"
      tabIndex={0}
      onClick={(e) => {
        e.stopPropagation();
        rt.focus(path, 'image');
      }}
      onKeyDown={(e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          rt.focus(path, 'image');
        }
      }}
    >
      <ComposerIcon name="image" size={18} />
      {label}
    </span>
  );
}

function BuilderHint({ children }: { children: React.ReactNode }) {
  const rt = useRt();
  return rt.builder ? <p className="cmp-hint cms-builder-ui">{children}</p> : null;
}

/* ───────────────────────── elements ───────────────────────── */

type ElProps = { el: ComposerElement; path: string; p: Record<string, any> };

function headingSize(p: Record<string, any>) {
  const level = Math.min(6, Math.max(1, Math.round(num(p.level, 2))));
  const auto = ['display', 'xl', 'lg', 'md', 'sm', 'sm'][level - 1];
  return ['display', 'xl', 'lg', 'md', 'sm'].includes(p.size) ? p.size : auto;
}

function HeadingEl({ el, path, p }: ElProps) {
  const level = Math.min(6, Math.max(1, Math.round(num(p.level, 2))));
  return (
    <>
      <Editable path={`${path}.props.eyebrow`} value={str(p.eyebrow)} as="span" className="cmp-eyebrow" placeholder="Antetítulo (opcional)" optional />
      <Editable path={`${path}.props.text`} value={str(p.text)} as={`h${level}`} className="cmp-h" placeholder="Escribe un titular" id={`h-${el.id}`} extra={{ 'data-size': headingSize(p) }} />
    </>
  );
}

function TextEl({ path, p }: ElProps) {
  return <Editable path={`${path}.props.text`} value={str(p.text)} as="p" className="cmp-p" placeholder="Escribe un párrafo" multiline />;
}

function RichEl({ path, p }: ElProps) {
  const rt = useRt();
  const md = str(p.markdown);
  if (!md) return rt.builder ? <BuilderHint>Texto con formato vacío. Escríbelo en el panel de la derecha.</BuilderHint> : null;
  return (
    <div
      className="cmp-prose"
      data-cms-field={`${path}.props.markdown`}
      data-cms-type="richtext"
      onClick={rt.builder ? () => rt.focus(`${path}.props.markdown`, 'richtext') : undefined}
      dangerouslySetInnerHTML={{ __html: markdownToHtml(md) }}
    />
  );
}

function ImageEl({ path, p }: ElProps) {
  const rt = useRt();
  const url = str(p.url);
  const ratio = ratioValue(str(p.ratio));
  const frameStyle = {
    ...(ratio ? { '--ratio': ratio } : {}),
    ...(p.fit === 'contain' ? { '--fit': 'contain' } : {}),
  } as React.CSSProperties;
  if (!url && !rt.builder) return null;
  const img = url ? (
    <Img url={url} alt={str(p.alt)} style={{ objectPosition: str(p.focal) || undefined }} />
  ) : (
    <ImagePlaceholder path={`${path}.props.url`} />
  );
  const linked = url && str(p.link) && !rt.builder ? <SmartLink href={str(p.link)}>{img}</SmartLink> : img;
  return (
    <figure className="cmp-fig">
      <div
        className="cmp-frame"
        data-ratio={ratio ? '' : undefined}
        data-round={p.radius === false ? undefined : ''}
        style={frameStyle}
        data-cms-field={`${path}.props.url`}
        data-cms-type="image"
        onClick={rt.builder && url ? (e) => {
          e.stopPropagation();
          rt.select(path);
          rt.focus(`${path}.props.url`, 'image');
        } : undefined}
      >
        {linked}
      </div>
      {str(p.caption) || rt.builder ? (
        <Editable path={`${path}.props.caption`} value={str(p.caption)} as="figcaption" className="cmp-cap" placeholder="Pie de foto (opcional)" optional />
      ) : null}
    </figure>
  );
}

function ButtonEl({ path, p }: ElProps) {
  return (
    <Btn
      label={str(p.label)}
      href={str(p.href)}
      newTab={Boolean(p.newTab)}
      variant={str(p.variant) || 'primary'}
      size={str(p.size)}
      full={Boolean(p.fullWidth)}
      labelPath={`${path}.props.label`}
      hrefPath={`${path}.props.href`}
    />
  );
}

function ButtonsEl({ path, p }: ElProps) {
  const rt = useRt();
  const items: any[] = Array.isArray(p.items) ? p.items : [];
  if (!items.length) return rt.builder ? <BuilderHint>Añade botones en el panel de la derecha.</BuilderHint> : null;
  return (
    <div className="cmp-btns">
      {items.map((b, i) => (
        <Btn
          key={i}
              label={str(b?.label)}
          href={str(b?.href)}
          newTab={Boolean(b?.newTab)}
          variant={str(b?.variant) || (i === 0 ? 'primary' : 'secondary')}
          labelPath={`${path}.props.items.${i}.label`}
          hrefPath={`${path}.props.items.${i}.href`}
        />
      ))}
    </div>
  );
}

function SpacerEl({ p }: ElProps) {
  return <div className="cmp-spacer" aria-hidden="true" style={{ '--h': `${num(p.size, 48)}px`, '--hm': `${num(p.sizeMobile, num(p.size, 48))}px` } as React.CSSProperties} />;
}

function DividerEl({ p }: ElProps) {
  const ls = ['solid', 'dashed', 'dotted'].includes(p.lineStyle) ? p.lineStyle : 'solid';
  return <hr className="cmp-hr" data-short={p.width === 'short' ? '' : undefined} style={{ '--th': `${Math.min(8, Math.max(1, num(p.thickness, 1)))}px`, '--ls': ls } as React.CSSProperties} />;
}

function VideoEl({ path, p }: ElProps) {
  const rt = useRt();
  const url = str(p.url).trim();
  const ratio = ratioValue(str(p.ratio)) || '16 / 9';
  if (!url) return rt.builder ? <BuilderHint>Pega el enlace de YouTube, Vimeo o .mp4 en el panel de la derecha.</BuilderHint> : null;
  const embed = videoEmbedUrl(url);
  const title = str(p.title) || 'Video';
  if (embed) {
    return (
      <div className="cmp-frame" data-ratio="" data-round="" style={{ '--ratio': ratio } as React.CSSProperties} data-cms-field={`${path}.props.url`} data-cms-type="text">
        <iframe src={embed} title={title} loading="lazy" allow="accelerometer; encrypted-media; gyroscope; picture-in-picture; fullscreen" allowFullScreen style={rt.builder ? { pointerEvents: 'none' } : undefined} />
      </div>
    );
  }
  if (!/^https?:\/\/.+\.(mp4|webm|mov)(\?.*)?$/i.test(url) && !/^\//.test(url)) {
    return rt.builder ? <BuilderHint>Ese enlace no es un video compatible.</BuilderHint> : null;
  }
  const auto = Boolean(p.autoplay);
  return (
    <div className="cmp-frame" data-ratio="" data-round="" style={{ '--ratio': ratio } as React.CSSProperties} data-cms-field={`${path}.props.url`} data-cms-type="text">
      <video
        src={url}
        poster={str(p.poster) || undefined}
        controls={!auto}
        playsInline
        muted={auto}
        autoPlay={auto && !rt.builder}
        loop={auto}
        preload="metadata"
        aria-label={title}
        style={{ objectFit: 'cover' }}
      />
    </div>
  );
}

function EmbedEl({ p }: ElProps) {
  const rt = useRt();
  const src = safeEmbedUrl(str(p.url));
  if (!src) return rt.builder ? <BuilderHint>{str(p.url) ? 'Ese servicio no está permitido. Usa un enlace https de un servicio conocido.' : 'Pega el enlace para insertar en el panel de la derecha.'}</BuilderHint> : null;
  return (
    <iframe
      className="cmp-embed"
      src={src}
      title={str(p.title) || 'Contenido insertado'}
      loading="lazy"
      height={Math.min(1600, Math.max(120, num(p.height, 480)))}
      sandbox="allow-scripts allow-same-origin allow-forms allow-popups"
      style={rt.builder ? { pointerEvents: 'none' } : undefined}
    />
  );
}

function IconEl({ p }: ElProps) {
  const name = hasComposerIcon(p.name) ? p.name : 'sparkles';
  const size = Math.min(160, Math.max(12, num(p.size, 32)));
  return (
    <span className="cmp-icon" data-framed={p.framed === false ? undefined : ''}>
      <ComposerIcon name={name} size={size} label={str(p.label) || undefined} />
    </span>
  );
}

function ListEl({ path, p }: ElProps) {
  const rt = useRt();
  const items: any[] = Array.isArray(p.items) ? p.items : [];
  if (!items.length) return rt.builder ? <BuilderHint>Añade puntos a la lista en el panel de la derecha.</BuilderHint> : null;
  const marker = ['icon', 'bullet', 'number'].includes(p.marker) ? p.marker : 'icon';
  const Tag = marker === 'number' ? 'ol' : 'ul';
  const icon = hasComposerIcon(p.icon) ? p.icon : 'check';
  return (
    <Tag className="cmp-list">
      {items.map((it, i) => (
        <li key={i}>
          <span className="cmp-list__mark" aria-hidden="true">
            {marker === 'number' ? `${i + 1}.` : marker === 'bullet' ? <span className="cmp-list__dot" /> : <ComposerIcon name={hasComposerIcon(it?.icon) ? it.icon : icon} />}
          </span>
          <Editable path={`${path}.props.items.${i}.text`} value={str(it?.text)} placeholder="Punto de la lista" />
        </li>
      ))}
    </Tag>
  );
}

function BadgeEl({ path, p }: ElProps) {
  const tone = ['accent', 'primary', 'neutral', 'outline'].includes(p.tone) ? p.tone : 'accent';
  const rt = useRt();
  if (!str(p.text) && !rt.builder) return null;
  return (
    <span className="cmp-badge" data-tone={tone}>
      <Editable path={`${path}.props.text`} value={str(p.text)} placeholder="Etiqueta" />
    </span>
  );
}

function StatEl({ path, p }: ElProps) {
  return (
    <div className="cmp-stat">
      <span className="cmp-stat__v">
        {str(p.prefix)}
        <Editable path={`${path}.props.value`} value={str(p.value)} placeholder="00" />
        {str(p.suffix)}
      </span>
      <Editable path={`${path}.props.label`} value={str(p.label)} className="cmp-stat__l" placeholder="Qué significa" />
    </div>
  );
}

function QuoteEl({ path, p }: ElProps) {
  const rt = useRt();
  return (
    <figure className="cmp-quote">
      <blockquote style={{ margin: 0 }}>
        <Editable path={`${path}.props.text`} value={str(p.text)} as="p" className="cmp-quote__t" placeholder="Escribe la cita" multiline />
      </blockquote>
      {str(p.author) || str(p.role) || rt.builder ? (
        <figcaption className="cmp-quote__by">
          {str(p.avatar) ? <Img url={str(p.avatar)} alt="" width={120} /> : null}
          <span>
            <Editable path={`${path}.props.author`} value={str(p.author)} as="cite" className="cmp-quote__a" placeholder="Autor" />
            <Editable path={`${path}.props.role`} value={str(p.role)} className="cmp-quote__r" placeholder="Cargo o ciudad" optional />
          </span>
        </figcaption>
      ) : null}
    </figure>
  );
}

function CardEl({ el, path, p }: ElProps) {
  const rt = useRt();
  const variant = ['outlined', 'elevated', 'filled', 'plain'].includes(p.variant) ? p.variant : 'outlined';
  const link = p.link && typeof p.link === 'object' ? p.link : {};
  const image = str(p.image);
  const titleId = `t-${el.id}`;
  return (
    <article className="cmp-card" data-variant={variant} aria-labelledby={str(p.title) ? titleId : undefined}>
      {image ? (
        <div
          className="cmp-card__media"
          data-cms-field={`${path}.props.image`}
          data-cms-type="image"
          onClick={rt.builder ? (e) => {
            e.stopPropagation();
            rt.select(path);
            rt.focus(`${path}.props.image`, 'image');
          } : undefined}
        >
          <Img url={image} alt={str(p.imageAlt)} width={900} />
        </div>
      ) : hasComposerIcon(p.icon) ? (
        <span className="cmp-icon cmp-card__icon" data-framed="">
          <ComposerIcon name={p.icon} size={24} />
        </span>
      ) : null}
      <Editable path={`${path}.props.eyebrow`} value={str(p.eyebrow)} className="cmp-eyebrow" placeholder="Antetítulo (opcional)" optional />
      <Editable path={`${path}.props.title`} value={str(p.title)} as="h3" className="cmp-card__t" placeholder="Título de la tarjeta" id={titleId} />
      <Editable path={`${path}.props.text`} value={str(p.text)} as="p" className="cmp-card__x" placeholder="Texto de la tarjeta" multiline />
      {str(link.label) || rt.builder ? (
        str(link.href) || rt.builder ? (
          <SmartLink href={str(link.href)} newTab={Boolean(link.newTab)} className="cmp-card__l" focusPath={`${path}.props.link`}>
            <Editable path={`${path}.props.link.label`} value={str(link.label)} placeholder="Texto del enlace (opcional)" optional />
            <ComposerIcon name="arrow-right" size={16} />
          </SmartLink>
        ) : null
      ) : null}
    </article>
  );
}

function GalleryEl({ path, p }: ElProps) {
  const rt = useRt();
  const images = (Array.isArray(p.images) ? p.images : [])
    .map((g: any) => (typeof g === 'string' ? { url: g, alt: '' } : { url: str(g?.url), alt: str(g?.alt) }))
    .filter((g: any) => g.url);
  if (!images.length) {
    return rt.builder ? (
      <div className="cmp-frame" data-ratio="" data-round="" style={{ '--ratio': '16 / 9' } as React.CSSProperties}>
        <ImagePlaceholder path={`${path}.props.images`} label="Agregar fotos a la galería" />
      </div>
    ) : null;
  }
  const ratio = ratioValue(str(p.ratio));
  const cols = Math.min(6, Math.max(1, Math.round(num(p.columns, 3))));
  return (
    <div className="cmp-gallery" style={{ '--cols': cols, '--gg': `${Math.min(48, Math.max(0, num(p.gap, 12)))}px` } as React.CSSProperties} data-cms-field={`${path}.props.images`} data-cms-type="gallery">
      {images.map((g: any, i: number) => (
        <div
          key={i}
          className="cmp-frame"
          data-ratio={ratio ? '' : undefined}
          data-round=""
          style={ratio ? ({ '--ratio': ratio } as React.CSSProperties) : undefined}
          onClick={rt.builder ? (e) => {
            e.stopPropagation();
            rt.select(path);
            rt.focus(`${path}.props.images`, 'gallery');
          } : undefined}
        >
          <Img url={g.url} alt={g.alt} width={900} sizes={`(max-width: 640px) 50vw, ${Math.round(100 / cols)}vw`} />
        </div>
      ))}
    </div>
  );
}

function MapEl({ p }: ElProps) {
  const rt = useRt();
  const q = str(p.address).trim();
  if (!q) return rt.builder ? <BuilderHint>Escribe la dirección del mapa en el panel de la derecha.</BuilderHint> : null;
  const zoom = Math.min(20, Math.max(3, Math.round(num(p.zoom, 15))));
  const src = `https://www.google.com/maps?q=${encodeURIComponent(q)}&z=${zoom}&output=embed`;
  return (
    <div>
      <iframe className="cmp-embed" src={src} title={`Mapa: ${q}`} loading="lazy" height={Math.min(900, Math.max(160, num(p.height, 360)))} referrerPolicy="no-referrer-when-downgrade" style={rt.builder ? { pointerEvents: 'none' } : undefined} />
      <a className="cmp-maplink" href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(q)}`} target="_blank" rel="noopener noreferrer">
        Abrir en Google Maps
      </a>
    </div>
  );
}

function itemImage(it: any): string {
  const g = Array.isArray(it?.gallery) ? it.gallery[0] : typeof it?.gallery === 'string' ? it.gallery.split('|')[0] : null;
  return str(it?.imageUrl) || str(it?.image) || str(it?.coverImage) || str(it?.photo) || (typeof g === 'string' ? g.trim() : str(g?.url));
}

function itemSummary(it: any): string {
  return str(it?.summary) || str(it?.excerpt) || str(it?.subtitle) || str(it?.description).replace(/[#*_>`]/g, '').slice(0, 180);
}

function defaultPrice(v: unknown): string {
  if (typeof v === 'number') {
    try {
      return new Intl.NumberFormat('es-CO', { style: 'currency', currency: 'COP', maximumFractionDigits: 0 }).format(v);
    } catch {
      return `$ ${v}`;
    }
  }
  return str(v);
}

const SORTS: Record<string, (a: any, b: any) => number> = {
  newest: (a, b) => String(b?.publishedAt || b?.createdAt || '').localeCompare(String(a?.publishedAt || a?.createdAt || '')),
  title: (a, b) => str(a?.title).localeCompare(str(b?.title), 'es'),
  'price-asc': (a, b) => priceNum(a) - priceNum(b),
  'price-desc': (a, b) => priceNum(b) - priceNum(a),
};

function priceNum(it: any): number {
  const raw = it?.price ?? it?.priceCop ?? it?.precio;
  if (typeof raw === 'number') return raw;
  const d = str(raw).replace(/[^0-9]/g, '');
  return d ? Number(d) : Number.MAX_SAFE_INTEGER;
}

function CollectionEl({ path, p }: ElProps) {
  const rt = useRt();
  const [activeCat, setActiveCat] = useState('');
  const slug = str(p.collection);
  const all: any[] = (slug && Array.isArray(rt.host.collections?.[slug]) ? rt.host.collections![slug] : []).filter(
    (it) => !it?.status || it.status === 'PUBLISHED' || rt.builder,
  );
  const cat = (str(p.category) || activeCat).trim().toLowerCase();
  const categories = Array.from(new Set(all.map((it) => str(it?.category).trim()).filter(Boolean)));
  let items = cat ? all.filter((it) => str(it?.category).trim().toLowerCase() === cat) : all;
  items = [...items].sort(SORTS[str(p.sort)] || ((a, b) => (Boolean(a?.isFeatured) === Boolean(b?.isFeatured) ? 0 : a?.isFeatured ? -1 : 1)));
  const limit = Math.max(0, Math.round(num(p.limit, 6)));
  if (limit) items = items.slice(0, limit);
  if (!slug) return rt.builder ? <BuilderHint>Elige qué colección mostrar en el panel de la derecha.</BuilderHint> : null;
  const filter =
    p.showFilter && !str(p.category) && categories.length > 1 ? (
      <div className="cmp-chips" role="group" aria-label="Filtrar por categoría">
        {['', ...categories].map((c) => (
          <button key={c || 'all'} type="button" className="cmp-chip" aria-pressed={activeCat === c} onClick={() => setActiveCat(c)}>
            {c || 'Todos'}
          </button>
        ))}
      </div>
    ) : null;
  if (!items.length) return rt.builder ? <p className="cmp-empty">La colección «{slug}» no tiene ítems publicados{cat ? ` en «${cat}»` : ''}.</p> : null;
  const layout = ['grid', 'list', 'carousel'].includes(p.layout) ? p.layout : 'grid';
  const cols = Math.min(6, Math.max(1, Math.round(num(p.columns, 3))));
  const price = rt.host.formatPrice || defaultPrice;
  return (
    <>
    {filter}
    <ul className="cmp-items" data-layout={layout} style={{ '--cols': cols, listStyle: 'none', margin: 0, padding: 0 } as React.CSSProperties} data-cms-field={`${path}.props.collection`} data-cms-type="collection" aria-label={rt.host.collectionDefinitions?.[slug]?.name || slug}>
      {items.map((it, i) => {
        const href = p.linkToItem === false ? null : (rt.host.itemHref ? rt.host.itemHref(it, slug) : null) || (str(it?.path) ? rt.link(str(it.path)).href : null);
        const img = p.showImage === false ? '' : itemImage(it);
        const summary = p.showSummary === false ? '' : itemSummary(it);
        const priceRaw = it?.price ?? it?.priceCop ?? it?.precio;
        const priceText = p.showPrice === false || priceRaw === undefined || priceRaw === null || priceRaw === '' ? '' : price(priceRaw);
        // Precio tachado (compareAtPrice) solo si es mayor que el precio (docs/PRICING.md).
        const compareRaw = it?.compareAtPrice;
        const compareText = priceText && compareRaw !== undefined && compareRaw !== null && compareRaw !== '' && priceNum({ price: compareRaw }) > priceNum(it) ? price(compareRaw) : '';
        const body = (
          <>
            {img ? (
              <div className="cmp-item__img">
                <Img url={img} alt={str(it?.imageAlt) || str(it?.title)} width={720} />
              </div>
            ) : null}
            <div className="cmp-item__body">
              <h3 className="cmp-item__t" data-cms-item={`${slug}:${str(it?.id)}`} data-cms-field="title">
                {str(it?.title) || str(it?.name)}
              </h3>
              {summary ? (
                <p className="cmp-item__s" data-cms-item={`${slug}:${str(it?.id)}`} data-cms-field="summary">
                  {summary}
                </p>
              ) : null}
              {priceText ? (
                <span className="cmp-item__p">
                  {priceText}
                  {compareText ? (
                    <>
                      {' '}
                      <s className="cmp-item__was">{compareText}</s>
                    </>
                  ) : null}
                </span>
              ) : null}
            </div>
          </>
        );
        const clickable = (href || rt.host.onItemClick) && p.linkToItem !== false;
        return (
          <li key={str(it?.id) || i}>
            {clickable ? (
              <a
                className="cmp-item"
                href={href || '#'}
                onClick={(e) => {
                  if (rt.builder) {
                    e.preventDefault();
                    return;
                  }
                  if (rt.host.onItemClick) {
                    e.preventDefault();
                    rt.host.onItemClick(it, slug, e);
                  }
                }}
              >
                {body}
              </a>
            ) : (
              <div className="cmp-item">{body}</div>
            )}
          </li>
        );
      })}
    </ul>
    </>
  );
}

function parseOptions(v: unknown): string[] {
  if (Array.isArray(v)) return v.map((o) => (typeof o === 'string' ? o : str((o as any)?.label ?? (o as any)?.value))).filter(Boolean);
  return str(v)
    .split(/[,\n|]/)
    .map((s) => s.trim())
    .filter(Boolean);
}

function fieldKeyFrom(label: string, i: number): string {
  const k = label
    .toLowerCase()
    .normalize('NFD')
    .replace(/[̀-ͯ]/g, '')
    .replace(/[^a-z0-9]+/g, '_')
    .replace(/^_+|_+$/g, '');
  return k || `campo_${i + 1}`;
}

function FormEl({ el, path, p }: ElProps) {
  const rt = useRt();
  const linked = p.mode === 'linked' ? rt.host.findForm?.(formIdOf(p.formId)) || null : null;
  const src: Record<string, any> = linked ? { ...p, ...linked, submitLabel: str(p.submitLabel) || linked.submitLabel } : p.mode === 'linked' ? { ...p, fields: [] } : p;
  // A field added in the inspector may not have a key yet: derive one so it still renders and submits.
  const fields: any[] = (Array.isArray(src.fields) ? src.fields : [])
    .filter((fl) => fl && typeof fl === 'object')
    .map((fl, i) => ({ ...fl, key: str(fl.key).trim() || fieldKeyFrom(str(fl.label), i) }));
  const [state, setState] = useState<'idle' | 'sending' | 'done' | 'error'>('idle');
  const [error, setError] = useState('');
  const formRef = useRef<HTMLFormElement | null>(null);
  const uid = el.id.replace(/[^a-zA-Z0-9_-]/g, '');

  if (!fields.length) {
    if (!rt.builder) return null;
    return (
      <BuilderHint>
        {p.mode === 'linked'
          ? `No hay un formulario publicado con el identificador «${formIdOf(p.formId) || '…'}». Revisa el identificador o define los campos aquí.`
          : 'Agrega campos al formulario en el panel de la derecha.'}
      </BuilderHint>
    );
  }

  if (state === 'done') {
    return (
      <div className="cmp-form__ok" role="status">
        {str(src.successMessage) || 'Gracias. Recibimos tu mensaje.'}
      </div>
    );
  }

  const onSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (rt.builder) return;
    const form = e.currentTarget;
    if (!form.reportValidity()) return;
    const fd = new FormData(form);
    const answers: Record<string, unknown> = {};
    for (const fl of fields) {
      const k = str(fl.key);
      if (fl.type === 'checkbox') answers[k] = fd.get(k) === 'on';
      else answers[k] = str(fd.get(k) as string).trim();
    }
    const pick = (re: RegExp, type?: string) => {
      const byKey = fields.find((fl) => re.test(str(fl.key)));
      const byType = type ? fields.find((fl) => fl.type === type) : undefined;
      const fl = byKey || byType;
      return fl ? str(answers[str(fl.key)]) : '';
    };
    const email = pick(/^(email|correo|e-?mail)$/i, 'email');
    const phone = pick(/^(phone|tel|telefono|teléfono|celular|whatsapp)$/i, 'tel');
    const fullName = pick(/^(name|nombre|fullname|full_name|nombre_completo|nombres)$/i) || str(answers[str(fields.find((fl) => fl.type === 'text')?.key)]) || email || phone;
    const message = pick(/^(message|mensaje|comentario|comentarios)$/i, 'textarea');
    const lead: LeadSubmission = {
      fullName,
      email,
      phone,
      message,
      formName: formIdOf(p.formId) || 'formulario',
      formId: formIdOf(p.formId),
      payload: answers,
      sourcePage: typeof window !== 'undefined' ? window.location.pathname : '/',
      sourceSection: rt.sectionKey,
      website: str(fd.get('website') as string),
    };
    setState('sending');
    setError('');
    try {
      if (rt.host.submitLead) await rt.host.submitLead(lead);
      else {
        const base = (rt.host.apiBase || 'https://webproai.tech').replace(/\/+$/, '').replace(/\/api$/, '');
        const res = await fetch(`${base}/api/public/leads/${encodeURIComponent(rt.host.projectSlug || '')}`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(lead),
        });
        if (!res.ok) {
          const body = await res.json().catch(() => ({}));
          throw new Error(str((body as any)?.message) || `Error ${res.status}`);
        }
      }
      const redirect = str(src.redirectTo).trim();
      if (redirect && typeof window !== 'undefined') {
        const r = rt.link(redirect);
        if (r.href) {
          window.location.assign(r.href);
          return;
        }
      }
      setState('done');
    } catch (err: any) {
      setState('error');
      setError(str(err?.message) || 'No pudimos enviar el formulario. Inténtalo de nuevo.');
    }
  };

  return (
    <form ref={formRef} className="cmp-form" onSubmit={onSubmit} noValidate={false} aria-describedby={state === 'error' ? `${uid}-err` : undefined} data-cms-field={`${path}.props.fields`} data-cms-type="form">
      {fields.map((fl, i) => {
        const k = str(fl.key);
        const id = `${uid}-${k}`;
        const label = str(fl.label) || k;
        const req = Boolean(fl.required);
        const half = fl.width === 'half';
        const reqMark = req ? (
          <span className="cmp-req" aria-hidden="true">
            *
          </span>
        ) : null;
        const common = { id, name: k, required: req, placeholder: str(fl.placeholder) || undefined, className: 'cmp-input', disabled: rt.builder ? true : undefined };
        const labelEl = (
          <label htmlFor={id}>
            {linked ? label : <Editable path={`${path}.props.fields.${i}.label`} value={label} placeholder="Etiqueta" />}
            {reqMark}
          </label>
        );
        switch (fl.type) {
          case 'textarea':
            return (
              <div key={k} className="cmp-field" data-half={half ? '' : undefined}>
                {labelEl}
                <textarea {...common} rows={4} />
              </div>
            );
          case 'select':
            return (
              <div key={k} className="cmp-field" data-half={half ? '' : undefined}>
                {labelEl}
                <select {...common} defaultValue="">
                  <option value="" disabled>
                    {str(fl.placeholder) || 'Elige una opción'}
                  </option>
                  {parseOptions(fl.options).map((o) => (
                    <option key={o} value={o}>
                      {o}
                    </option>
                  ))}
                </select>
              </div>
            );
          case 'radio':
            return (
              <div key={k} className="cmp-field" data-half={half ? '' : undefined}>
                <fieldset>
                  <legend>
                    {label}
                    {reqMark}
                  </legend>
                  {parseOptions(fl.options).map((o, oi) => (
                    <label key={o} className="cmp-check">
                      <input type="radio" name={k} value={o} required={req && oi === 0} disabled={rt.builder ? true : undefined} />
                      {o}
                    </label>
                  ))}
                </fieldset>
              </div>
            );
          case 'checkbox':
            return (
              <div key={k} className="cmp-field" data-half={half ? '' : undefined}>
                <label className="cmp-check" htmlFor={id}>
                  <input id={id} type="checkbox" name={k} required={req} disabled={rt.builder ? true : undefined} />
                  <span>
                    {label}
                    {reqMark}
                  </span>
                </label>
              </div>
            );
          default: {
            const type = ['email', 'tel', 'date', 'number'].includes(fl.type) ? fl.type : 'text';
            const auto = type === 'email' ? 'email' : type === 'tel' ? 'tel' : /^(nombre|name|fullname)$/i.test(k) ? 'name' : undefined;
            return (
              <div key={k} className="cmp-field" data-half={half ? '' : undefined}>
                {labelEl}
                <input {...common} type={type} autoComplete={auto} inputMode={type === 'tel' ? 'tel' : undefined} />
              </div>
            );
          }
        }
      })}
      <div className="cmp-hp" aria-hidden="true">
        <label htmlFor={`${uid}-website`}>No llenes este campo</label>
        <input id={`${uid}-website`} name="website" tabIndex={-1} autoComplete="off" />
      </div>
      {state === 'error' ? (
        <p id={`${uid}-err`} className="cmp-form__err" role="alert">
          {error}
        </p>
      ) : null}
      <div className="cmp-form__foot">
        <button type="submit" className="cmp-btn" data-variant="primary" disabled={state === 'sending'} aria-busy={state === 'sending' || undefined} onClick={rt.builder ? (e) => e.preventDefault() : undefined}>
          {state === 'sending' ? 'Enviando…' : <Editable path={`${path}.props.submitLabel`} value={str(src.submitLabel) || 'Enviar'} placeholder="Enviar" />}
        </button>
        {rt.builder ? <span className="cmp-hint cms-builder-ui">Los envíos funcionan en el sitio publicado.</span> : null}
      </div>
    </form>
  );
}

const RENDERERS: Record<string, React.ComponentType<ElProps>> = {
  heading: HeadingEl,
  text: TextEl,
  richtext: RichEl,
  image: ImageEl,
  button: ButtonEl,
  buttons: ButtonsEl,
  spacer: SpacerEl,
  divider: DividerEl,
  video: VideoEl,
  embed: EmbedEl,
  icon: IconEl,
  list: ListEl,
  badge: BadgeEl,
  stat: StatEl,
  quote: QuoteEl,
  form: FormEl,
  collection: CollectionEl,
  map: MapEl,
  gallery: GalleryEl,
  card: CardEl,
};

/* ───────────────────────── builder chrome ───────────────────────── */

function ToolBtn({ icon, label, onClick, danger, disabled }: { icon: string; label: string; onClick: () => void; danger?: boolean; disabled?: boolean }) {
  return (
    <button
      type="button"
      aria-label={label}
      title={label}
      data-danger={danger ? '' : undefined}
      disabled={disabled}
      onClick={(e) => {
        e.preventDefault();
        e.stopPropagation();
        onClick();
      }}
    >
      <ComposerIcon name={icon} size={14} strokeWidth={2} />
    </button>
  );
}

function ElementTools({ el, path, index, count, wrapperRef }: { el: ComposerElement; path: string; index: number; count: number; wrapperRef: React.RefObject<HTMLDivElement> }) {
  const rt = useRt();
  const def = isElementType(el.type) ? ELEMENT_DEFS[el.type] : null;
  return (
    <div className="cmp-tools cms-builder-ui" role="toolbar" aria-label={`Acciones de ${def?.label || 'elemento'}`} onClick={(e) => e.stopPropagation()}>
      <span
        draggable
        role="button"
        tabIndex={-1}
        aria-label="Arrastrar para mover"
        title="Arrastrar a otra posición o columna"
        onDragStart={(e) => {
          e.stopPropagation();
          dragging = { sectionKey: rt.sectionKey, path };
          e.dataTransfer.effectAllowed = 'move';
          e.dataTransfer.setData('text/plain', `composer:${path}`);
          if (wrapperRef.current) {
            e.dataTransfer.setDragImage(wrapperRef.current, 16, 16);
            wrapperRef.current.setAttribute('data-dragging', '');
          }
        }}
        onDragEnd={(e) => {
          e.stopPropagation();
          dragging = null;
          wrapperRef.current?.removeAttribute('data-dragging');
          rt.setDrop(null);
        }}
      >
        <ComposerIcon name="grip" size={14} strokeWidth={2.5} />
      </span>
      <span className="cmp-tools__label">{def?.label || el.type}</span>
      <ToolBtn icon="arrow-up" label="Subir" disabled={index === 0} onClick={() => rt.action('move_up', path)} />
      <ToolBtn icon="arrow-down" label="Bajar" disabled={index === count - 1} onClick={() => rt.action('move_down', path)} />
      <ToolBtn icon="copy" label="Duplicar" onClick={() => rt.action('duplicate', path)} />
      <ToolBtn icon="plus" label="Añadir elemento debajo" onClick={() => rt.action('add_element', path, { position: 'after' })} />
      <ToolBtn icon="trash" label="Eliminar" danger onClick={() => rt.action('remove', path)} />
    </div>
  );
}

function dropPosition(e: React.DragEvent<HTMLElement>): 'before' | 'after' {
  const r = e.currentTarget.getBoundingClientRect();
  return e.clientY < r.top + r.height / 2 ? 'before' : 'after';
}

/* ───────────────────────── tree ───────────────────────── */

function ElementView({ el, r, c, e: ei, count, align }: { el: ComposerElement; r: number; c: number; e: number; count: number; align: string }) {
  const rt = useRt();
  const ref = useRef<HTMLDivElement>(null);
  const Cmp = RENDERERS[el.type];
  const path = elementPath(r, c, ei);
  if (!Cmp) {
    return rt.builder ? <BuilderHint>Elemento «{String(el.type)}» no disponible en esta versión.</BuilderHint> : null;
  }
  const p = el.props || {};
  const { css, attrs, cls } = elementStyleAttrs(el.style, align);
  const selected = rt.builder && rt.selected === path;
  const drop = rt.builder && rt.drop?.path === path ? rt.drop.position : undefined;

  return (
    <div
      ref={ref}
      className={`cmp-el cmp-el--${el.type}${cls}`}
      data-cmp-type={el.type}
      data-cms-el={el.id}
      data-cms-path={path}
      data-el-id={el.id}
      data-selected={selected ? '' : undefined}
      data-drop={drop}
      style={css}
      {...attrs}
      {...(rt.builder
        ? {
            onClick: (e: React.MouseEvent) => {
              e.stopPropagation();
              rt.select(path);
              rt.focus(path, 'element');
            },
            onDragOver: (e: React.DragEvent<HTMLDivElement>) => {
              if (!dragging || dragging.sectionKey !== rt.sectionKey) return;
              e.preventDefault();
              e.stopPropagation();
              e.dataTransfer.dropEffect = 'move';
              const pos = dropPosition(e);
              if (rt.drop?.path !== path || rt.drop.position !== pos) rt.setDrop({ path, position: pos });
            },
            onDrop: (e: React.DragEvent<HTMLDivElement>) => {
              if (!dragging || dragging.sectionKey !== rt.sectionKey) return;
              e.preventDefault();
              e.stopPropagation();
              const src = dragging.path;
              const pos = dropPosition(e);
              dragging = null;
              rt.setDrop(null);
              if (src !== path) rt.action('move_to', src, { targetPath: path, position: pos });
            },
          }
        : {})}
    >
      <Cmp el={el} path={path} p={p} />
      {rt.builder ? <ElementTools el={el} path={path} index={ei} count={count} wrapperRef={ref} /> : null}
    </div>
  );
}

function ColumnView({ col, r, c, rowGap }: { col: ComposerColumn; r: number; c: number; rowGap: number }) {
  const rt = useRt();
  const s = col.style || {};
  const span = col.span || { desktop: 12 };
  const path = columnPath(r, c);
  const align = s.align === 'center' ? 'center' : s.align === 'end' ? 'right' : '';
  const bg = cssColor(s.background);
  const color = cssColor(s.color);
  const boxed = Boolean(bg || s.padding || s.border);
  const style = {
    '--d': span.desktop,
    '--t': span.tablet ?? span.desktop,
    '--m': span.mobile ?? 12,
    '--g': `${rowGap}px`,
    ...(s.gap !== undefined && s.gap !== null && (s.gap as any) !== '' ? { '--cg': `${num(s.gap, 16)}px` } : {}),
    ...(bg ? { background: bg } : {}),
    ...(color ? inkVars(color) : {}),
    ...(boxed ? { '--cp': `${num(s.padding, bg || s.border ? 24 : 0)}px`, '--cr': `${num(s.radius, 0)}px` } : s.radius ? { borderRadius: `${num(s.radius, 0)}px` } : {}),
  } as unknown as React.CSSProperties;
  const els = col.elements || [];
  const dropInside = rt.builder && rt.drop?.path === path;
  return (
    <div
      className={`cmp-col${s.hideOnMobile ? ' cmp-hide-m' : ''}${s.hideOnDesktop ? ' cmp-hide-d' : ''}`}
      data-cms-col={col.id}
      data-cms-path={path}
      data-valign={s.valign || undefined}
      data-boxed={boxed ? '' : undefined}
      data-border={s.border ? '' : undefined}
      data-drop={dropInside ? 'inside' : undefined}
      style={style}
      {...(rt.builder
        ? {
            onDragOver: (e: React.DragEvent<HTMLDivElement>) => {
              if (!dragging || dragging.sectionKey !== rt.sectionKey) return;
              e.preventDefault();
              e.stopPropagation();
              if (rt.drop?.path !== path) rt.setDrop({ path, position: 'inside' });
            },
            onDragLeave: (e: React.DragEvent<HTMLDivElement>) => {
              if (rt.drop?.path === path && !e.currentTarget.contains(e.relatedTarget as Node)) rt.setDrop(null);
            },
            onDrop: (e: React.DragEvent<HTMLDivElement>) => {
              if (!dragging || dragging.sectionKey !== rt.sectionKey) return;
              e.preventDefault();
              e.stopPropagation();
              const src = dragging.path;
              dragging = null;
              rt.setDrop(null);
              rt.action('move_to', src, { targetPath: path });
            },
          }
        : {})}
    >
      {els.map((el, i) => (
        <ElementView key={el.id || i} el={el} r={r} c={c} e={i} count={els.length} align={align} />
      ))}
      {rt.builder && els.length === 0 ? (
        <button type="button" className="cmp-add cms-builder-ui" onClick={(e) => { e.stopPropagation(); rt.action('add_element', path, {}); }}>
          <ComposerIcon name="plus" size={16} />
          Añadir elemento
        </button>
      ) : null}
    </div>
  );
}

function RowView({ row, r, count }: { row: ComposerRow; r: number; count: number }) {
  const rt = useRt();
  const s = row.style || {};
  const gap = Math.min(160, Math.max(0, num(s.gap, 32)));
  const bg = cssColor(s.background);
  const color = cssColor(s.color);
  const pad = typeof s.padding === 'number' || /^\d+$/.test(str(s.padding)) ? `${num(s.padding, 0)}px` : cssLen(s.padding);
  const boxed = Boolean(bg || pad);
  const path = rowPath(r);
  const style = {
    '--g': `${gap}px`,
    ...(bg ? { background: bg } : {}),
    ...(color ? inkVars(color) : {}),
    ...(boxed ? { '--rp': pad || '32px', '--rr': s.radius !== undefined && s.radius !== null && (s.radius as any) !== '' ? `${num(s.radius, 0)}px` : undefined } : {}),
    ...(s.marginBottom ? { marginBottom: `${num(s.marginBottom, 0)}px` } : {}),
  } as unknown as React.CSSProperties;
  return (
    <div
      className={`cmp-row${s.hideOnMobile ? ' cmp-hide-m' : ''}${s.hideOnDesktop ? ' cmp-hide-d' : ''}`}
      data-cms-row={row.id}
      data-cms-path={path}
      data-align={s.align || undefined}
      data-justify={s.justify || undefined}
      data-reverse={s.reverseOnMobile ? '' : undefined}
      data-boxed={boxed ? '' : undefined}
      data-selected={rt.builder && rt.selected === path ? '' : undefined}
      style={style}
    >
      {rt.builder ? (
        <div className="cmp-rowbar cms-builder-ui" onClick={(e) => e.stopPropagation()}>
          <div className="cmp-tools" role="toolbar" aria-label={`Acciones de la fila ${r + 1}`}>
            <button
              type="button"
              className="cmp-tools__label"
              style={{ width: 'auto', padding: '0 6px' }}
              onClick={(e) => {
                e.stopPropagation();
                rt.select(path);
                rt.focus(path, 'row');
              }}
            >
              Fila {r + 1}
            </button>
            <ToolBtn icon="arrow-up" label="Subir fila" disabled={r === 0} onClick={() => rt.action('move_up', path)} />
            <ToolBtn icon="arrow-down" label="Bajar fila" disabled={r === count - 1} onClick={() => rt.action('move_down', path)} />
            <ToolBtn icon="column" label="Añadir columna" disabled={(row.columns || []).length >= 12} onClick={() => rt.action('add_column', path)} />
            <ToolBtn icon="copy" label="Duplicar fila" onClick={() => rt.action('duplicate', path)} />
            <ToolBtn icon="trash" label="Eliminar fila" danger onClick={() => rt.action('remove', path)} />
          </div>
        </div>
      ) : null}
      {(row.columns || []).map((col, c) => (
        <ColumnView key={col.id || c} col={col} r={r} c={c} rowGap={gap} />
      ))}
    </div>
  );
}

/* ───────────────────────── root ───────────────────────── */

/** Hoja de estilos del compositor (inclúyela una vez si renderizas con `styles={false}`). */
export function ComposerStyles() {
  return <style data-cms-composer-css="" dangerouslySetInnerHTML={{ __html: COMPOSER_CSS }} />;
}

export function Composer({ data, sectionKey, sectionId = '', host = {}, className = '', style, as: Tag = 'div', styles = true, id }: ComposerProps) {
  const norm = useMemo(() => normalizeComposer(data), [data]);
  const builder = Boolean(host.isBuilder);
  const [selected, setSelected] = useState<string | null>(null);
  const [drop, setDrop] = useState<Runtime['drop']>(null);
  // Inline edits made before the portal echoes the new state build on each other, not on stale data.
  const localRows = useRef<{ base: unknown; rows: ComposerRow[] } | null>(null);

  // The portal tells the canvas which node is selected in its inspector.
  useEffect(() => {
    if (!builder || typeof window === 'undefined') return;
    const onMsg = (ev: MessageEvent) => {
      if (ev.source !== window.parent) return;
      const m = ev.data;
      if (!m || m.type !== 'CMS_COMPOSER_SELECT') return;
      setSelected(m.sectionKey === sectionKey && typeof m.path === 'string' && m.path ? m.path : null);
    };
    window.addEventListener('message', onMsg);
    return () => window.removeEventListener('message', onMsg);
  }, [builder, sectionKey]);

  // Canvas shortcuts on the selected element: Supr/Retroceso borra, Ctrl+D duplica, Alt+↑/↓ mueve.
  useEffect(() => {
    if (!builder || !selected || typeof window === 'undefined') return;
    const onKey = (e: KeyboardEvent) => {
      const t = e.target as HTMLElement | null;
      if (t && (t.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName))) return;
      const send = (op: ComposerOp) => {
        e.preventDefault();
        host.emit?.('COMPOSER_ACTION', { sectionKey, sectionId, op, path: selected, payload: {} });
      };
      if (e.key === 'Delete' || e.key === 'Backspace') send('remove');
      else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'd') send('duplicate');
      else if (e.altKey && e.key === 'ArrowUp') send('move_up');
      else if (e.altKey && e.key === 'ArrowDown') send('move_down');
      else if (e.key === 'Escape') setSelected(null);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [builder, selected, host, sectionKey, sectionId]);

  const rt: Runtime = useMemo(() => {
    const emit = (action: string, payload: Record<string, unknown>) => {
      if (host.emit) host.emit(action, { sectionKey, sectionId, ...payload });
    };
    const link = (href: string) => (host.resolveHref ? host.resolveHref(href) : resolveComposerHref(href, { basePath: host.basePath, whatsappNumber: host.whatsappNumber }));
    return {
      host,
      builder,
      sectionKey,
      sectionId,
      data: norm,
      selected,
      select: setSelected,
      commit: (path, value) => {
        if (!path.startsWith('rows.')) return;
        // Dot-path INLINE_FIELD_CHANGE (LIVE-PREVIEW §8.2): the portal writes just this leaf on its
        // latest draft. `rows` carries the whole tree for hosts that only understand top-level keys.
        const base = localRows.current && localRows.current.base === data ? localRows.current.rows : norm.rows;
        const rows = setPath(base, path.slice(5), value);
        localRows.current = { base: data, rows };
        emit('INLINE_FIELD_CHANGE', { fieldKey: path, value, path, rows });
      },
      // SELECT_SECTION first: chrome buttons stop propagation, so the section wrapper never sees the click.
      action: (op, path, payload = {}) => {
        emit('SELECT_SECTION', {});
        emit('COMPOSER_ACTION', { op, path, payload });
      },
      focus: (fieldPath, fieldType) => {
        emit('SELECT_SECTION', {});
        emit('FOCUS_FIELD', { fieldPath, fieldType });
      },
      link,
      img: (url, w) => (host.imageUrl ? host.imageUrl(url, w) : url),
      drop,
      setDrop,
    };
  }, [host, builder, sectionKey, sectionId, norm, data, selected, drop]);

  const rows = norm.rows || [];
  const width = ['narrow', 'standard', 'wide', 'full'].includes(str(norm.width)) ? str(norm.width) : 'standard';
  const spacing = ['none', 'sm', 'md', 'lg'].includes(str(norm.spacing)) ? str(norm.spacing) : 'md';

  return (
    <Ctx.Provider value={rt}>
      <Tag
        id={id}
        className={`cmp ${className}`.trim()}
        data-cms-block="layout.composer"
        data-width={width}
        data-spacing={spacing}
        data-cmp-builder={builder ? '' : undefined}
        style={style}
      >
        {styles ? <ComposerStyles /> : null}
        <div className="cmp-wrap">
          {rows.map((row, r) => (
            <RowView key={row.id || r} row={row} r={r} count={rows.length} />
          ))}
          {builder && rows.length === 0 ? (
            <div className="cmp-layouts cms-builder-ui">
              <strong style={{ fontSize: 14, color: '#0f172a' }}>Sección en blanco</strong>
              <span>Elige cómo dividir la primera fila. Después agrega títulos, imágenes, botones o formularios.</span>
              <div className="cmp-layouts__opts">
                {ROW_LAYOUTS.map((l) => (
                  <button key={l.id} type="button" className="cmp-add" onClick={(e) => { e.stopPropagation(); rt.action('add_row', '', { spans: l.spans }); }}>
                    {l.label}
                  </button>
                ))}
              </div>
            </div>
          ) : null}
          {builder && rows.length > 0 ? (
            <button type="button" className="cmp-add cmp-add--row cms-builder-ui" onClick={(e) => { e.stopPropagation(); rt.action('add_row', rowPath(rows.length - 1), { spans: [12] }); }}>
              <ComposerIcon name="plus" size={16} />
              Añadir fila
            </button>
          ) : null}
        </div>
      </Tag>
    </Ctx.Provider>
  );
}
