'use client';

/**
 * Compositor conectado a <CmsProvider> (sitios headless).
 *
 *   // Con <CmsPage>: importar este módulo registra `layout.composer` en defaultRegistry.
 *   import '@latinovation/cms-client/composer/react';
 *   <CmsPage pageSlug="/" registry={{ hero: Hero }} />
 *
 *   // Sección suelta:
 *   const s = useSection('intro');
 *   <CmsComposer s={s} />
 *
 * Toma colecciones, WhatsApp, medios y el modo editor del provider; en el portal emite las mismas
 * acciones que el renderer del CMS (INLINE_FIELD_CHANGE, FOCUS_FIELD, COMPOSER_ACTION).
 */

import React, { useMemo } from 'react';
import { CmsSection, registerBlock, useCms, type CmsBlockProps } from '../react.js';
import { mediaUrl } from '../delivery.js';
import { getItemRoute } from '../collections.js';
import { Composer, formsFromPayload, type ComposerHost } from './render.js';

type SectionLike = { id: string; key: string; data: Record<string, any>; isVisible?: boolean; block?: string | null };

/** Host del compositor a partir del provider (sobrescribible con `host`). */
export function useComposerHost(host?: Partial<ComposerHost>, apiBase?: string): ComposerHost {
  const cms = useCms();
  const payload: any = cms.payload;
  const forms = useMemo(() => formsFromPayload(payload), [payload]);
  return useMemo(
    () => ({
      isBuilder: cms.isBuilder,
      projectSlug: payload?.project?.slug || cms.slug,
      apiBase: apiBase || cms.cmsUrl,
      collections: payload?.collections,
      collectionDefinitions: payload?.collectionDefinitions,
      whatsappNumber: payload?.global?.whatsappNumber,
      imageUrl: (url: string) => mediaUrl(url, cms.cmsUrl),
      itemHref: (item: any, collection: string) => getItemRoute(payload, collection, item) || null,
      findForm: (formId: string) => forms[formId] || null,
      emit: (action: string, data: Record<string, unknown>) => cms.post(action as any, data),
      ...host,
    }),
    [cms.isBuilder, cms.post, cms.slug, cms.cmsUrl, payload, forms, apiBase, host],
  );
}

/** Componente de bloque para <CmsPage> (ya va envuelto en <CmsSection>). */
export function ComposerBlock({ section, data }: CmsBlockProps) {
  const host = useComposerHost();
  return <Composer data={data} sectionKey={section.key} sectionId={section.id} host={host} />;
}

/** Sección de compositor independiente (incluye <CmsSection> para selección y anclas). */
export function CmsComposer({
  s,
  host,
  apiBase,
  className,
  styles,
}: {
  s: SectionLike;
  host?: Partial<ComposerHost>;
  /** Origen del CMS para los formularios (por defecto el `cmsUrl` del provider). */
  apiBase?: string;
  className?: string;
  styles?: boolean;
}) {
  const merged = useComposerHost(host, apiBase);
  if (s.isVisible === false) return null;
  return (
    <CmsSection s={{ ...s, block: 'layout.composer' } as any}>
      <Composer data={s.data} sectionKey={s.key} sectionId={s.id} host={merged} className={className} styles={styles} />
    </CmsSection>
  );
}

/** Registra `layout.composer` en el defaultRegistry del SDK (idempotente). */
export function registerComposer(): void {
  registerBlock('layout.composer', ComposerBlock);
}

registerComposer();
