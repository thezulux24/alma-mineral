import type { CmsPage, CmsSectionRef, CollectionItem, DeliveryPayload, Product, ProductVariant, SectionData } from './types.js';

export const DEFAULT_CMS_URL = 'https://webproai.tech';

export class CmsDeliveryError extends Error {
  status: number;
  url: string;
  constructor(message: string, status: number, url: string) {
    super(message);
    this.name = 'CmsDeliveryError';
    this.status = status;
    this.url = url;
  }
}

export interface FetchDeliveryOptions {
  /** Slug del proyecto (o usa `host`). */
  slug?: string;
  /** Dominio propio: usa /api/v1/delivery/by-domain/:host. */
  host?: string;
  /** URL del CMS (por defecto https://webproai.tech). */
  baseUrl?: string;
  /** Pide borradores. Sin previewToken válido el servidor devuelve lo publicado (contrato 2.6). */
  preview?: boolean;
  previewToken?: string;
  /** Segundos de ISR en Next.js (por defecto 60). `false` = sin caché. Se ignora en preview. */
  revalidate?: number | false;
  /** Etiquetas de caché de Next.js (por defecto `cms:<slug>`), para revalidateTag desde el webhook. */
  tags?: string[];
  fetch?: typeof fetch;
  init?: RequestInit;
  timeoutMs?: number;
}

export function normalizeBaseUrl(url?: string): string {
  return (url || DEFAULT_CMS_URL).replace(/\/+$/, '').replace(/\/api$/, '');
}

/** Construye la URL de delivery. */
export function deliveryUrl(opts: FetchDeliveryOptions): string {
  const base = normalizeBaseUrl(opts.baseUrl);
  const path = opts.host
    ? `/api/v1/delivery/by-domain/${encodeURIComponent(opts.host)}`
    : `/api/v1/delivery/${encodeURIComponent(opts.slug || '')}`;
  const q = new URLSearchParams();
  if (opts.preview) {
    q.set('preview', '1');
    if (opts.previewToken) q.set('previewToken', opts.previewToken);
  }
  const qs = q.toString();
  return `${base}${path}${qs ? `?${qs}` : ''}`;
}

/**
 * Descarga el contenido del sitio. Lanza CmsDeliveryError si falla.
 * En Next.js cachea con ISR (`revalidate`) y etiquetas; en preview usa `no-store`.
 */
export async function fetchDelivery(opts: FetchDeliveryOptions): Promise<DeliveryPayload> {
  if (!opts.slug && !opts.host) throw new Error('fetchDelivery requiere slug o host');
  const url = deliveryUrl(opts);
  const f = opts.fetch || fetch;
  const init: RequestInit & { next?: { revalidate?: number | false; tags?: string[] } } = { ...(opts.init || {}) };
  if (opts.preview) init.cache = 'no-store';
  else if (opts.revalidate === false) init.cache = 'no-store';
  else init.next = { revalidate: opts.revalidate ?? 60, tags: opts.tags || [`cms:${opts.slug || opts.host}`] };
  if (opts.timeoutMs && typeof AbortSignal !== 'undefined' && 'timeout' in AbortSignal) {
    init.signal = (AbortSignal as any).timeout(opts.timeoutMs);
  }
  const res = await f(url, init);
  if (!res.ok) throw new CmsDeliveryError(`Delivery respondió HTTP ${res.status}`, res.status, url);
  return (await res.json()) as DeliveryPayload;
}

/** Igual que fetchDelivery pero devuelve null ante cualquier error (útil para no romper el render). */
export async function tryFetchDelivery(opts: FetchDeliveryOptions): Promise<DeliveryPayload | null> {
  try {
    return await fetchDelivery(opts);
  } catch {
    return null;
  }
}

// ---------- páginas y secciones ----------

export function normalizePageSlug(slug?: string): string {
  if (!slug || slug === '/' || /^(home|inicio|index)$/i.test(slug)) return '/';
  return slug.startsWith('/') ? slug : `/${slug}`;
}

export function getPage(p: DeliveryPayload | null | undefined, slug = '/'): CmsPage | undefined {
  const wanted = normalizePageSlug(slug);
  return p?.pages?.find((x) => normalizePageSlug(x.slug) === wanted);
}

/**
 * Página del CMS para una ruta del sitio: coincidencia exacta o el prefijo más largo
 * (`/producto/creatina` → `/producto` si existe esa página). Sin coincidencia: `/`.
 * `basePath` se quita antes (p. ej. "/site/demo").
 */
export function pageSlugFromPath(pathname: string | undefined | null, p?: DeliveryPayload | null, basePath = ''): string {
  let path = String(pathname || '/').split(/[?#]/)[0] || '/';
  const base = basePath.replace(/\/+$/, '');
  if (base && (path === base || path.startsWith(`${base}/`))) path = path.slice(base.length) || '/';
  path = normalizePageSlug(path.replace(/\/+$/, '') || '/');
  const slugs = (p?.pages || []).map((pg) => normalizePageSlug(pg.slug));
  if (!slugs.length) return path;
  if (slugs.includes(path)) return path;
  const prefix = slugs.filter((s) => s !== '/' && path.startsWith(`${s}/`)).sort((a, b) => b.length - a.length)[0];
  return prefix || '/';
}

function toRef<T extends SectionData>(row: { id: string; key: string; name?: string; isVisible?: boolean; order?: number; data?: SectionData }, fallbackOrder = 0): CmsSectionRef<T> {
  const data = (row.data || {}) as T;
  return {
    id: row.id,
    key: row.key,
    name: row.name,
    block: (data as SectionData)._block || null,
    isVisible: row.isVisible !== false,
    order: row.order ?? fallbackOrder,
    data,
  };
}

/** Secciones visibles de una página, en orden. `includeHidden` para el editor. */
export function getSections(p: DeliveryPayload | null | undefined, pageSlug = '/', { includeHidden = false } = {}): CmsSectionRef[] {
  const page = getPage(p, pageSlug);
  if (!page) return [];
  const rows = page.sectionsList?.length
    ? page.sectionsList
    : Object.entries(page.sections || {}).map(([key, data], i) => ({ id: `sec-${key}`, key, data, order: i, isVisible: true }));
  return rows
    .map((r, i) => toRef(r, i))
    .filter((s) => includeHidden || s.isVisible)
    .sort((a, b) => a.order - b.order);
}

/**
 * Sección por clave. Si no existe devuelve una referencia vacía con `isVisible: false`
 * para que el componente pueda decidir no renderizar.
 */
export function getSection<T extends SectionData = SectionData>(p: DeliveryPayload | null | undefined, pageSlug: string, key: string): CmsSectionRef<T> {
  const page = getPage(p, pageSlug);
  const row = page?.sectionsList?.find((s) => s.key === key);
  if (row) return toRef<T>(row);
  const data = page?.sections?.[key];
  if (data) return toRef<T>({ id: `sec-${key}`, key, data, isVisible: true });
  return { id: `sec-${key}`, key, block: null, isVisible: false, order: 0, data: {} as T };
}

/** Secciones de un tipo de bloque (contrato 2.3), en una página o en todas. */
export function findSectionsByBlock(p: DeliveryPayload | null | undefined, block: string, pageSlug?: string): CmsSectionRef[] {
  const pages = pageSlug ? [getPage(p, pageSlug)].filter(Boolean) : p?.pages || [];
  return (pages as CmsPage[]).flatMap((pg) => getSections(p, pg.slug).filter((s) => s.block === block || s.block?.startsWith(`${block}.`)));
}

export function sectionVisible(p: DeliveryPayload | null | undefined, pageSlug: string, key: string): boolean {
  return getSection(p, pageSlug, key).isVisible;
}

// ---------- global ----------

/** Valor de `global` con ruta con puntos (ej. "ui.addToCart"). */
export function getGlobal<T = any>(p: DeliveryPayload | null | undefined, dotted: string, fallback?: T): T {
  let cur: any = p?.global;
  for (const k of dotted.split('.')) cur = cur?.[k];
  return (cur === undefined || cur === null || cur === '' ? fallback : cur) as T;
}

// ---------- colecciones y productos ----------

const STORE_SLUGS = /^(productos|products|catalogo|catálogo|tienda|shop|store)$/i;

export function getCollection(p: DeliveryPayload | null | undefined, slug: string): CollectionItem[] {
  return p?.collections?.[slug] || [];
}

/** Slug de la colección de tienda (isStore o productos/products/catalogo). */
export function getStoreCollectionSlug(p: DeliveryPayload | null | undefined): string | undefined {
  const defs = p?.collectionDefinitions || {};
  const flagged = Object.values(defs).find((d) => d?.isStore);
  if (flagged) return flagged.slug;
  return Object.keys(p?.collections || {}).find((k) => STORE_SLUGS.test(k));
}

/** Número desde texto de precio con formato colombiano ("$ 45.000" → 45000). */
export function toNumber(v: unknown): number | undefined {
  if (v === null || v === undefined || v === '') return undefined;
  if (typeof v === 'number') return Number.isFinite(v) ? v : undefined;
  let s = String(v).replace(/[^\d.,-]/g, '');
  if (/^-?\d{1,3}(\.\d{3})+(,\d+)?$/.test(s)) s = s.replace(/\./g, '').replace(',', '.');
  else if (/^-?\d{1,3}(,\d{3})+(\.\d+)?$/.test(s)) s = s.replace(/,/g, '');
  else s = s.replace(',', '.');
  const n = Number(s);
  return s && Number.isFinite(n) ? n : undefined;
}

export function splitList(v?: string | string[], sep: RegExp = /\s*[|\n]\s*/): string[] {
  if (Array.isArray(v)) return v.map(String).filter(Boolean);
  return (v || '').split(sep).map((s) => s.trim()).filter(Boolean);
}

export function normalizeProduct(raw: CollectionItem): Product {
  const variants: ProductVariant[] = Array.isArray(raw.variants)
    ? raw.variants
        .filter((v: any) => v && v.label)
        .map((v: any) => {
          const w = unitWeightKg(v);
          return { label: String(v.label), price: toNumber(v.price), stock: toNumber(v.stock), sku: v.sku, ...(w !== undefined ? { weightKg: w } : {}) };
        })
    : [];
  const stock = toNumber(raw.stock);
  const variantStock = variants.some((v) => v.stock === undefined || v.stock > 0);
  const ratingCount = toNumber(raw.ratingCount) || 0;
  const weightKg = unitWeightKg(raw);
  return {
    ...raw,
    title: raw.title || raw.name || '',
    price: toNumber(raw.price) ?? 0,
    compareAtPrice: toNumber(raw.compareAtPrice),
    stock,
    gallery: splitList(raw.gallery),
    variants,
    inStock: variants.length ? variantStock : stock === undefined || stock > 0,
    ratingCount,
    ratingAverage: ratingCount ? toNumber(raw.ratingAverage) || 0 : 0,
    isDigital: raw.isDigital === true || raw.isDigital === 'true',
    ...(weightKg !== undefined ? { weightKg } : {}),
    ...(toNumber(raw.maxPerCustomer) ? { maxPerCustomer: Math.floor(toNumber(raw.maxPerCustomer) as number) } : {}),
  };
}

/** Peso por unidad en kg: `weightKg`, o `weight` + `weightUnit` (g | kg | lb). Misma regla que el backend. */
export function unitWeightKg(data: Record<string, any> | null | undefined): number | undefined {
  if (!data) return undefined;
  const kg = toNumber(data.weightKg);
  if (kg !== undefined && kg > 0) return kg;
  const w = toNumber(data.weight);
  if (w === undefined || w <= 0) return undefined;
  const unit = String(data.weightUnit || 'kg').trim().toLowerCase();
  if (unit === 'g' || unit === 'gr' || unit === 'gramos') return w / 1000;
  if (unit === 'lb' || unit === 'lbs') return w * 0.453592;
  return w;
}

/** true si el precio anterior (`compareAtPrice`) es mayor que el actual (badge «Oferta»). */
export function isOnSale(product: Pick<Product, 'price' | 'compareAtPrice'> | null | undefined): boolean {
  return Boolean(product && product.compareAtPrice && product.compareAtPrice > product.price);
}

/** Porcentaje de descuento frente a `compareAtPrice` (0 si no está en oferta). */
export function discountPercent(product: Pick<Product, 'price' | 'compareAtPrice'> | null | undefined): number {
  if (!isOnSale(product)) return 0;
  return Math.round((1 - product!.price / (product!.compareAtPrice as number)) * 100);
}

export interface GetProductsOptions {
  collection?: string;
  category?: string;
  featured?: boolean;
  /** Incluir ítems no publicados (solo llegan en preview). */
  includeUnpublished?: boolean;
}

export function getProducts(p: DeliveryPayload | null | undefined, opts: GetProductsOptions = {}): Product[] {
  const slug = opts.collection || getStoreCollectionSlug(p);
  if (!slug) return [];
  return getCollection(p, slug)
    .filter((x) => opts.includeUnpublished || !x.status || x.status === 'PUBLISHED')
    .map(normalizeProduct)
    .filter((x) => !opts.category || x.category === opts.category)
    .filter((x) => opts.featured === undefined || Boolean(x.isFeatured) === opts.featured);
}

export function getProduct(p: DeliveryPayload | null | undefined, slugOrId: string, collection?: string): Product | undefined {
  return getProducts(p, { collection, includeUnpublished: true }).find((x) => x.slug === slugOrId || x.id === slugOrId);
}

/** Categorías del filtro: las del esquema de la colección, o las presentes en los productos. */
export function getCategories(p: DeliveryPayload | null | undefined, collection?: string): string[] {
  const slug = collection || getStoreCollectionSlug(p);
  const defs = slug ? p?.collectionDefinitions?.[slug]?.categories : undefined;
  if (defs?.length) return defs;
  return Array.from(new Set(getProducts(p, { collection: slug }).map((x) => x.category).filter(Boolean) as string[]));
}

/** Precio efectivo (de la variante si tiene precio propio). */
export function productPrice(product: Product, variantLabel?: string): number {
  const v = variantLabel ? product.variants.find((x) => x.label === variantLabel) : undefined;
  return v?.price ?? product.price;
}

/**
 * @deprecated Desde 4.4: usa `formatMoney(amount, currency, locale)` o `moneyFormatter(payload)` (respetan
 * el locale del proyecto y los decimales de cada moneda). Se mantiene por compatibilidad.
 */
export function formatPrice(amount: number, currency = 'COP', locale = 'es-CO'): string {
  return new Intl.NumberFormat(locale, { style: 'currency', currency, maximumFractionDigits: currency === 'COP' ? 0 : 2 }).format(amount || 0);
}

/** URL absoluta para medios del CMS (`/uploads/...` → `https://webproai.tech/uploads/...`). */
export function mediaUrl(url: string | undefined, baseUrl?: string): string {
  if (!url) return '';
  if (/^(https?:)?\/\//.test(url) || url.startsWith('data:')) return url;
  return `${normalizeBaseUrl(baseUrl)}${url.startsWith('/') ? '' : '/'}${url}`;
}
