/**
 * Carrito con recuperación (v5 F2.2, docs/ABANDONED-CART.md) y «Pedir por WhatsApp» (v5 F2.7,
 * docs/WHATSAPP.md) para storefronts headless. Sin React: `createCart()` guarda el carrito en el
 * navegador y, en cuanto hay correo o teléfono, lo sincroniza con el CMS (con espera, sin saturar
 * la API) para que la tienda pueda recordárselo al comprador. El enlace `/carrito/recuperar?token=…`
 * lo reconstruye con `recover()`.
 *
 *   const cart = createCart({ slug: 'arsenal' });
 *   cart.add({ productId: 'creatina', title: 'Creatina', unitPrice: 95000 }, 2);
 *   cart.setContact({ email: 'ana@x.co', consent: true });   // desde el checkout
 *   await cart.recoverFromUrl();                               // en /carrito/recuperar
 *   const wa = await buildWhatsAppOrder({ slug: 'arsenal', items: cart.items });
 *   window.location.assign(wa.whatsappUrl);
 *
 * Los precios del carrito son solo para mostrar: el CMS los vuelve a calcular al crear el pedido.
 */
import { normalizeBaseUrl } from './delivery.js';
import { ShopError, type ShopStorage } from './shop.js';

export interface CartLine {
  productId: string;
  title: string;
  /** Solo para mostrar mientras llega la cotización; el servidor usa el precio del catálogo. */
  unitPrice: number;
  quantity: number;
  variant?: string;
  imageUrl?: string;
  collectionSlug?: string;
  sku?: string;
}

/** Lo que recibe `add()`: título y precio son opcionales (el servidor cotiza con el catálogo). */
export type CartLineInput = Omit<CartLine, 'quantity' | 'title' | 'unitPrice'> & { title?: string; unitPrice?: number; quantity?: number };

export interface CartContact {
  email?: string;
  phone?: string;
  name?: string;
  /** El comprador aceptó que le recuerden el carrito (la tienda puede exigirlo: requireConsent). */
  consent?: boolean;
}

export interface CartRecovery {
  cartKey: string;
  items: CartLine[];
  currency: string;
  subtotal: number;
  email: string | null;
  phone: string | null;
  name: string | null;
  /** Cupón configurado en la secuencia de recuperación (o null). */
  couponCode: string | null;
  /** El carrito ya terminó en un pedido. */
  alreadyOrdered: boolean;
}

export interface CartOptions {
  slug: string;
  apiUrl?: string;
  /** Por defecto localStorage si existe; `null` = solo memoria. */
  storage?: ShopStorage | null;
  fetch?: typeof fetch;
  /** Espera antes de sincronizar con el CMS (ms). Por defecto 1500. */
  debounceMs?: number;
  /** `false` desactiva la sincronización (el carrito sigue funcionando en el navegador). */
  sync?: boolean;
  /** Origen del guardado (`sdk` por defecto). */
  source?: 'site' | 'sdk';
}

export interface Cart {
  readonly slug: string;
  readonly items: CartLine[];
  readonly count: number;
  readonly subtotal: number;
  readonly contact: CartContact;
  /** Cupones del carrito (docs/PRICING.md); el servidor los valida al cotizar y al crear el pedido. */
  readonly couponCodes: string[];
  /** Tarjetas de regalo del carrito. */
  readonly giftCardCodes: string[];
  /** Clave aleatoria de este carrito (la envía el sincronizador). */
  readonly cartKey: string;
  /** `quantity` (o `line.quantity`) por defecto 1; misma línea (producto + variante) suma cantidades. */
  add(line: CartLineInput, quantity?: number): void;
  setQuantity(index: number, quantity: number): void;
  remove(index: number): void;
  clear(): void;
  /** Reemplaza cupones o tarjetas de regalo (en MAYÚSCULAS, sin espacios). */
  setCodes(codes: { couponCodes?: string[]; giftCardCodes?: string[] }): void;
  /** Datos de contacto del checkout: con correo o teléfono el carrito se guarda en el CMS. */
  setContact(contact: CartContact): void;
  /** Sincroniza ya (sin esperar el debounce). */
  flush(): Promise<void>;
  /** Restaura el carrito del enlace firmado; reemplaza los ítems locales. */
  recover(token: string): Promise<CartRecovery>;
  /** Lee `?token=` de la URL actual y restaura; null si no hay token. */
  recoverFromUrl(search?: string): Promise<CartRecovery | null>;
  /** Avisa cada vez que cambian ítems o contacto. */
  subscribe(listener: () => void): () => void;
}

const isBrowser = () => typeof globalThis !== 'undefined' && typeof (globalThis as any).document !== 'undefined';

function memory(): ShopStorage {
  const m = new Map<string, string>();
  return { getItem: (k) => (m.has(k) ? (m.get(k) as string) : null), setItem: (k, v) => void m.set(k, String(v)), removeItem: (k) => void m.delete(k) };
}

function defaultStorage(): ShopStorage {
  try {
    const ls = (globalThis as { localStorage?: ShopStorage }).localStorage;
    if (ls) return ls;
  } catch {
    // almacenamiento bloqueado
  }
  return memory();
}

function randomKey(): string {
  const c = (globalThis as any).crypto;
  if (c?.randomUUID) return `ck_${String(c.randomUUID()).replace(/-/g, '')}`;
  let s = 'ck_';
  for (let i = 0; i < 32; i++) s += Math.floor(Math.random() * 36).toString(36);
  return s;
}

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
/** Código de cupón o tarjeta normalizado (MAYÚSCULAS, sin espacios). */
export const normalizeCode = (c: string) => String(c || '').trim().toUpperCase().replace(/\s+/g, '');
const codeList = (v: unknown): string[] => (Array.isArray(v) ? Array.from(new Set(v.map((c) => normalizeCode(String(c))).filter(Boolean))).slice(0, 10) : []);
const cleanLine = (i: any): CartLine | null => {
  if (!i || typeof i.productId !== 'string' || !i.productId) return null;
  const quantity = Math.min(99, Math.floor(Number(i.quantity) || 0));
  if (quantity <= 0) return null;
  return { ...i, title: String(i.title || ''), unitPrice: Number(i.unitPrice) || 0, quantity };
};
const hasContact = (c: CartContact) => Boolean((c.email && EMAIL_RE.test(c.email.trim())) || String(c.phone || '').replace(/[^0-9]/g, '').length >= 7);

async function post<T>(fetchImpl: typeof fetch | undefined, url: string, body: unknown): Promise<T> {
  if (!fetchImpl) throw new ShopError('No hay fetch disponible.', 0, 'NO_FETCH');
  let res: Response;
  try {
    res = await fetchImpl(url, { method: 'POST', headers: { 'Content-Type': 'application/json', Accept: 'application/json' }, body: JSON.stringify(body) });
  } catch (e) {
    throw new ShopError('No se pudo conectar con la tienda. Revisa tu conexión.', 0, 'NETWORK_ERROR', { cause: String((e as Error)?.message || e) });
  }
  const text = await res.text();
  let data: any = {};
  try {
    data = text ? JSON.parse(text) : {};
  } catch {
    data = { message: text };
  }
  if (!res.ok) {
    const raw = data?.message;
    throw new ShopError(Array.isArray(raw) ? raw.join('. ') : typeof raw === 'string' && raw ? raw : 'Error de la tienda.', res.status, typeof data?.code === 'string' ? data.code : `HTTP_${res.status}`, data);
  }
  return data as T;
}

/** Token del enlace de recuperación en la URL (`?token=`). */
export function readCartRecoveryToken(search?: string): string | null {
  const s = search ?? (globalThis as any).location?.search ?? '';
  try {
    const t = new URLSearchParams(s).get('token');
    return t && /^[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+$/.test(t) ? t : null;
  } catch {
    return null;
  }
}

export function createCart(opts: CartOptions): Cart {
  if (!opts?.slug) throw new Error('createCart requiere slug');
  const slug = opts.slug;
  const apiUrl = normalizeBaseUrl(opts.apiUrl);
  const fetchImpl: typeof fetch | undefined = opts.fetch || (typeof fetch === 'function' ? fetch.bind(globalThis) : undefined);
  const storage = opts.storage === null ? memory() : opts.storage || defaultStorage();
  const itemsKey = `ltn_cart_${slug}`;
  const metaKey = `ltn_cart_${slug}_meta`;
  const debounceMs = opts.debounceMs ?? 1500;
  const syncOn = opts.sync !== false;
  const listeners = new Set<() => void>();
  const read = (k: string) => {
    try {
      return JSON.parse(storage.getItem(k) || 'null');
    } catch {
      return null;
    }
  };
  const write = (k: string, v: unknown) => {
    try {
      storage.setItem(k, JSON.stringify(v));
    } catch {
      // sin persistencia
    }
  };

  // Formato anterior del SDK (v5 F2 precios): { items, couponCodes, giftCardCodes } en la misma clave.
  const savedItems = read(itemsKey);
  const legacy = savedItems && !Array.isArray(savedItems) && Array.isArray(savedItems.items) ? savedItems : null;
  let items: CartLine[] = (Array.isArray(savedItems) ? savedItems : legacy ? legacy.items : []).map(cleanLine).filter(Boolean) as CartLine[];
  const meta = read(metaKey) || {};
  let couponCodes: string[] = codeList(meta.couponCodes ?? legacy?.couponCodes);
  let giftCardCodes: string[] = codeList(meta.giftCardCodes ?? legacy?.giftCardCodes);
  let cartKey: string = typeof meta.cartKey === 'string' && meta.cartKey.length >= 16 ? meta.cartKey : randomKey();
  let contact: CartContact = meta.contact && typeof meta.contact === 'object' ? meta.contact : {};
  let timer: ReturnType<typeof setTimeout> | null = null;
  let lastSent = '';

  const persist = () => {
    write(itemsKey, items);
    write(metaKey, { cartKey, contact, couponCodes, giftCardCodes });
  };
  const emit = () => listeners.forEach((l) => l());

  async function flush() {
    if (timer) {
      clearTimeout(timer);
      timer = null;
    }
    if (!syncOn || !hasContact(contact)) return;
    const body = {
      cartKey,
      email: contact.email || undefined,
      phone: contact.phone || undefined,
      name: contact.name || undefined,
      consent: contact.consent,
      source: opts.source || 'sdk',
      items: items.map((i) => ({ productId: i.productId, quantity: i.quantity, variant: i.variant, title: i.title, imageUrl: i.imageUrl, collectionSlug: i.collectionSlug })),
    };
    const sig = JSON.stringify(body);
    if (sig === lastSent) return;
    lastSent = sig;
    try {
      await post(fetchImpl, `${apiUrl}/api/shop/${encodeURIComponent(slug)}/carts`, body);
    } catch {
      // De mejor esfuerzo: un fallo no rompe el carrito; se reintenta en el próximo cambio.
      lastSent = '';
    }
  }

  const schedule = () => {
    if (!syncOn || !hasContact(contact)) return;
    if (timer) clearTimeout(timer);
    timer = setTimeout(() => void flush(), debounceMs);
    (timer as any)?.unref?.();
  };

  const changed = () => {
    persist();
    emit();
    schedule();
  };

  async function recover(token: string): Promise<CartRecovery> {
    const r = await post<CartRecovery>(fetchImpl, `${apiUrl}/api/shop/${encodeURIComponent(slug)}/carts/recover`, { token });
    cartKey = r.cartKey || cartKey;
    items = (Array.isArray(r.items) ? r.items : []).map((i: any) => ({
      productId: String(i.productId),
      title: String(i.title || ''),
      unitPrice: Number(i.unitPrice) || 0,
      quantity: Math.max(1, Number(i.quantity) || 1),
      ...(i.variant ? { variant: String(i.variant) } : {}),
      ...(i.imageUrl ? { imageUrl: String(i.imageUrl) } : {}),
      ...(i.collectionSlug ? { collectionSlug: String(i.collectionSlug) } : {}),
    }));
    contact = { ...contact, ...(r.email ? { email: r.email } : {}), ...(r.phone ? { phone: r.phone } : {}), ...(r.name ? { name: r.name } : {}) };
    lastSent = '';
    persist();
    emit();
    return r;
  }

  const cart: Cart = {
    slug,
    get items() {
      return items;
    },
    get count() {
      return items.reduce((a, b) => a + b.quantity, 0);
    },
    get subtotal() {
      return items.reduce((a, b) => a + b.unitPrice * b.quantity, 0);
    },
    get contact() {
      return contact;
    },
    get couponCodes() {
      return couponCodes;
    },
    get giftCardCodes() {
      return giftCardCodes;
    },
    get cartKey() {
      return cartKey;
    },
    add(input, quantity) {
      const { quantity: inQty, ...line } = input;
      const qty = Math.max(1, Math.floor(Number(quantity ?? inQty) || 1));
      const idx = items.findIndex((p) => p.productId === line.productId && (p.variant || '') === (line.variant || ''));
      if (idx >= 0) {
        items = items.map((it, i) =>
          i === idx
            ? { ...it, ...line, title: line.title ?? it.title, unitPrice: line.unitPrice ?? it.unitPrice, quantity: Math.min(99, it.quantity + qty) }
            : it,
        );
      } else items = [...items, { ...line, title: String(line.title || ''), unitPrice: Number(line.unitPrice) || 0, quantity: Math.min(99, qty) }];
      changed();
    },
    setQuantity(index, quantity) {
      const q = Math.floor(Number(quantity) || 0);
      items = items.map((it, i) => (i === index ? { ...it, quantity: Math.min(99, q) } : it)).filter((it) => it.quantity > 0);
      changed();
    },
    remove(index) {
      items = items.filter((_, i) => i !== index);
      changed();
    },
    clear() {
      if (timer) {
        clearTimeout(timer);
        timer = null;
      }
      items = [];
      couponCodes = [];
      giftCardCodes = [];
      // Carrito nuevo después de un pedido: el anterior queda ligado a ese pedido en el CMS.
      cartKey = randomKey();
      lastSent = '';
      persist();
      emit();
    },
    setCodes(next) {
      if (next.couponCodes) couponCodes = codeList(next.couponCodes);
      if (next.giftCardCodes) giftCardCodes = codeList(next.giftCardCodes);
      persist();
      emit();
    },
    setContact(next) {
      contact = { ...contact, ...next };
      changed();
    },
    flush,
    recover,
    async recoverFromUrl(search) {
      const token = readCartRecoveryToken(search);
      return token ? recover(token) : null;
    },
    subscribe(listener) {
      listeners.add(listener);
      return () => listeners.delete(listener);
    },
  };
  // Último intento al cerrar la pestaña.
  if (isBrowser() && syncOn) {
    try {
      (globalThis as any).addEventListener?.('pagehide', () => void flush());
    } catch {
      // sin eventos de ventana
    }
  }
  return cart;
}

/* ------------------------------ WhatsApp ------------------------------ */

export interface WhatsAppOrderInput {
  slug: string;
  apiUrl?: string;
  fetch?: typeof fetch;
  items: Array<Pick<CartLine, 'productId' | 'quantity' | 'variant'>>;
  customerName?: string;
  customerPhone?: string;
  customerEmail?: string;
  notes?: string;
  shippingAddress?: { address?: string; city?: string; department?: string; country?: string; postalCode?: string; daneCode?: string; notes?: string };
  shippingZoneId?: string;
  /** v5 F2.9: opción de `quoteShipping()` (el servidor la re-cotiza). */
  shippingOptionId?: string;
  /** v5 F2 (docs/PRICING.md): el pedido se cotiza con cupones e impuestos igual que el checkout. */
  couponCodes?: string[];
  giftCardCodes?: string[];
}

export interface WhatsAppOrderResult {
  orderNumber: string;
  /** PENDING_WHATSAPP; PROCESSING si una tarjeta de regalo cubrió todo. */
  status: 'PENDING_WHATSAPP' | (string & {});
  paymentStatus?: string;
  /** Lo que falta por pagar (total − tarjetas de regalo). */
  totalAmount: number;
  subtotal: number;
  shippingCost: number;
  discountAmount?: number;
  taxAmount?: number;
  giftCardAmount?: number;
  currency: string;
  /** Desglose del servidor (descuentos, impuestos, tarjetas). */
  pricing?: unknown;
  /** Página para ver el pedido (?pedido=ORD-…). */
  orderUrl: string;
  /** Mensaje prellenado (ítems, total y link). */
  message: string;
  /** https://wa.me/<número de la tienda>?text=… */
  whatsappUrl: string;
  claimToken?: string;
}

/**
 * «Pedir por WhatsApp»: crea el pedido en el CMS (estado PENDING_WHATSAPP, precios del servidor) y
 * devuelve el enlace wa.me con el mensaje listo. La tienda debe tenerlo activo
 * (globalData.site.whatsappOrders.enabled) y un número de WhatsApp en el sitio.
 */
export async function buildWhatsAppOrder(input: WhatsAppOrderInput): Promise<WhatsAppOrderResult> {
  if (!input?.slug) throw new Error('buildWhatsAppOrder requiere slug');
  if (!Array.isArray(input.items) || !input.items.length) throw new ShopError('El carrito está vacío.', 400, 'EMPTY_CART');
  const fetchImpl = input.fetch || (typeof fetch === 'function' ? fetch.bind(globalThis) : undefined);
  const { slug, apiUrl, fetch: _f, ...body } = input;
  void _f;
  return post<WhatsAppOrderResult>(fetchImpl, `${normalizeBaseUrl(apiUrl)}/api/shop/${encodeURIComponent(slug)}/whatsapp-order`, {
    ...body,
    items: input.items.map((i) => ({ productId: i.productId, quantity: i.quantity, ...(i.variant ? { variant: i.variant } : {}) })),
    ...(input.couponCodes?.length ? { couponCodes: codeList(input.couponCodes) } : {}),
    ...(input.giftCardCodes?.length ? { giftCardCodes: codeList(input.giftCardCodes) } : {}),
  });
}

/** Mensaje de pedido sin crear pedido (alternativa sin API): `wa.me` con ítems y total estimado. */
export function whatsappOrderText(items: CartLine[], opts: { intro?: string; currency?: string; locale?: string } = {}): string {
  const currency = opts.currency || 'COP';
  const fmt = (n: number) => {
    try {
      return new Intl.NumberFormat(opts.locale || 'es-CO', { style: 'currency', currency, maximumFractionDigits: currency === 'COP' ? 0 : 2 }).format(n).replace(/ /g, ' ');
    } catch {
      return `${n} ${currency}`;
    }
  };
  const total = items.reduce((a, b) => a + b.unitPrice * b.quantity, 0);
  return [`${opts.intro || 'Hola, quiero hacer este pedido'}:`, ...items.map((i) => `• ${i.quantity} × ${i.title}${i.variant ? ` (${i.variant})` : ''} — ${fmt(i.unitPrice * i.quantity)}`), `Total: ${fmt(total)}`].join('\n');
}

export function waMeUrl(number: string, text: string): string {
  const digits = String(number || '').replace(/[^0-9]/g, '');
  return digits ? `https://wa.me/${digits}${text ? `?text=${encodeURIComponent(text)}` : ''}` : '';
}

/** `globalData.site.whatsappOrders` del delivery: si mostrar «Pedir por WhatsApp» en la ficha y el carrito. */
export function whatsappOrdersConfig(global: Record<string, any> | null | undefined): { enabled: boolean; product: boolean; cart: boolean; number: string; intro: string } {
  const g: Record<string, any> = global && typeof global === 'object' ? global : {};
  const w: Record<string, any> = g.site && typeof g.site === 'object' && g.site.whatsappOrders && typeof g.site.whatsappOrders === 'object' ? g.site.whatsappOrders : {};
  const number = String(w.number || g.whatsappNumber || '').replace(/[^0-9]/g, '');
  return {
    enabled: w.enabled === true && Boolean(number),
    product: w.product !== false,
    cart: w.cart !== false,
    number,
    intro: typeof w.intro === 'string' && w.intro.trim() ? w.intro.trim() : 'Hola, quiero hacer este pedido',
  };
}

/**
 * Baja de los recordatorios de carrito desde un storefront headless (el token es el del enlace de
 * baja del correo o del WhatsApp). Responde 404 si el enlace no es válido.
 */
export async function unsubscribeCartReminders(input: { slug: string; token: string; apiUrl?: string; fetch?: typeof fetch }): Promise<{ unsubscribed: true; [k: string]: unknown }> {
  if (!input?.slug) throw new Error('unsubscribeCartReminders requiere slug');
  if (!input.token) throw new ShopError('Falta el token del enlace de baja.', 400, 'MISSING_TOKEN');
  const fetchImpl = input.fetch || (typeof fetch === 'function' ? fetch.bind(globalThis) : undefined);
  const r = await post<Record<string, unknown>>(fetchImpl, `${normalizeBaseUrl(input.apiUrl)}/api/shop/${encodeURIComponent(input.slug)}/carts/unsubscribe`, { token: input.token });
  return { ...r, unsubscribed: true };
}
