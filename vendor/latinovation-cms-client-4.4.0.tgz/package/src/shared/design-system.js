// GENERADO desde shared/src/design-system.mjs por scripts/sync-shared.mjs. No editar a mano.
// Design System v2 (docs/EDITING-V4.1.md §A) — pure JS, no dependencies.
//
// Single source shared by the CMS renderer, the portal Theme Studio, the SDK and the agent tools.
// Generated copies (never edit them): frontend/src/shared-generated/design-system.mjs,
// backend/shared/src/design-system.mjs and packages/cms-client/src/shared/design-system.js
// (node frontend/scripts/sync-shared.mjs · node backend/scripts/sync-shared.mjs ·
// node packages/cms-client/scripts/sync-shared.mjs).
//
// Every function accepts a design system or a whole globalData (then `designSystem` is used and
// root-level legacy keys only fill gaps).
//
//   normalizeDesignSystem(ds)       legacy flat fields → clean v2 object (no defaults invented)
//   resolveDesignSystem(ds)         normalized v2 with every default and derived color filled in
//   designSystemToCssVars(ds)       Record<'--cms-…', string>, the exact list of §A
//   designSystemToCss(ds, scope)    `scope{--cms-…}`
//   designSystemFontLinks(ds)       Google Fonts stylesheet URLs
//   designSystemFontFaceCss(ds)     @font-face rules for typography.customFonts (alias designSystemFontFaces)
//   designSystemGlobalCss(ds)       sanitized globalCss
//   contrastReport(ds)              WCAG ratios for the text/background/primary pairs
//   sanitizeGlobalCss(css)          { css, errors } — strips what CSS must never do
//   DESIGN_PRESETS, applyPreset()   8 curated starting points
//
// Precedence when a stored object mixes both shapes: a legacy flat field (`primaryColor`, …)
// wins over its v2 twin, because only legacy writers still set flat fields. Writers that speak
// v2 should save the output of normalizeDesignSystem(), which never contains flat fields.

export const DESIGN_SYSTEM_VERSION = 2;

// ───────────────────────── colors ─────────────────────────

/** Parses #rgb, #rrggbb, #rrggbbaa and rgb()/rgba(); null for anything else. */
export function parseColor(input) {
  const s = String(input ?? '').trim();
  const m = s.match(/^#([0-9a-f]{3}|[0-9a-f]{6})([0-9a-f]{2})?$/i);
  if (m) {
    let h = m[1];
    if (h.length === 3) h = h.split('').map((c) => c + c).join('');
    return [parseInt(h.slice(0, 2), 16), parseInt(h.slice(2, 4), 16), parseInt(h.slice(4, 6), 16)];
  }
  const r = s.match(/^rgba?\(\s*(\d{1,3})[\s,]+(\d{1,3})[\s,]+(\d{1,3})/i);
  if (r) return [Number(r[1]), Number(r[2]), Number(r[3])].map((v) => Math.min(255, v));
  return null;
}

export function isColor(v) {
  return typeof v === 'string' && parseColor(v) !== null;
}

export function toHex(rgb) {
  return `#${rgb.map((v) => Math.round(Math.max(0, Math.min(255, v))).toString(16).padStart(2, '0')).join('')}`.toUpperCase();
}

/** Normalizes a color to upper-case #RRGGBB (null when it is not a color). */
export function normalizeHex(v) {
  const rgb = parseColor(v);
  return rgb ? toHex(rgb) : null;
}

export function relativeLuminance(color) {
  const rgb = Array.isArray(color) ? color : parseColor(color);
  if (!rgb) return 0;
  const [r, g, b] = rgb.map((v) => {
    const c = v / 255;
    return c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);
  });
  return 0.2126 * r + 0.7152 * g + 0.0722 * b;
}

/** WCAG 2.x contrast ratio (1–21). Unparseable colors return 1. */
export function contrastRatio(a, b) {
  const ra = parseColor(a);
  const rb = parseColor(b);
  if (!ra || !rb) return 1;
  const la = relativeLuminance(ra);
  const lb = relativeLuminance(rb);
  return (Math.max(la, lb) + 0.05) / (Math.min(la, lb) + 0.05);
}

/** Linear sRGB mix; `weightOfA` 1 → a, 0 → b. */
export function mixColors(a, b, weightOfA) {
  const ra = parseColor(a);
  const rb = parseColor(b);
  if (!ra || !rb) return a;
  const w = Math.max(0, Math.min(1, weightOfA));
  return toHex([0, 1, 2].map((i) => ra[i] * w + rb[i] * (1 - w)));
}

/** First candidate reaching `min` against `bg`, else the best one. */
export function readableOn(bg, candidates, min = 4.5) {
  let best = candidates.find(isColor) || '#111111';
  let bestRatio = 0;
  for (const c of candidates) {
    if (!isColor(c)) continue;
    const r = contrastRatio(bg, c);
    if (r >= min) return c;
    if (r > bestRatio) {
      best = c;
      bestRatio = r;
    }
  }
  return best;
}

/** `Arena Fina` → `arena-fina` (for --cms-color-<slug>). */
export function colorSlug(name) {
  return String(name ?? '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 40);
}

export const COLOR_ROLES = [
  { key: 'background', var: '--cms-bg', label: 'Fondo' },
  { key: 'surface', var: '--cms-surface', label: 'Superficie (tarjetas)' },
  { key: 'surfaceAlt', var: '--cms-surface-alt', label: 'Fondo alterno' },
  { key: 'text', var: '--cms-text', label: 'Texto' },
  { key: 'muted', var: '--cms-muted', label: 'Texto secundario' },
  { key: 'border', var: '--cms-border', label: 'Bordes' },
  { key: 'primary', var: '--cms-primary', label: 'Primario' },
  { key: 'primaryText', var: '--cms-primary-text', label: 'Texto sobre primario' },
  { key: 'secondary', var: '--cms-secondary', label: 'Secundario' },
  { key: 'secondaryText', var: '--cms-secondary-text', label: 'Texto sobre secundario' },
  { key: 'accent', var: '--cms-accent', label: 'Acento' },
  { key: 'success', var: '--cms-success', label: 'Éxito' },
  { key: 'danger', var: '--cms-danger', label: 'Error' },
];

// ───────────────────────── fonts ─────────────────────────

const GENERIC_STACKS = {
  serif: '"Fraunces", "Iowan Old Style", Georgia, serif',
  sans: '"Plus Jakarta Sans", ui-sans-serif, system-ui, sans-serif',
  'sans-serif': '"Plus Jakarta Sans", ui-sans-serif, system-ui, sans-serif',
  mono: '"JetBrains Mono", ui-monospace, monospace',
  monospace: '"JetBrains Mono", ui-monospace, monospace',
  'system-ui': 'ui-sans-serif, system-ui, sans-serif',
};


const SERIF_HINT =
  /serif|fraunces|playfair|newsreader|garamond|lora|cormorant|baskerville|merriweather|dm serif|instrument serif|crimson|spectral|literata|bodoni|young serif|marcellus|cinzel|prata|gloock|libre caslon|eb garamond|petrona|bitter|zilla|alegreya(?! sans)|vollkorn|cardo|domine|gelasio|noto serif|pt serif|roboto serif|source serif|rufina|yeseva|abril|dm serif/i;
const MONO_HINT = /mono|code|courier|inconsolata/i;
const HAND_HINT = /caveat|dancing|pacifico|satisfy|great vibes|sacramento|kalam|shadows into|indie flower|permanent marker|homemade|amatic|patrick hand|allura|parisienne/i;

export function isSerifFont(name) {
  const n = String(name ?? '').trim().toLowerCase();
  if (n === 'serif') return true;
  if (n === 'sans' || n === 'sans-serif') return false;
  return SERIF_HINT.test(n) && !/sans/.test(n);
}

export function fontCategory(name) {
  const n = String(name ?? '').trim();
  if (MONO_HINT.test(n)) return 'monospace';
  if (HAND_HINT.test(n)) return 'handwriting';
  return isSerifFont(n) ? 'serif' : 'sans-serif';
}

// Same fallbacks as the block renderer (frontend runtime/tokens.ts) so --cms-font-* and --bk-font-* agree.
const CATEGORY_FALLBACK = {
  serif: 'Georgia, serif',
  'sans-serif': 'ui-sans-serif, system-ui, sans-serif',
  display: 'ui-sans-serif, system-ui, sans-serif',
  handwriting: 'cursive',
  monospace: 'ui-monospace, monospace',
};

/** CSS font-family stack for a family name (generic aliases map to the bundled defaults). */
export function fontStack(family, category) {
  const n = String(family ?? '').trim();
  if (!n) return GENERIC_STACKS.sans;
  if (GENERIC_STACKS[n.toLowerCase()]) return GENERIC_STACKS[n.toLowerCase()];
  const cat = CATEGORY_FALLBACK[category] ? category : fontCategory(n);
  return `"${n.replace(/["\\;{}<>]/g, '')}", ${CATEGORY_FALLBACK[cat]}`;
}

function cleanFamily(v) {
  return String(v ?? '')
    .replace(/["\\;{}<>]/g, '')
    .trim()
    .slice(0, 80);
}

function cleanWeights(v, fallback) {
  const list = (Array.isArray(v) ? v : [])
    .map((w) => Math.round(Number(w) / 100) * 100)
    .filter((w) => w >= 100 && w <= 900);
  const uniq = Array.from(new Set(list)).sort((a, b) => a - b);
  return uniq.length ? uniq : fallback;
}

function safeUrl(v) {
  const s = String(v ?? '').trim();
  if (!s) return '';
  if (/^https:\/\//i.test(s) || /^\/(?!\/)/.test(s)) return s.replace(/["'()\\\s<>]/g, (c) => encodeURIComponent(c));
  return '';
}

function normalizeFont(v) {
  if (v === undefined || v === null || v === '') return undefined;
  if (typeof v === 'string') {
    const family = cleanFamily(v);
    if (!family) return undefined;
    const generic = GENERIC_STACKS[family.toLowerCase()] !== undefined;
    return { family, source: generic ? 'system' : 'google' };
  }
  if (typeof v !== 'object') return undefined;
  const family = cleanFamily(v.family);
  if (!family) return undefined;
  const out = { family, source: ['google', 'custom', 'system'].includes(v.source) ? v.source : 'google' };
  const weights = cleanWeights(v.weights, null);
  if (weights) out.weights = weights;
  if (['serif', 'sans-serif', 'display', 'handwriting', 'monospace'].includes(v.category)) out.category = v.category;
  const url = safeUrl(v.url);
  if (url) out.url = url;
  return out;
}

// ───────────────────────── defaults ─────────────────────────

export const DEFAULT_DESIGN_SYSTEM = Object.freeze({
  version: 2,
  colors: {
    background: '#FFFFFF',
    text: '#15171C',
    primary: '#15171C',
    success: '#1E7A4C',
    danger: '#B42318',
    custom: [],
  },
  typography: {
    headingFont: { family: 'sans', source: 'system' },
    bodyFont: { family: 'sans', source: 'system' },
    baseSize: 16,
    scaleRatio: 1.25,
    headingWeight: 600,
    bodyWeight: 400,
    headingCase: 'none',
    headingTracking: -0.02,
    bodyLineHeight: 1.6,
    customFonts: [],
  },
  shape: { radiusSm: 4, radiusMd: 6, radiusLg: 14, radiusFull: 999, borderWidth: 1 },
  shadow: {
    sm: '0 1px 2px rgb(0 0 0 / 0.06)',
    md: '0 6px 20px -8px rgb(0 0 0 / 0.2)',
    lg: '0 24px 60px -24px rgb(0 0 0 / 0.3)',
  },
  spacing: { sectionY: 136, sectionYMobile: 68, gutter: 56, maxWidth: 1240 },
  buttons: { style: 'solid', shape: 'rounded', case: 'none', weight: 600, paddingY: 12, paddingX: 22 },
  motion: { level: 'subtle', durationMs: 200 },
  header: { variant: 'simple', sticky: true, transparentOnHero: false, showSearch: false, showCart: true },
  footer: { variant: 'columns', showNewsletter: false },
  globalCss: '',
});

const ENUMS = {
  headingCase: ['none', 'uppercase', 'capitalize'],
  buttonStyle: ['solid', 'outline', 'soft', 'link'],
  buttonShape: ['square', 'rounded', 'pill'],
  buttonCase: ['none', 'uppercase'],
  motion: ['none', 'subtle', 'expressive'],
  header: ['simple', 'centered', 'split', 'minimal'],
  footer: ['columns', 'simple', 'big'],
  density: ['compact', 'comfortable', 'airy'],
};

const isObj = (v) => v !== null && typeof v === 'object' && !Array.isArray(v);

function num(v, min, max) {
  if (v === undefined || v === null || v === '') return undefined;
  const n = typeof v === 'number' ? v : parseFloat(String(v));
  if (!Number.isFinite(n)) return undefined;
  return Math.max(min, Math.min(max, n));
}

function px(v, min, max) {
  if (typeof v === 'string' && /rem$/.test(v.trim())) return num(parseFloat(v) * 16, min, max);
  return num(v, min, max);
}

function oneOf(v, list) {
  return list.includes(v) ? v : undefined;
}

function bool(v) {
  return typeof v === 'boolean' ? v : v === 'true' ? true : v === 'false' ? false : undefined;
}

function shadowValue(v) {
  if (typeof v !== 'string') return undefined;
  const s = v.trim().slice(0, 240);
  if (!s) return undefined;
  if (s === 'none') return 'none';
  // Only lengths, colors and keywords; no url(), var() of unknown origin or braces.
  if (!/^[-#%.,()/\w\s]+$/.test(s) || /url\(|expression|;|[{}]/i.test(s)) return undefined;
  return s;
}

function prune(obj) {
  const out = {};
  for (const [k, v] of Object.entries(obj)) {
    if (v === undefined) continue;
    if (isObj(v)) {
      const inner = prune(v);
      if (Object.keys(inner).length) out[k] = inner;
    } else out[k] = v;
  }
  return out;
}

const LEGACY_COLOR_MAP = {
  backgroundColor: 'background',
  altBackgroundColor: 'surfaceAlt',
  cardBg: 'surface',
  textColor: 'text',
  mutedTextColor: 'muted',
  borderColor: 'border',
  primaryColor: 'primary',
  secondaryColor: 'secondary',
  accentColor: 'accent',
};

/** Legacy flat keys v1 stored at the root of `designSystem`. */
export const LEGACY_KEYS = [
  ...Object.keys(LEGACY_COLOR_MAP),
  'cardText',
  'headingFont',
  'bodyFont',
  'borderRadius',
  'headingWeight',
  'buttonShape',
  'density',
  'themeMode',
];

function fillMissing(target, source) {
  const out = { ...target };
  for (const [k, v] of Object.entries(source || {})) {
    if (out[k] === undefined) out[k] = v;
    else if (isObj(out[k]) && isObj(v)) out[k] = fillMissing(out[k], v);
  }
  return out;
}

/**
 * Upgrades any stored design system (legacy flat, v2, or a mix) to a clean v2 object.
 * Keeps only valid values and never invents defaults; legacy flat fields win over v2 twins.
 * Also accepts a whole `globalData`: its `designSystem` is used, and legacy flat keys stored at
 * the globalData root (`primaryColor`, `headingFont`, …) only fill what the design system lacks.
 */
export function normalizeDesignSystem(input) {
  if (isObj(input) && isObj(input.designSystem)) {
    const rootLegacy = {};
    for (const k of LEGACY_KEYS) if (input[k] !== undefined) rootLegacy[k] = input[k];
    const own = normalizeOne(input.designSystem);
    return Object.keys(rootLegacy).length ? fillMissing(own, normalizeOne(rootLegacy)) : own;
  }
  return normalizeOne(input);
}

function normalizeOne(input) {
  const ds = isObj(input) ? input : {};
  const c = isObj(ds.colors) ? ds.colors : {};
  const t = isObj(ds.typography) ? ds.typography : {};
  const sh = isObj(ds.shape) ? ds.shape : {};
  const sd = isObj(ds.shadow) ? ds.shadow : {};
  const sp = isObj(ds.spacing) ? ds.spacing : {};
  const b = isObj(ds.buttons) ? ds.buttons : {};
  const m = isObj(ds.motion) ? ds.motion : {};
  const h = isObj(ds.header) ? ds.header : {};
  const f = isObj(ds.footer) ? ds.footer : {};

  const colors = {};
  for (const role of COLOR_ROLES) {
    const v = normalizeHex(c[role.key]);
    if (v) colors[role.key] = v;
  }
  for (const [legacy, role] of Object.entries(LEGACY_COLOR_MAP)) {
    const v = normalizeHex(ds[legacy]);
    if (v) colors[role] = v;
  }
  const legacyCardText = normalizeHex(ds.cardText);
  if (legacyCardText) colors.surfaceText = legacyCardText;
  else if (normalizeHex(c.surfaceText)) colors.surfaceText = normalizeHex(c.surfaceText);
  const seen = new Set();
  const custom = (Array.isArray(c.custom) ? c.custom : [])
    .map((x) => ({ name: String(x?.name ?? '').trim().slice(0, 40), value: normalizeHex(x?.value) }))
    .filter((x) => x.name && x.value && colorSlug(x.name) && !seen.has(colorSlug(x.name)) && seen.add(colorSlug(x.name)))
    .slice(0, 24);
  if (custom.length) colors.custom = custom;

  const legacyRadius = px(ds.borderRadius, 0, 64);
  const typography = {
    headingFont: normalizeFont(ds.headingFont ?? t.headingFont),
    bodyFont: normalizeFont(ds.bodyFont ?? t.bodyFont),
    baseSize: num(t.baseSize, 12, 24),
    scaleRatio: num(t.scaleRatio, 1.05, 1.8),
    headingWeight: num(ds.headingWeight ?? t.headingWeight, 100, 900),
    bodyWeight: num(t.bodyWeight, 100, 900),
    headingCase: oneOf(t.headingCase, ENUMS.headingCase),
    headingTracking: num(t.headingTracking, -0.08, 0.3),
    bodyLineHeight: num(t.bodyLineHeight, 1, 2.4),
  };
  // A typography font left as a plain string inside v2 is tolerated too.
  if (typeof ds.headingFont === 'string' && isObj(t.headingFont) && cleanFamily(ds.headingFont) === cleanFamily(t.headingFont.family)) {
    typography.headingFont = normalizeFont({ ...t.headingFont, family: ds.headingFont });
  }
  if (typeof ds.bodyFont === 'string' && isObj(t.bodyFont) && cleanFamily(ds.bodyFont) === cleanFamily(t.bodyFont.family)) {
    typography.bodyFont = normalizeFont({ ...t.bodyFont, family: ds.bodyFont });
  }
  if (typography.headingWeight !== undefined) typography.headingWeight = Math.round(typography.headingWeight / 100) * 100;
  if (typography.bodyWeight !== undefined) typography.bodyWeight = Math.round(typography.bodyWeight / 100) * 100;
  const customFonts = (Array.isArray(t.customFonts) ? t.customFonts : [])
    .map((x) => ({
      family: cleanFamily(x?.family),
      url: safeUrl(x?.url),
      weight: Math.round((num(x?.weight, 100, 900) ?? 400) / 100) * 100,
      style: x?.style === 'italic' ? 'italic' : 'normal',
    }))
    .filter((x) => x.family && x.url)
    .slice(0, 12);
  if (customFonts.length) typography.customFonts = customFonts;

  const shape = {
    radiusSm: px(sh.radiusSm, 0, 64),
    radiusMd: legacyRadius ?? px(sh.radiusMd, 0, 64),
    radiusLg: px(sh.radiusLg, 0, 96),
    radiusFull: px(sh.radiusFull, 0, 9999),
    borderWidth: px(sh.borderWidth, 0, 6),
  };

  const legacyShape = ds.buttonShape === 'soft' ? 'rounded' : oneOf(ds.buttonShape, ENUMS.buttonShape);
  const out = prune({
    version: DESIGN_SYSTEM_VERSION,
    name: typeof ds.name === 'string' && ds.name.trim() ? ds.name.trim().slice(0, 60) : undefined,
    preset: typeof ds.preset === 'string' && /^[a-z0-9-]{1,40}$/.test(ds.preset) ? ds.preset : undefined,
    mode: oneOf(ds.themeMode ?? ds.mode, ['light', 'dark']),
    colors,
    typography,
    shape,
    shadow: { sm: shadowValue(sd.sm), md: shadowValue(sd.md), lg: shadowValue(sd.lg) },
    spacing: {
      sectionY: px(sp.sectionY, 0, 320),
      sectionYMobile: px(sp.sectionYMobile, 0, 240),
      gutter: px(sp.gutter, 8, 120),
      maxWidth: px(sp.maxWidth, 640, 2400),
      density: oneOf(ds.density ?? sp.density, ENUMS.density),
    },
    buttons: {
      style: oneOf(b.style, ENUMS.buttonStyle),
      shape: legacyShape ?? oneOf(b.shape, ENUMS.buttonShape),
      case: oneOf(b.case, ENUMS.buttonCase),
      weight: num(b.weight, 100, 900) !== undefined ? Math.round(num(b.weight, 100, 900) / 100) * 100 : undefined,
      paddingY: px(b.paddingY, 4, 40),
      paddingX: px(b.paddingX, 8, 80),
    },
    motion: { level: oneOf(m.level, ENUMS.motion), durationMs: num(m.durationMs, 0, 2000) },
    header: {
      variant: oneOf(h.variant, ENUMS.header),
      sticky: bool(h.sticky),
      transparentOnHero: bool(h.transparentOnHero),
      showSearch: bool(h.showSearch),
      showCart: bool(h.showCart),
    },
    footer: { variant: oneOf(f.variant, ENUMS.footer), showNewsletter: bool(f.showNewsletter) },
  });
  if (typeof ds.globalCss === 'string' && ds.globalCss.trim()) out.globalCss = sanitizeGlobalCss(ds.globalCss).css;
  return out;
}

/** True when the stored object (or one of its groups) explicitly sets `path` ("colors.primary"). */
export function hasToken(normalized, path) {
  let cur = normalized;
  for (const k of String(path).split('.')) {
    if (!isObj(cur) || !(k in cur)) return false;
    cur = cur[k];
  }
  return cur !== undefined;
}

function deepMerge(base, over) {
  const out = Array.isArray(base) ? [...base] : { ...base };
  for (const [k, v] of Object.entries(over || {})) {
    if (isObj(v) && isObj(out[k])) out[k] = deepMerge(out[k], v);
    else if (v !== undefined) out[k] = v;
  }
  return out;
}

/** Fills derived colors (surface, borders, readable text on primary/secondary, …). */
function deriveColors(colors) {
  const c = { ...colors };
  const bg = c.background || '#FFFFFF';
  const dark = relativeLuminance(bg) < 0.2;
  // Same rule as the renderer: unreadable body text falls back to near-black / near-white.
  if (!c.text || contrastRatio(bg, c.text) < 4.5) c.text = dark ? '#F5F5F2' : '#15171C';
  const fg = c.text;
  if (!c.surfaceAlt) c.surfaceAlt = mixColors(fg, bg, 0.045);
  // A surface too far from the page background reads as another section, not a card.
  if (!c.surface || contrastRatio(c.surface, bg) >= 1.6) c.surface = mixColors(fg, bg, 0.03);
  if (!c.muted || contrastRatio(bg, c.muted) < 4.5) {
    let m = c.muted && contrastRatio(bg, c.muted) >= 4.5 ? c.muted : null;
    for (const w of [0.68, 0.74, 0.8, 0.86, 0.92]) {
      if (m) break;
      const cand = mixColors(fg, bg, w);
      if (contrastRatio(bg, cand) >= 4.5) m = cand;
    }
    c.muted = m || fg;
  }
  if (!c.border) c.border = mixColors(fg, bg, dark ? 0.18 : 0.13);
  if (!c.primary) c.primary = fg;
  if (!c.primaryText || contrastRatio(c.primary, c.primaryText) < 4.5) c.primaryText = readableOn(c.primary, ['#FFFFFF', '#111111', bg, fg]);
  if (!c.secondary) c.secondary = c.accent || c.primary;
  if (!c.secondaryText) c.secondaryText = readableOn(c.secondary, ['#FFFFFF', '#111111', bg, fg]);
  if (!c.accent) c.accent = c.secondary || c.primary;
  if (!c.success) c.success = '#1E7A4C';
  if (!c.danger) c.danger = '#B42318';
  return c;
}

/** Normalized design system with every default filled in (what the renderer actually uses). */
export function resolveDesignSystem(input) {
  const n = normalizeDesignSystem(input);
  const merged = deepMerge(structuredClone(DEFAULT_DESIGN_SYSTEM), n);
  // Defaults pick a heading weight/tracking that suits the heading family.
  const serifHeading = isSerifFont(merged.typography.headingFont.family);
  if (!hasToken(n, 'typography.headingWeight')) merged.typography.headingWeight = serifHeading ? 400 : 600;
  if (!hasToken(n, 'typography.headingTracking')) merged.typography.headingTracking = serifHeading ? -0.012 : -0.028;
  merged.colors = deriveColors(merged.colors);
  if (!Array.isArray(merged.colors.custom)) merged.colors.custom = [];
  merged.mode = relativeLuminance(merged.colors.background) < 0.2 ? 'dark' : 'light';
  return merged;
}

function buttonRadius(r) {
  if (r.buttons.shape === 'pill') return 'var(--cms-radius-full)';
  if (r.buttons.shape === 'square') return '0px';
  return 'var(--cms-radius-md)';
}

/** Every CSS custom property of §A, resolved (strings ready for `style`). */
export function designSystemToCssVars(input) {
  const r = resolveDesignSystem(input);
  const c = r.colors;
  const t = r.typography;
  const vars = {};
  for (const role of COLOR_ROLES) vars[role.var] = c[role.key];
  for (const cc of c.custom) vars[`--cms-color-${colorSlug(cc.name)}`] = cc.value;
  Object.assign(vars, {
    '--cms-font-heading': fontStack(t.headingFont.family, t.headingFont.category),
    '--cms-font-body': fontStack(t.bodyFont.family, t.bodyFont.category),
    '--cms-text-base': `${t.baseSize}px`,
    '--cms-scale': String(t.scaleRatio),
    '--cms-heading-weight': String(t.headingWeight),
    '--cms-body-weight': String(t.bodyWeight),
    '--cms-heading-case': t.headingCase,
    '--cms-heading-tracking': `${t.headingTracking}em`,
    '--cms-line-height': String(t.bodyLineHeight),
    '--cms-radius-sm': `${r.shape.radiusSm}px`,
    '--cms-radius-md': `${r.shape.radiusMd}px`,
    '--cms-radius-lg': `${r.shape.radiusLg}px`,
    '--cms-radius-full': `${r.shape.radiusFull}px`,
    '--cms-border-width': `${r.shape.borderWidth}px`,
    '--cms-shadow-sm': r.shadow.sm,
    '--cms-shadow-md': r.shadow.md,
    '--cms-shadow-lg': r.shadow.lg,
    '--cms-section-y': `${r.spacing.sectionY}px`,
    '--cms-section-y-mobile': `${r.spacing.sectionYMobile}px`,
    '--cms-gutter': `${r.spacing.gutter}px`,
    '--cms-max-width': `${r.spacing.maxWidth}px`,
    '--cms-btn-radius': buttonRadius(r),
    '--cms-btn-case': r.buttons.case,
    '--cms-btn-weight': String(r.buttons.weight),
    '--cms-btn-py': `${r.buttons.paddingY}px`,
    '--cms-btn-px': `${r.buttons.paddingX}px`,
    '--cms-duration': `${r.motion.level === 'none' ? 0 : r.motion.durationMs}ms`,
  });
  return vars;
}

/** The exact variable names of §A (custom palette entries come on top as --cms-color-<slug>). */
export const CSS_VAR_NAMES = Object.keys(designSystemToCssVars({}));

/** `scope{--cms-…}` (custom fonts: designSystemFontFaceCss; client CSS: designSystemGlobalCss). */
export function designSystemToCss(input, scope = ':root') {
  const vars = designSystemToCssVars(input);
  const body = Object.entries(vars)
    .map(([k, v]) => `${k}:${v}`)
    .join(';');
  return `${scope}{${body}}`;
}

/** Sanitized `globalCss` of the design system ('' when none). */
export function designSystemGlobalCss(input) {
  return normalizeDesignSystem(input).globalCss || '';
}

const LEGACY_AXIS = 'ital,wght@0,400;0,500;0,600;0,700;1,400';

function googleFamilyUrl(family, weights) {
  const name = encodeURIComponent(family).replace(/%20/g, '+');
  let axis = '';
  if (weights === 'legacy') axis = `:${LEGACY_AXIS}`;
  else if (weights.length) axis = `:wght@${weights.join(';')}`;
  return `https://fonts.googleapis.com/css2?family=${name}${axis}&display=swap`;
}

/**
 * Google Fonts stylesheet URLs, one per family (an unavailable weight makes Google reject the
 * whole request, so families never share a URL). Families saved without `weights` (legacy)
 * request the historical axis set `ital,wght@0,400;0,500;0,600;0,700;1,400`.
 */
export function designSystemFontLinks(input) {
  const n = normalizeDesignSystem(input);
  const r = resolveDesignSystem(input);
  const fams = new Map();
  for (const key of ['headingFont', 'bodyFont']) {
    const font = r.typography[key];
    if (!font || font.source === 'custom') continue;
    // Generic aliases (serif, sans, mono, system-ui) and system fonts are never fetched.
    if (font.source === 'system' || GENERIC_STACKS[font.family.toLowerCase()]) continue;
    const family = font.family;
    const explicit = hasToken(n, `typography.${key}.weights`) ? font.weights : 'legacy';
    const prev = fams.get(family);
    if (prev === undefined || prev === 'legacy') fams.set(family, explicit);
    else if (explicit !== 'legacy') fams.set(family, Array.from(new Set([...prev, ...explicit])).sort((a, b) => a - b));
  }
  return Array.from(fams.entries()).map(([f, w]) => googleFamilyUrl(f, w));
}

/** SDK name for designSystemFontFaceCss. */
export function designSystemFontFaces(input) {
  return designSystemFontFaceCss(input);
}

/** @font-face rules for typography.customFonts (and custom-source heading/body fonts with a url). */
export function designSystemFontFaceCss(input) {
  const n = normalizeDesignSystem(input);
  const t = n.typography || {};
  const faces = [...(t.customFonts || [])];
  for (const key of ['headingFont', 'bodyFont']) {
    const font = t[key];
    if (font?.source === 'custom' && font.url && !faces.some((f) => f.family === font.family)) {
      faces.push({ family: font.family, url: font.url, weight: 400, style: 'normal' });
    }
  }
  return faces
    .map((f) => {
      const fmt = /\.woff2(\?|$)/i.test(f.url) ? 'woff2' : /\.woff(\?|$)/i.test(f.url) ? 'woff' : /\.otf(\?|$)/i.test(f.url) ? 'opentype' : 'truetype';
      return `@font-face{font-family:"${f.family}";src:url("${f.url}") format("${fmt}");font-weight:${f.weight};font-style:${f.style};font-display:swap}`;
    })
    .join('\n');
}

// ───────────────────────── contrast ─────────────────────────

/**
 * WCAG ratios for the pairs that matter. `level`: AAA (≥7), AA (≥4.5), AA-large (≥3, large text
 * and UI only) or fail. `min` is what the pair needs to pass.
 */
export function contrastReport(input) {
  // Explicit choices are judged as chosen (the renderer would silently correct some of them).
  const own = normalizeDesignSystem(input).colors || {};
  const c = { ...resolveDesignSystem(input).colors };
  for (const k of ['text', 'muted', 'surface', 'primaryText', 'secondaryText']) if (own[k]) c[k] = own[k];
  const pairs = [
    ['text-on-background', 'Texto sobre fondo', c.text, c.background, 4.5],
    ['muted-on-background', 'Texto secundario sobre fondo', c.muted, c.background, 4.5],
    ['text-on-surface', 'Texto sobre superficie', c.surfaceText || c.text, c.surface, 4.5],
    ['text-on-surface-alt', 'Texto sobre fondo alterno', c.text, c.surfaceAlt, 4.5],
    ['primary-text-on-primary', 'Texto de botón primario', c.primaryText, c.primary, 4.5],
    ['secondary-text-on-secondary', 'Texto de botón secundario', c.secondaryText, c.secondary, 4.5],
    ['primary-on-background', 'Primario sobre fondo (bordes, enlaces)', c.primary, c.background, 3],
    ['accent-on-background', 'Acento sobre fondo', c.accent, c.background, 3],
    ['border-on-background', 'Bordes sobre fondo (decorativo)', c.border, c.background, 1.15],
  ];
  return pairs.map(([id, label, fg, bg, min]) => {
    const ratio = Math.round(contrastRatio(fg, bg) * 100) / 100;
    const level = ratio >= 7 ? 'AAA' : ratio >= 4.5 ? 'AA' : ratio >= 3 ? 'AA-large' : 'fail';
    return { id, label, fg, bg, ratio, min, level, pass: ratio >= min };
  });
}

// ───────────────────────── global CSS ─────────────────────────

const CSS_MAX = 40_000;

/**
 * Removes what client CSS must never do (escape the <style> tag, load remote code, run script)
 * and reports syntax problems. `css` is always safe to inline; `errors` lists what was found.
 */
export function sanitizeGlobalCss(input) {
  const errors = [];
  let css = String(input ?? '');
  if (css.length > CSS_MAX) {
    errors.push(`El CSS supera ${CSS_MAX} caracteres; se recortó.`);
    css = css.slice(0, CSS_MAX);
  }
  css = css.replace(/\u0000/g, '');
  if (/<\/?\s*(style|script)/i.test(css) || /<!--|-->/.test(css)) {
    errors.push('No se permiten etiquetas HTML dentro del CSS.');
    css = css.replace(/<\/?\s*(style|script)[^>]*>?/gi, '').replace(/<!--|-->/g, '');
  }
  css = css.replace(/</g, '\\3C ');
  const rules = [
    [/@import[^;]*;?/gi, 'No se permite @import; carga fuentes desde Tipografía.'],
    [/@charset[^;]*;?/gi, null],
    [/expression\s*\(/gi, 'expression() no está permitido.'],
    [/javascript\s*:/gi, 'javascript: no está permitido.'],
    [/vbscript\s*:/gi, 'vbscript: no está permitido.'],
    [/-moz-binding\s*:[^;}]*/gi, '-moz-binding no está permitido.'],
    [/behavior\s*:[^;}]*/gi, 'behavior no está permitido.'],
    [/url\(\s*(['"]?)\s*data:(?!image\/(png|jpe?g|gif|webp|avif|svg\+xml))[^)]*\)/gi, 'Solo se permiten data: de imágenes en url().'],
  ];
  for (const [re, msg] of rules) {
    if (re.test(css)) {
      if (msg) errors.push(msg);
      css = css.replace(re, '');
    }
    re.lastIndex = 0;
  }
  // Syntax: balanced braces/parens outside strings and comments.
  let depth = 0;
  let paren = 0;
  let quote = '';
  for (let i = 0; i < css.length; i++) {
    const ch = css[i];
    if (quote) {
      if (ch === '\\') i++;
      else if (ch === quote) quote = '';
      continue;
    }
    if (ch === '/' && css[i + 1] === '*') {
      const end = css.indexOf('*/', i + 2);
      if (end === -1) {
        errors.push('Comentario sin cerrar (falta */).');
        css = css.slice(0, i);
        break;
      }
      i = end + 1;
      continue;
    }
    if (ch === '"' || ch === "'") quote = ch;
    else if (ch === '{') depth++;
    else if (ch === '}') {
      depth--;
      if (depth < 0) {
        errors.push('Hay una llave } de más.');
        depth = 0;
      }
    } else if (ch === '(') paren++;
    else if (ch === ')') paren = Math.max(0, paren - 1);
  }
  if (quote) errors.push('Hay una comilla sin cerrar.');
  if (depth > 0) errors.push(`Falta${depth > 1 ? 'n' : ''} ${depth} llave${depth > 1 ? 's' : ''} de cierre }.`);
  if (paren > 0) errors.push('Hay un paréntesis sin cerrar.');
  return { css: depth > 0 || quote ? '' : css.trim(), errors, valid: errors.length === 0 };
}

// ───────────────────────── presets ─────────────────────────

const preset = (id, label, description, ds) => ({ id, label, description, designSystem: { version: 2, preset: id, ...ds } });

/** Eight curated, deliberately different starting points. */
export const DESIGN_PRESETS = [
  preset('editorial', 'Editorial', 'Revista: serif de alto contraste, papel cálido, tinta negra y un rojo de imprenta.', {
    colors: { background: '#F6F3EC', surface: '#FFFFFF', surfaceAlt: '#ECE6DA', text: '#141210', muted: '#5B554C', border: '#D7CFC1', primary: '#141210', primaryText: '#F6F3EC', secondary: '#B3261E', secondaryText: '#FFFFFF', accent: '#B3261E' },
    typography: { headingFont: { family: 'Newsreader', source: 'google', weights: [400, 500, 600] }, bodyFont: { family: 'Source Serif 4', source: 'google', weights: [400, 600] }, baseSize: 18, scaleRatio: 1.333, headingWeight: 400, bodyWeight: 400, headingCase: 'none', headingTracking: -0.015, bodyLineHeight: 1.65 },
    shape: { radiusSm: 0, radiusMd: 0, radiusLg: 2, radiusFull: 999, borderWidth: 1 },
    shadow: { sm: 'none', md: 'none', lg: '0 1px 0 rgb(20 18 16 / 0.12)' },
    spacing: { sectionY: 144, sectionYMobile: 76, gutter: 48, maxWidth: 1180 },
    buttons: { style: 'solid', shape: 'square', case: 'uppercase', weight: 600, paddingY: 14, paddingX: 26 },
    motion: { level: 'subtle', durationMs: 240 },
    header: { variant: 'centered', sticky: true, transparentOnHero: false, showSearch: false, showCart: true },
    footer: { variant: 'big', showNewsletter: true },
  }),
  preset('minimal', 'Minimal', 'Suizo: blanco, negro casi puro, una sola sans neutra y mucho aire.', {
    colors: { background: '#FFFFFF', surface: '#FAFAFA', surfaceAlt: '#F3F3F2', text: '#0A0A0A', muted: '#5E5E5C', border: '#E4E4E2', primary: '#0A0A0A', primaryText: '#FFFFFF', secondary: '#5E5E5C', secondaryText: '#FFFFFF', accent: '#0A0A0A' },
    typography: { headingFont: { family: 'Inter Tight', source: 'google', weights: [500, 600] }, bodyFont: { family: 'Inter', source: 'google', weights: [400, 500] }, baseSize: 16, scaleRatio: 1.25, headingWeight: 500, bodyWeight: 400, headingCase: 'none', headingTracking: -0.035, bodyLineHeight: 1.6 },
    shape: { radiusSm: 2, radiusMd: 4, radiusLg: 8, radiusFull: 999, borderWidth: 1 },
    shadow: { sm: 'none', md: '0 1px 2px rgb(0 0 0 / 0.05)', lg: '0 12px 32px -16px rgb(0 0 0 / 0.18)' },
    spacing: { sectionY: 160, sectionYMobile: 80, gutter: 40, maxWidth: 1120 },
    buttons: { style: 'solid', shape: 'rounded', case: 'none', weight: 500, paddingY: 12, paddingX: 20 },
    motion: { level: 'subtle', durationMs: 180 },
    header: { variant: 'simple', sticky: true, transparentOnHero: false, showSearch: false, showCart: true },
    footer: { variant: 'simple', showNewsletter: false },
  }),
  preset('bold', 'Audaz', 'Cartel: grotesca condensada en mayúsculas, amarillo eléctrico sobre negro tinta.', {
    colors: { background: '#FFFDF5', surface: '#FFFFFF', surfaceAlt: '#FFE94D', text: '#111111', muted: '#4A4A45', border: '#111111', primary: '#111111', primaryText: '#FFE94D', secondary: '#FF4F1F', secondaryText: '#111111', accent: '#FF4F1F' },
    typography: { headingFont: { family: 'Anton', source: 'google', weights: [400] }, bodyFont: { family: 'Archivo', source: 'google', weights: [400, 600, 700] }, baseSize: 17, scaleRatio: 1.414, headingWeight: 400, bodyWeight: 400, headingCase: 'uppercase', headingTracking: 0.005, bodyLineHeight: 1.5 },
    shape: { radiusSm: 0, radiusMd: 0, radiusLg: 0, radiusFull: 999, borderWidth: 2 },
    shadow: { sm: 'none', md: 'none', lg: 'none' },
    spacing: { sectionY: 120, sectionYMobile: 64, gutter: 32, maxWidth: 1320 },
    buttons: { style: 'solid', shape: 'square', case: 'uppercase', weight: 700, paddingY: 16, paddingX: 28 },
    motion: { level: 'expressive', durationMs: 160 },
    header: { variant: 'split', sticky: true, transparentOnHero: false, showSearch: false, showCart: true },
    footer: { variant: 'big', showNewsletter: false },
  }),
  preset('soft', 'Suave', 'Bienestar: lavanda empolvada, formas redondas, sombras difusas y una sans amable.', {
    colors: { background: '#FBF9FE', surface: '#FFFFFF', surfaceAlt: '#F0EBFA', text: '#2B2540', muted: '#615A78', border: '#E3DCF2', primary: '#6E56CF', primaryText: '#FFFFFF', secondary: '#E8DFFB', secondaryText: '#2B2540', accent: '#D9668B' },
    typography: { headingFont: { family: 'Nunito', source: 'google', weights: [600, 700] }, bodyFont: { family: 'Nunito Sans', source: 'google', weights: [400, 600] }, baseSize: 17, scaleRatio: 1.2, headingWeight: 700, bodyWeight: 400, headingCase: 'none', headingTracking: -0.015, bodyLineHeight: 1.65 },
    shape: { radiusSm: 10, radiusMd: 18, radiusLg: 28, radiusFull: 999, borderWidth: 1 },
    shadow: { sm: '0 1px 3px rgb(43 37 64 / 0.06)', md: '0 10px 30px -12px rgb(110 86 207 / 0.22)', lg: '0 30px 70px -30px rgb(110 86 207 / 0.35)' },
    spacing: { sectionY: 120, sectionYMobile: 72, gutter: 28, maxWidth: 1180 },
    buttons: { style: 'solid', shape: 'pill', case: 'none', weight: 700, paddingY: 13, paddingX: 26 },
    motion: { level: 'subtle', durationMs: 260 },
    header: { variant: 'simple', sticky: true, transparentOnHero: false, showSearch: false, showCart: true },
    footer: { variant: 'columns', showNewsletter: true },
  }),
  preset('dark', 'Nocturno', 'Bar o estudio: grafito profundo, texto marfil y un verde menta como única luz.', {
    colors: { background: '#0E1013', surface: '#171A1F', surfaceAlt: '#14171B', text: '#ECEAE3', muted: '#A3A29C', border: '#2A2E35', primary: '#7CE0B5', primaryText: '#0E1013', secondary: '#262A31', secondaryText: '#ECEAE3', accent: '#7CE0B5' },
    typography: { headingFont: { family: 'Space Grotesk', source: 'google', weights: [500, 600] }, bodyFont: { family: 'Inter', source: 'google', weights: [400, 500] }, baseSize: 16, scaleRatio: 1.25, headingWeight: 500, bodyWeight: 400, headingCase: 'none', headingTracking: -0.025, bodyLineHeight: 1.6 },
    shape: { radiusSm: 4, radiusMd: 8, radiusLg: 16, radiusFull: 999, borderWidth: 1 },
    shadow: { sm: '0 1px 2px rgb(0 0 0 / 0.4)', md: '0 10px 30px -12px rgb(0 0 0 / 0.6)', lg: '0 30px 80px -30px rgb(0 0 0 / 0.8)' },
    spacing: { sectionY: 128, sectionYMobile: 72, gutter: 32, maxWidth: 1240 },
    buttons: { style: 'solid', shape: 'rounded', case: 'none', weight: 600, paddingY: 12, paddingX: 22 },
    motion: { level: 'subtle', durationMs: 220 },
    header: { variant: 'simple', sticky: true, transparentOnHero: true, showSearch: false, showCart: true },
    footer: { variant: 'columns', showNewsletter: false },
  }),
  preset('warm', 'Cálido', 'Cocina de barrio: terracota, crema horneada y una serif con carácter.', {
    colors: { background: '#FBF4EA', surface: '#FFFBF5', surfaceAlt: '#F3E4D0', text: '#2E1B12', muted: '#6E5443', border: '#E5D2BC', primary: '#B4472B', primaryText: '#FFFFFF', secondary: '#E9B44C', secondaryText: '#2E1B12', accent: '#6B7F3A' },
    typography: { headingFont: { family: 'Young Serif', source: 'google', weights: [400] }, bodyFont: { family: 'Work Sans', source: 'google', weights: [400, 500, 600] }, baseSize: 17, scaleRatio: 1.28, headingWeight: 400, bodyWeight: 400, headingCase: 'none', headingTracking: -0.01, bodyLineHeight: 1.6 },
    shape: { radiusSm: 6, radiusMd: 10, radiusLg: 20, radiusFull: 999, borderWidth: 1 },
    shadow: { sm: '0 1px 2px rgb(46 27 18 / 0.08)', md: '0 8px 24px -10px rgb(46 27 18 / 0.22)', lg: '0 24px 60px -24px rgb(46 27 18 / 0.3)' },
    spacing: { sectionY: 120, sectionYMobile: 68, gutter: 32, maxWidth: 1200 },
    buttons: { style: 'solid', shape: 'pill', case: 'none', weight: 600, paddingY: 13, paddingX: 24 },
    motion: { level: 'subtle', durationMs: 220 },
    header: { variant: 'split', sticky: true, transparentOnHero: false, showSearch: false, showCart: true },
    footer: { variant: 'columns', showNewsletter: true },
  }),
  preset('tech', 'Tecnológico', 'Producto digital: azul cobalto, gris acero, mono para datos y bordes finos.', {
    colors: { background: '#F7F8FA', surface: '#FFFFFF', surfaceAlt: '#EDF0F5', text: '#0B1220', muted: '#4B5567', border: '#D9DEE7', primary: '#2F5BFF', primaryText: '#FFFFFF', secondary: '#0B1220', secondaryText: '#FFFFFF', accent: '#007F86' },
    typography: { headingFont: { family: 'Geist', source: 'google', weights: [500, 600, 700] }, bodyFont: { family: 'Geist', source: 'google', weights: [400, 500] }, baseSize: 16, scaleRatio: 1.22, headingWeight: 600, bodyWeight: 400, headingCase: 'none', headingTracking: -0.03, bodyLineHeight: 1.55 },
    shape: { radiusSm: 4, radiusMd: 8, radiusLg: 12, radiusFull: 999, borderWidth: 1 },
    shadow: { sm: '0 1px 2px rgb(11 18 32 / 0.06)', md: '0 4px 14px -6px rgb(11 18 32 / 0.14)', lg: '0 20px 50px -20px rgb(47 91 255 / 0.28)' },
    spacing: { sectionY: 112, sectionYMobile: 64, gutter: 32, maxWidth: 1240 },
    buttons: { style: 'solid', shape: 'rounded', case: 'none', weight: 600, paddingY: 11, paddingX: 18 },
    motion: { level: 'subtle', durationMs: 160 },
    header: { variant: 'split', sticky: true, transparentOnHero: false, showSearch: true, showCart: true },
    footer: { variant: 'columns', showNewsletter: true },
  }),
  preset('artisan', 'Artesanal', 'Taller: lino crudo, verde oliva, una serif humanista y botones de contorno.', {
    colors: { background: '#EFEBE2', surface: '#F7F4EE', surfaceAlt: '#E2DCCD', text: '#262A1F', muted: '#5C604F', border: '#CEC6B3', primary: '#4E5B31', primaryText: '#F7F4EE', secondary: '#8A5A3C', secondaryText: '#FFFFFF', accent: '#8A5A3C', custom: [{ name: 'Arcilla', value: '#B9785A' }] },
    typography: { headingFont: { family: 'Cormorant Garamond', source: 'google', weights: [500, 600] }, bodyFont: { family: 'Karla', source: 'google', weights: [400, 500, 700] }, baseSize: 17, scaleRatio: 1.333, headingWeight: 500, bodyWeight: 400, headingCase: 'none', headingTracking: -0.005, bodyLineHeight: 1.65 },
    shape: { radiusSm: 2, radiusMd: 3, radiusLg: 6, radiusFull: 999, borderWidth: 1 },
    shadow: { sm: 'none', md: '0 2px 10px -4px rgb(38 42 31 / 0.18)', lg: '0 18px 40px -20px rgb(38 42 31 / 0.3)' },
    spacing: { sectionY: 128, sectionYMobile: 72, gutter: 40, maxWidth: 1160 },
    buttons: { style: 'outline', shape: 'square', case: 'uppercase', weight: 700, paddingY: 13, paddingX: 24 },
    motion: { level: 'subtle', durationMs: 260 },
    header: { variant: 'centered', sticky: false, transparentOnHero: false, showSearch: false, showCart: true },
    footer: { variant: 'simple', showNewsletter: true },
  }),
];

/**
 * Applies a preset over the current design system. Keeps the client's custom palette, custom
 * fonts and global CSS; everything else comes from the preset. Returns a clean v2 object.
 */
export function applyPreset(current, presetId) {
  const p = DESIGN_PRESETS.find((x) => x.id === presetId);
  if (!p) throw new Error(`Preset desconocido: ${presetId}`);
  const cur = normalizeDesignSystem(current);
  const next = structuredClone(p.designSystem);
  const keepCustom = [...(cur.colors?.custom || [])];
  for (const cc of next.colors.custom || []) if (!keepCustom.some((k) => colorSlug(k.name) === colorSlug(cc.name))) keepCustom.push(cc);
  if (keepCustom.length) next.colors.custom = keepCustom;
  if (cur.typography?.customFonts?.length) next.typography.customFonts = cur.typography.customFonts;
  if (cur.globalCss) next.globalCss = cur.globalCss;
  if (cur.name) next.name = cur.name;
  return normalizeDesignSystem(next);
}
