/**
 * Design System v2 (docs/EDITING-V4.1.md §A) → variables CSS `--cms-*`, enlaces de fuentes,
 * `@font-face` y CSS global.
 *
 * Una sola implementación para el renderer del CMS y los sitios headless: el código vive en
 * `shared/src/design-system.mjs` y `scripts/sync-shared.mjs` lo copia a `src/shared/`. Acepta v2
 * (`version: 2`, grupos `colors`, `typography`, `shape`…), los campos planos v1 (`primaryColor`,
 * `headingFont`, `borderRadius`…) o un `globalData` completo (se usa su `designSystem`; los campos
 * planos de la raíz solo completan lo que falte).
 */
export {
  COLOR_ROLES,
  CSS_VAR_NAMES,
  DEFAULT_DESIGN_SYSTEM,
  DESIGN_PRESETS,
  applyPreset,
  colorSlug,
  contrastRatio,
  contrastReport,
  designSystemFontFaceCss,
  designSystemFontFaces,
  designSystemFontLinks,
  designSystemGlobalCss,
  designSystemToCss,
  designSystemToCssVars,
  fontStack,
  normalizeDesignSystem,
  resolveDesignSystem,
  sanitizeGlobalCss,
} from './shared/design-system.js';
export type { ContrastPair, DesignPreset, DesignSystemV2, FontRef, ResolvedDesignSystem } from './shared/design-system.js';

export type DesignSystemInput = Record<string, any> | null | undefined;
