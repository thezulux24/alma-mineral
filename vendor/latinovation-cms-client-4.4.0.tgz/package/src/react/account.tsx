'use client';

/**
 * Cuenta del cliente de la tienda para storefronts React (docs/SHOP-ACCOUNTS.md): sesión, perfil,
 * direcciones, pedidos con rastreo, devoluciones y descargas digitales. Va dentro de
 * <ShopAccountProvider> (y de <CmsProvider> para slug, URL y textos).
 *
 *   const acc = useCustomerAccount({ load: ['orders', 'returns', 'downloads'] });
 *   if (!acc.customer) return <form onSubmit={() => acc.login({ email, password })}>…</form>;
 *   acc.orders.items.map((o) => …)  ·  await acc.requestReturn('ORD-1', { reason: 'Talla' })
 *
 *   const { order, tracking } = useOrder('ORD-2026-…');      // detalle + envíos
 *   const t = useOrderTracking(); await t.track('ORD-…');      // rastreo público (sin cuenta)
 *   const d = useDownloads({ orderNumber, email });            // descargas de invitado
 */
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import type {
  ShopAddress,
  ShopAddressInput,
  ShopAuthResult,
  ShopClient,
  ShopCustomer,
  ShopError,
  ShopOrder,
  ShopOrderSummary,
  ShopProfilePatch,
  ShopRegisterInput,
  ShopRetryResult,
  ShopReturnRequest,
  ShopTrackResult,
} from '../shop.js';
import type { DigitalDownload } from '../store-extras.js';
import { useShopClient, type ShopSourceOptions } from './checkout.js';
import { useShopAccount } from './shop.js';
import { useStoreExtras } from './store-extras.js';

type Section = 'orders' | 'returns' | 'downloads' | 'addresses';

interface ListState<T> {
  items: T[];
  loading: boolean;
  error: ShopError | null;
}

export interface UseCustomerAccount {
  customer: ShopCustomer | null;
  /** Validando la sesión guardada. */
  loading: boolean;
  /** Hay sesión de cliente. */
  signedIn: boolean;
  login(input: { email: string; password: string }): Promise<ShopCustomer>;
  register(input: ShopRegisterInput): Promise<ShopAuthResult & { claimedOrders: string[] }>;
  logout(): void;
  logoutAll(): Promise<void>;
  /** Envía el correo para restablecer (siempre responde `sent: true`). */
  forgotPassword(email: string, resetUrl?: string): Promise<{ sent: boolean }>;
  /** Restablece con el token del enlace (`?token=` en /cuenta/restablecer) e inicia sesión. */
  resetPassword(token: string, password: string): Promise<ShopCustomer>;
  updateProfile(patch: ShopProfilePatch): Promise<ShopCustomer>;
  changePassword(currentPassword: string, newPassword: string): Promise<void>;
  deleteAccount(password: string): Promise<void>;
  addresses: ListState<ShopAddress> & {
    load(): Promise<void>;
    add(a: ShopAddressInput): Promise<ShopAddress[]>;
    update(id: string, patch: Partial<ShopAddressInput>): Promise<ShopAddress[]>;
    remove(id: string): Promise<ShopAddress[]>;
  };
  orders: ListState<ShopOrderSummary> & { page: number; totalPages: number; total: number; load(page?: number): Promise<void> };
  getOrder(orderNumber: string): Promise<ShopOrder>;
  /** Nuevo intento de pago de un pedido rechazado o pendiente (lleva a la pasarela salvo `redirect: false`). */
  retryPayment(orderNumber: string, opts?: { redirectUrl?: string; redirect?: boolean }): Promise<ShopRetryResult>;
  returns: ListState<ShopReturnRequest> & { load(): Promise<void> };
  /** «Solicitar devolución» de un pedido pagado; `items` vacío = el pedido completo. */
  requestReturn(orderNumber: string, input: { reason: string; items?: Array<{ lineId: string; quantity: number }>; note?: string }): Promise<ShopReturnRequest>;
  downloads: ListState<DigitalDownload> & { load(): Promise<void> };
  client: ShopClient;
}

const emptyList = <T,>(): ListState<T> => ({ items: [], loading: false, error: null });

/** Cuenta completa del cliente. `load` elige qué listas se cargan solas al tener sesión. */
export function useCustomerAccount(opts: { load?: Section[]; pageSize?: number } = {}): UseCustomerAccount {
  const acc = useShopAccount();
  const { client, customer } = acc;
  const extras = useStoreExtras({ slug: client.slug, apiUrl: client.apiUrl });
  const auto = new Set(opts.load || []);
  const pageSize = opts.pageSize || 10;

  const [orders, setOrders] = useState<ListState<ShopOrderSummary> & { page: number; totalPages: number; total: number }>({ ...emptyList(), page: 1, totalPages: 1, total: 0 });
  const [returns, setReturns] = useState<ListState<ShopReturnRequest>>(emptyList());
  const [downloads, setDownloads] = useState<ListState<DigitalDownload>>(emptyList());
  const [addresses, setAddresses] = useState<ListState<ShopAddress>>(emptyList());

  const loadOrders = useCallback(
    async (page = 1) => {
      setOrders((s) => ({ ...s, loading: true }));
      try {
        const r = await client.account.orders.list({ page, limit: pageSize });
        setOrders({ items: r.items, page: r.page, totalPages: r.totalPages, total: r.total, loading: false, error: null });
      } catch (e) {
        setOrders((s) => ({ ...s, loading: false, error: e as ShopError }));
      }
    },
    [client, pageSize],
  );
  const loadReturns = useCallback(async () => {
    setReturns((s) => ({ ...s, loading: true }));
    try {
      setReturns({ items: await client.account.returns.list(), loading: false, error: null });
    } catch (e) {
      setReturns((s) => ({ ...s, loading: false, error: e as ShopError }));
    }
  }, [client]);
  const loadDownloads = useCallback(async () => {
    if (!extras) return;
    setDownloads((s) => ({ ...s, loading: true }));
    try {
      setDownloads({ items: (await extras.downloads.mine()).items, loading: false, error: null });
    } catch (e) {
      setDownloads((s) => ({ ...s, loading: false, error: e as ShopError }));
    }
  }, [extras]);
  const loadAddresses = useCallback(async () => {
    setAddresses((s) => ({ ...s, loading: true }));
    try {
      setAddresses({ items: await client.account.addresses.list(), loading: false, error: null });
    } catch (e) {
      setAddresses((s) => ({ ...s, loading: false, error: e as ShopError }));
    }
  }, [client]);

  const autoKey = [...auto].sort().join(',');
  useEffect(() => {
    if (!customer) {
      setOrders({ ...emptyList(), page: 1, totalPages: 1, total: 0 });
      setReturns(emptyList());
      setDownloads(emptyList());
      setAddresses(emptyList());
      return;
    }
    if (auto.has('orders')) void loadOrders(1);
    if (auto.has('returns')) void loadReturns();
    if (auto.has('downloads')) void loadDownloads();
    if (auto.has('addresses')) setAddresses({ items: customer.addresses || [], loading: false, error: null });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [customer?.id, autoKey]);

  const withAddresses = useCallback((p: Promise<ShopAddress[]>) => p.then((items) => (setAddresses({ items, loading: false, error: null }), items)), []);

  return {
    customer,
    loading: acc.loading,
    signedIn: Boolean(customer),
    login: acc.login,
    register: acc.register,
    logout: acc.logout,
    logoutAll: () => client.account.logoutAll(),
    forgotPassword: (email, resetUrl) => client.account.forgotPassword({ email, resetUrl }),
    resetPassword: async (token, password) => {
      await client.account.resetPassword({ token, password });
      return (await acc.refresh()) as ShopCustomer;
    },
    updateProfile: async (patch) => {
      const c = await client.account.update(patch);
      await acc.refresh();
      return c;
    },
    changePassword: async (currentPassword, newPassword) => {
      await client.account.changePassword({ currentPassword, newPassword });
    },
    deleteAccount: async (password) => {
      await client.account.deleteAccount({ password });
    },
    addresses: {
      ...addresses,
      load: loadAddresses,
      add: (a) => withAddresses(client.account.addresses.add(a)),
      update: (id, patch) => withAddresses(client.account.addresses.update(id, patch)),
      remove: (id) => withAddresses(client.account.addresses.remove(id)),
    },
    orders: { ...orders, load: loadOrders },
    getOrder: (n) => client.account.orders.get(n),
    retryPayment: async (orderNumber, o = {}) => {
      const loc = (globalThis as any).location;
      const res = await client.retryPayment(orderNumber, { redirectUrl: o.redirectUrl ?? (loc ? `${loc.origin}${loc.pathname}` : undefined) });
      if (o.redirect !== false && res.checkoutUrl && loc?.assign) loc.assign(res.checkoutUrl);
      return res;
    },
    returns: { ...returns, load: loadReturns },
    requestReturn: async (orderNumber, input) => {
      const r = await client.account.returns.request(orderNumber, input);
      setReturns((s) => ({ ...s, items: [r, ...s.items.filter((x) => x.id !== r.id)] }));
      return r;
    },
    downloads: { ...downloads, load: loadDownloads },
    client,
  };
}

/**
 * Detalle de un pedido con su rastreo. Con sesión lee el pedido de la cuenta (líneas con `lineId`
 * para devoluciones); el rastreo (`shipments`, eventos normalizados) es el público por número.
 */
export function useOrder(orderNumber: string | null | undefined, opts: ShopSourceOptions & { tracking?: boolean } = {}) {
  const client = useShopClient(opts);
  const [order, setOrder] = useState<ShopOrder | null>(null);
  const [tracking, setTracking] = useState<ShopTrackResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<ShopError | null>(null);
  const seq = useRef(0);
  const load = useCallback(async () => {
    if (!client || !orderNumber) return;
    const id = ++seq.current;
    setLoading(true);
    try {
      const [o, t] = await Promise.all([
        client.getToken() ? client.account.orders.get(orderNumber).catch((e) => (e?.status === 401 || e?.status === 404 ? null : Promise.reject(e))) : Promise.resolve(null),
        opts.tracking === false ? Promise.resolve(null) : client.track(orderNumber).catch(() => null),
      ]);
      if (id !== seq.current) return;
      setOrder(o);
      setTracking(t);
      setError(null);
    } catch (e) {
      if (id === seq.current) setError(e as ShopError);
    } finally {
      if (id === seq.current) setLoading(false);
    }
  }, [client, orderNumber, opts.tracking]);
  useEffect(() => {
    void load();
  }, [load]);
  return { order, tracking, shipments: tracking?.shipments || [], loading, error, reload: load };
}

/** Rastreo público por número de pedido o de guía (formulario «Rastrear pedido»). */
export function useOrderTracking(opts: ShopSourceOptions = {}) {
  const client = useShopClient(opts);
  const [result, setResult] = useState<ShopTrackResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<ShopError | null>(null);
  const track = useCallback(
    async (code: string) => {
      if (!client || !String(code || '').trim()) return null;
      setLoading(true);
      try {
        const r = await client.track(String(code).trim());
        setResult(r);
        setError(null);
        return r;
      } catch (e) {
        setResult(null);
        setError(e as ShopError);
        return null;
      } finally {
        setLoading(false);
      }
    },
    [client],
  );
  return { track, result, loading, error, notFound: error?.status === 404 };
}

/**
 * Descargas digitales: las de la cuenta (con sesión) o las de un pedido de invitado
 * (`orderNumber` + correo de la compra). Cada llamada trae enlaces firmados nuevos.
 */
export function useDownloads(opts: { orderNumber?: string; email?: string; auto?: boolean } = {}) {
  const extras = useStoreExtras();
  const [items, setItems] = useState<DigitalDownload[]>([]);
  const [pendingPayment, setPendingPayment] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<Error | null>(null);
  const guest = Boolean(opts.orderNumber && opts.email);
  const load = useCallback(async () => {
    if (!extras) return;
    setLoading(true);
    try {
      if (guest) {
        const r = await extras.downloads.forOrder(opts.orderNumber as string, opts.email as string);
        setItems(r.items);
        setPendingPayment(Boolean(r.pendingPayment));
      } else {
        setItems((await extras.downloads.mine()).items);
        setPendingPayment(false);
      }
      setError(null);
    } catch (e) {
      setError(e as Error);
      setItems([]);
    } finally {
      setLoading(false);
    }
  }, [extras, guest, opts.orderNumber, opts.email]);
  useEffect(() => {
    if (opts.auto !== false && (guest || extras)) void load();
  }, [load, opts.auto, guest, extras]);
  return useMemo(() => ({ items, pendingPayment, loading, error, reload: load }), [items, pendingPayment, loading, error, load]);
}
