'use client';

/**
 * Rótulos de la tienda y dinero con el formato del proyecto, editables desde /portal.
 *
 *   const ui = useShopUi();                      // global.ui > SHOP_UI
 *   <button><CmsUiText k="addToCart" /></button>  // en el editor: clic → editar el global
 *   const money = useMoney(); money(125000)       // "$ 125.000" (moneda y locale del proyecto)
 */
import React, { useMemo } from 'react';
import { editAttrs } from '../attrs.js';
import { moneyFormatter } from '../shop.js';
import { fillUi, resolveShopUi, type ShopUi, type ShopUiKey } from '../ui.js';
import { useOptionalCms } from './context.js';

/** Rótulos de la tienda: `overrides` > `global.ui` del sitio > `SHOP_UI` (español neutro). */
export function useShopUi(overrides?: Partial<ShopUi>): ShopUi {
  const cms = useOptionalCms();
  const ui = cms?.payload?.global?.ui;
  const key = JSON.stringify([ui || null, overrides || null]);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  return useMemo(() => resolveShopUi(cms?.payload?.global, overrides), [key]);
}

/**
 * Un rótulo de `global.ui` con su valor por defecto. Emite `data-cms-global="ui.<clave>"`: en el
 * editor del portal, un clic abre el global para editarlo (regla de editabilidad).
 */
export function CmsUiText({ k, n, as: Tag = 'span', fallback, ...rest }: { k: ShopUiKey | (string & {}); n?: string | number; as?: React.ElementType; fallback?: string } & Omit<React.HTMLAttributes<HTMLElement>, 'children'>) {
  const ui = useShopUi() as Record<string, string>;
  const raw = ui[k] ?? fallback ?? '';
  return (
    <Tag {...rest} {...editAttrs({ global: `ui.${k}`, type: 'text' })}>
      {n !== undefined ? fillUi(raw, n) : raw}
    </Tag>
  );
}

/**
 * Formateador de dinero con la moneda y el locale del proyecto (delivery `ecommerce`), o los que pases.
 * Sin <CmsProvider> usa COP / es-CO.
 */
export function useMoney(source?: { currency?: string; locale?: string } | null): (amount: number) => string {
  const cms = useOptionalCms();
  const eco = source || cms?.payload?.ecommerce || null;
  const currency = eco?.currency;
  const locale = eco?.locale;
  return useMemo(() => moneyFormatter({ currency, locale }), [currency, locale]);
}
