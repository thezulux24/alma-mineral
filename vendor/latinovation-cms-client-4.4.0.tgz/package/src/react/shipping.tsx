'use client';

/**
 * Opciones de envío para el checkout de un storefront headless (v5 F2.9, docs/LOGISTICS.md §8).
 *
 *   const ship = useShippingOptions({ slug: 'mi-tienda', address: { city, department, postalCode }, items });
 *   ship.options.map((o) => <label><input type="radio" checked={ship.selectedId === o.id} onChange={() => ship.select(o.id)} /> {o.name} · {o.amount}</label>)
 *   await shop.checkout({ ...input, shippingOptionId: ship.selectedId!, shippingAmount: ship.selected?.amount });
 *
 * Vuelve a cotizar (con espera de `debounceMs`) cuando cambian la dirección o el carrito y conserva
 * la elección si sigue disponible; si no, elige `defaultOptionId`. Sin dirección suficiente no
 * llama al servidor. Dentro de <ShopAccountProvider> usa su cliente; si no, pásale `client` o `slug`.
 */
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { createShopClient, type ShopCheckoutItem, type ShopClient, type ShopError, type ShopShippingAddress, type ShopShippingOption, type ShopShippingQuote } from '../shop.js';
import { useOptionalShopAccount } from './shop.js';

export interface UseShippingOptionsInput {
  address: ShopShippingAddress | null | undefined;
  items: ShopCheckoutItem[];
  client?: ShopClient;
  slug?: string;
  apiUrl?: string;
  /** Espera antes de cotizar tras un cambio (por defecto 400 ms). */
  debounceMs?: number;
  /** false pausa la cotización (p. ej. mientras el carrito está cerrado). */
  enabled?: boolean;
}

export interface UseShippingOptionsValue {
  quote: ShopShippingQuote | null;
  options: ShopShippingOption[];
  selectedId: string | null;
  selected: ShopShippingOption | null;
  select(id: string): void;
  loading: boolean;
  error: ShopError | null;
  /** Cotiza ya (sin esperar). */
  refresh(): Promise<ShopShippingQuote | null>;
}

/** true cuando la dirección permite cotizar: ciudad o código DANE, o código postal. */
export function canQuoteAddress(a: ShopShippingAddress | null | undefined): boolean {
  if (!a) return false;
  return Boolean(String(a.city || '').trim() || String(a.daneCode || '').trim() || String(a.postalCode || '').trim());
}

export function useShippingOptions(input: UseShippingOptionsInput): UseShippingOptionsValue {
  const ctx = useOptionalShopAccount();
  const { address, items, debounceMs = 400, enabled = true } = input;
  const client = useMemo<ShopClient | null>(() => {
    if (input.client) return input.client;
    if (ctx?.client && (!input.slug || ctx.client.slug === input.slug)) return ctx.client;
    return input.slug ? createShopClient({ slug: input.slug, apiUrl: input.apiUrl }) : null;
  }, [input.client, input.slug, input.apiUrl, ctx?.client]);

  const [quote, setQuote] = useState<ShopShippingQuote | null>(null);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<ShopError | null>(null);
  const seq = useRef(0);
  const chosen = useRef<string | null>(null);

  const key = JSON.stringify({
    a: address ? { c: address.city, d: address.department || address.state, p: address.postalCode, n: address.daneCode, k: address.country } : null,
    i: (items || []).map((it) => [it.productId, it.quantity, it.variant || '']),
  });

  const run = useCallback(async (): Promise<ShopShippingQuote | null> => {
    if (!client || !enabled || !canQuoteAddress(address) || !(items || []).length) return null;
    const id = ++seq.current;
    setLoading(true);
    try {
      const q = await client.quoteShipping({ address: address as ShopShippingAddress, items });
      if (id !== seq.current) return q;
      setQuote(q);
      setError(null);
      const keep = chosen.current && q.options.some((o) => o.id === chosen.current) ? chosen.current : q.defaultOptionId;
      setSelectedId(keep);
      return q;
    } catch (e) {
      if (id === seq.current) {
        setError(e as ShopError);
        setQuote(null);
        setSelectedId(null);
      }
      return null;
    } finally {
      if (id === seq.current) setLoading(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [client, enabled, key]);

  useEffect(() => {
    if (!enabled) return;
    const t = setTimeout(() => void run(), Math.max(0, debounceMs));
    return () => clearTimeout(t);
  }, [run, debounceMs, enabled]);

  const select = useCallback((id: string) => {
    chosen.current = id;
    setSelectedId(id);
  }, []);

  const options = quote?.options || [];
  const selected = options.find((o) => o.id === selectedId) || null;
  return { quote, options, selectedId, selected, select, loading, error, refresh: run };
}
