'use client';

// Carrito para storefronts headless React / Next.js. Un solo <CartProvider> / useCart() reúne:
//  - líneas guardadas en el navegador (createCart, src/cart.ts);
//  - totales siempre cotizados por el servidor, con cupones y tarjetas de regalo (docs/PRICING.md §5);
//  - guardado en el CMS con espera en cuanto hay correo o teléfono, y restauración desde el enlace
//    /carrito/recuperar?token=… (carrito abandonado, docs/ABANDONED-CART.md);
//  - «Pedir por WhatsApp» con los mismos precios del servidor (docs/WHATSAPP.md).
//
//   <CartProvider slug="mi-tienda">{children}</CartProvider>
//   const { items, add, applyCoupon, pricing, setContact, checkout, buildWhatsAppOrder } = useCart();
//   const r = await applyCoupon('BIENVENIDA10'); if (!r.ok) alert(r.message);
import React, { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, useSyncExternalStore } from 'react';
import {
  buildWhatsAppOrder as buildWhatsAppOrderRequest,
  createCart,
  normalizeCode,
  readCartRecoveryToken,
  type Cart,
  type CartContact,
  type CartLine,
  type CartLineInput,
  type CartOptions,
  type CartRecovery,
  type WhatsAppOrderInput,
  type WhatsAppOrderResult,
} from '../cart.js';
import {
  createShopClient,
  ShopError,
  type ShopCheckoutInput,
  type ShopCheckoutResult,
  type ShopClient,
  type ShopPricing,
  type ShopStorage,
} from '../shop.js';

/** Alias de compatibilidad (v5 F2 precios): una línea del carrito. */
export type CartItem = CartLine;

export interface CartCodeResult {
  ok: boolean;
  /** true si el código cambió el total (un cupón válido puede no ahorrar hoy). */
  applied?: boolean;
  message?: string;
  reason?: string;
}

export interface CartValue {
  items: CartLine[];
  count: number;
  /** Estimación local (precio × cantidad); el total real está en `pricing`. */
  subtotal: number;
  /** Igual que `subtotal` (nombre anterior). */
  estimatedSubtotal: number;
  contact: CartContact;
  couponCodes: string[];
  giftCardCodes: string[];
  /** Cotización del servidor; null sin líneas o mientras llega la primera. */
  pricing: ShopPricing | null;
  loading: boolean;
  error: ShopError | null;
  /** Agrega una línea (`quantity` como 2.º argumento o dentro de la línea; por defecto 1). */
  add(line: CartLineInput, quantity?: number): void;
  setQuantity(index: number, quantity: number): void;
  remove(index: number): void;
  /** Vacía el carrito (y empieza un carrito nuevo en el CMS). */
  clear(): void;
  applyCoupon(code: string): Promise<CartCodeResult>;
  removeCoupon(code: string): void;
  applyGiftCard(code: string): Promise<CartCodeResult>;
  removeGiftCard(code: string): void;
  /** Desde el checkout: con correo o teléfono el carrito se guarda en el CMS (con espera). Re-cotiza. */
  setContact(contact: CartContact): void;
  /** Atajo de setContact({ email }) (algunos cupones dependen del correo). */
  setCustomerEmail(email: string): void;
  /** Guarda ya en el CMS (sin esperar). */
  flush(): Promise<void>;
  /** Restaura el carrito de un enlace de recuperación y aplica su cupón si lo trae. */
  recover(token: string): Promise<CartRecovery>;
  /** Última recuperación (enlace /carrito/recuperar), con el cupón de la tienda si lo hay. */
  recovered: CartRecovery | null;
  /** Vuelve a cotizar ya (p. ej. tras cambiar la ciudad). */
  refresh(): Promise<ShopPricing | null>;
  /** Checkout con las líneas y códigos del carrito; lo vacía si el pedido se crea. */
  checkout(input: Omit<ShopCheckoutInput, 'items'>, opts?: { saveAddress?: boolean }): Promise<ShopCheckoutResult>;
  /**
   * «Pedir por WhatsApp»: crea el pedido PENDING_WHATSAPP con las líneas, cupones y tarjetas del
   * carrito (precios del servidor) y devuelve `whatsappUrl`. Vacía el carrito salvo `keepCart`.
   */
  buildWhatsAppOrder(input?: Partial<Omit<WhatsAppOrderInput, 'slug' | 'apiUrl' | 'fetch' | 'items'>> & { keepCart?: boolean }): Promise<WhatsAppOrderResult>;
  client: ShopClient;
  cart: Cart;
}

const CartContext = createContext<CartValue | null>(null);

/** `slug` (o un `client` de createShopClient, o un `cart` de createCart) identifica la tienda. */
type SourceProps = { client?: ShopClient; slug?: string; apiUrl?: string };

export type CartProviderProps = {
  children?: React.ReactNode;
  /** Carrito ya creado con createCart() (se comparte fuera de React). */
  cart?: Cart;
  /** Espera antes de re-cotizar (ms). */
  quoteDelayMs?: number;
  /** `false` no cotiza en el servidor (solo estimación local). */
  quote?: boolean;
  /** Dónde se guarda el carrito (por defecto `storage` o localStorage; null = solo memoria). */
  cartStorage?: ShopStorage | null;
  /** Restaura el carrito en /carrito/recuperar?token=… al montar (por defecto sí). */
  recoverOnMount?: boolean;
  /** Ruta de recuperación (por defecto /carrito/recuperar). */
  recoverPath?: RegExp;
} & SourceProps &
  Omit<Partial<CartOptions>, 'slug' | 'apiUrl'>;

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const EMPTY: Snapshot = { items: [], contact: {}, couponCodes: [], giftCardCodes: [], count: 0, subtotal: 0 };

type Snapshot = { items: CartLine[]; contact: CartContact; couponCodes: string[]; giftCardCodes: string[]; count: number; subtotal: number };
let snapshotCache = new WeakMap<Cart, { key: string; value: Snapshot }>();

function snapshot(cart: Cart): Snapshot {
  const key = JSON.stringify([cart.items, cart.contact, cart.couponCodes, cart.giftCardCodes]);
  const hit = snapshotCache.get(cart);
  if (hit && hit.key === key) return hit.value;
  const value = { items: cart.items, contact: cart.contact, couponCodes: cart.couponCodes, giftCardCodes: cart.giftCardCodes, count: cart.count, subtotal: cart.subtotal };
  snapshotCache.set(cart, { key, value });
  return value;
}

/** Reinicia la caché de instantáneas (pruebas). */
export function __resetCartSnapshots() {
  snapshotCache = new WeakMap();
}

const toItems = (items: CartLine[]) => items.map((i) => ({ productId: i.productId, quantity: i.quantity, ...(i.variant ? { variant: i.variant } : {}) }));

export function CartProvider(props: CartProviderProps) {
  const { children, quoteDelayMs = 300, quote: quoteOn = true, recoverOnMount = true, recoverPath = /\/carrito\/recuperar\/?$/ } = props;
  const optsRef = useRef(props);
  optsRef.current = props;
  const slug = props.client ? props.client.slug : props.slug || props.cart?.slug || '';
  const apiUrl = props.client ? props.client.apiUrl : props.apiUrl;

  const client = useMemo<ShopClient>(() => {
    const p = optsRef.current;
    if (p.client) return p.client;
    return createShopClient({ slug, apiUrl, storage: p.storage, fetch: p.fetch });
  }, [props.client, slug, apiUrl]);

  // Un carrito creado aquí lee el navegador: en SSR y en la hidratación se muestra vacío.
  const external = props.cart;
  const cart = useMemo<Cart>(() => {
    if (external) return external;
    const p = optsRef.current;
    return createCart({
      slug,
      apiUrl,
      storage: p.cartStorage !== undefined ? p.cartStorage : p.storage,
      fetch: p.fetch,
      debounceMs: p.debounceMs,
      sync: p.sync,
      source: p.source,
    });
  }, [external, slug, apiUrl]);

  const snap = useSyncExternalStore(
    (cb) => cart.subscribe(cb),
    () => snapshot(cart),
    () => (external ? snapshot(cart) : EMPTY),
  );

  const [pricing, setPricing] = useState<ShopPricing | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<ShopError | null>(null);
  const [recovered, setRecovered] = useState<CartRecovery | null>(null);
  const seq = useRef(0);

  const email = String(snap.contact.email || '').trim().toLowerCase();
  const quoteInput = useCallback(
    (over: { couponCodes?: string[]; giftCardCodes?: string[] } = {}) => ({
      items: toItems(cart.items),
      codes: over.couponCodes ?? cart.couponCodes,
      giftCardCodes: over.giftCardCodes ?? cart.giftCardCodes,
      ...(EMAIL_RE.test(email) ? { customerEmail: email } : {}),
    }),
    // snap cambia con cada cambio del carrito: la cotización usa siempre el estado actual.
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [cart, email, snap],
  );

  const refresh = useCallback(async (): Promise<ShopPricing | null> => {
    const id = ++seq.current;
    if (!cart.items.length || !quoteOn) {
      setPricing(null);
      setLoading(false);
      return null;
    }
    setLoading(true);
    try {
      const p = await client.quote(quoteInput());
      if (id === seq.current) {
        setPricing(p);
        setError(null);
      }
      return p;
    } catch (e) {
      if (id === seq.current) setError(e as ShopError);
      return null;
    } finally {
      if (id === seq.current) setLoading(false);
    }
  }, [cart, client, quoteInput, quoteOn]);

  useEffect(() => {
    const t = setTimeout(() => void refresh(), quoteDelayMs);
    return () => clearTimeout(t);
  }, [refresh, quoteDelayMs]);

  const applyCoupon = useCallback(
    async (raw: string): Promise<CartCodeResult> => {
      const code = normalizeCode(raw);
      if (!code) return { ok: false, message: 'Escribe un cupón' };
      if (cart.couponCodes.includes(code)) return { ok: true, applied: true };
      try {
        const r = await client.validateDiscount(code, quoteInput());
        if (!r.valid) return { ok: false, message: r.message, reason: r.reason };
        cart.setCodes({ couponCodes: [...cart.couponCodes, code] });
        if (r.pricing) setPricing(r.pricing);
        return { ok: true, applied: r.applied, message: r.message };
      } catch (e) {
        const err = e as ShopError;
        return { ok: false, message: err?.message, reason: (err?.body as any)?.reason || err?.code };
      }
    },
    [cart, client, quoteInput],
  );

  const applyGiftCard = useCallback(
    async (raw: string): Promise<CartCodeResult> => {
      const code = normalizeCode(raw);
      if (!code) return { ok: false, message: 'Escribe el código de la tarjeta' };
      if (cart.giftCardCodes.includes(code)) return { ok: true, applied: true };
      try {
        const p = await client.quote(quoteInput({ giftCardCodes: [...cart.giftCardCodes, code] }));
        // El servidor enmascara los códigos rechazados (••••1234): se comparan los últimos dígitos.
        const bad = p.rejectedGiftCards.find((g) => code.endsWith(String(g.code).replace(/^•+/, '')));
        if (bad && bad.reason !== 'NOT_NEEDED') return { ok: false, message: bad.message, reason: bad.reason };
        cart.setCodes({ giftCardCodes: [...cart.giftCardCodes, code] });
        setPricing(p);
        return { ok: true, applied: !bad };
      } catch (e) {
        const err = e as ShopError;
        return { ok: false, message: err?.message, reason: err?.code };
      }
    },
    [cart, client, quoteInput],
  );

  const removeCoupon = useCallback((code: string) => cart.setCodes({ couponCodes: cart.couponCodes.filter((c) => c !== normalizeCode(code)) }), [cart]);
  const removeGiftCard = useCallback((code: string) => cart.setCodes({ giftCardCodes: cart.giftCardCodes.filter((c) => c !== normalizeCode(code)) }), [cart]);

  const recover = useCallback(
    async (token: string) => {
      const r = await cart.recover(token);
      setRecovered(r);
      if (r.couponCode && !r.alreadyOrdered) await applyCoupon(r.couponCode).catch(() => undefined);
      return r;
    },
    [cart, applyCoupon],
  );

  // Enlace del correo o WhatsApp: /carrito/recuperar?token=…
  useEffect(() => {
    if (!recoverOnMount) return;
    const path = String((globalThis as any).location?.pathname || '');
    if (!recoverPath.test(path)) return;
    const token = readCartRecoveryToken();
    if (token) recover(token).catch(() => undefined);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [cart, recoverOnMount]);

  const checkout = useCallback(
    async (checkoutInput: Omit<ShopCheckoutInput, 'items'>, opts?: { saveAddress?: boolean }) => {
      const res = await client.checkout(
        {
          ...(checkoutInput as ShopCheckoutInput),
          items: toItems(cart.items),
          ...(cart.couponCodes.length ? { couponCodes: cart.couponCodes } : {}),
          ...(cart.giftCardCodes.length ? { giftCardCodes: cart.giftCardCodes } : {}),
        },
        opts,
      );
      cart.clear();
      return res;
    },
    [cart, client],
  );

  const buildWhatsAppOrder = useCallback<CartValue['buildWhatsAppOrder']>(
    async (input = {}) => {
      const { keepCart, ...rest } = input;
      const c = cart.contact;
      const res = await buildWhatsAppOrderRequest({
        slug,
        apiUrl,
        fetch: optsRef.current.fetch,
        items: toItems(cart.items),
        customerName: c.name,
        customerPhone: c.phone,
        customerEmail: c.email,
        ...(cart.couponCodes.length ? { couponCodes: cart.couponCodes } : {}),
        ...(cart.giftCardCodes.length ? { giftCardCodes: cart.giftCardCodes } : {}),
        ...rest,
      });
      if (!keepCart) cart.clear();
      return res;
    },
    [cart, slug, apiUrl],
  );

  const value = useMemo<CartValue>(
    () => ({
      items: snap.items,
      count: snap.count,
      subtotal: snap.subtotal,
      estimatedSubtotal: snap.subtotal,
      contact: snap.contact,
      couponCodes: snap.couponCodes,
      giftCardCodes: snap.giftCardCodes,
      pricing,
      loading,
      error,
      add: (line, quantity) => cart.add(line, quantity),
      setQuantity: (i, q) => cart.setQuantity(i, q),
      remove: (i) => cart.remove(i),
      clear: () => cart.clear(),
      applyCoupon,
      removeCoupon,
      applyGiftCard,
      removeGiftCard,
      setContact: (c) => cart.setContact(c),
      setCustomerEmail: (e) => cart.setContact({ email: String(e || '').trim().toLowerCase() }),
      flush: () => cart.flush(),
      recover,
      recovered,
      refresh,
      checkout,
      buildWhatsAppOrder,
      client,
      cart,
    }),
    [snap, pricing, loading, error, cart, applyCoupon, removeCoupon, applyGiftCard, removeGiftCard, recover, recovered, refresh, checkout, buildWhatsAppOrder, client],
  );
  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}

/** Carrito de la tienda. Requiere <CartProvider>. */
export function useCart(): CartValue {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error('useCart() requiere <CartProvider slug="…"> más arriba en el árbol.');
  return ctx;
}

/** Igual que useCart() pero devuelve null fuera del provider. */
export function useOptionalCart(): CartValue | null {
  return useContext(CartContext);
}
