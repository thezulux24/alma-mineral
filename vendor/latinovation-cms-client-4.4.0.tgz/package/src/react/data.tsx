'use client';

import React, { useCallback, useContext, useEffect, useMemo, useState } from 'react';
import type { CollectionItem, NavLink, Product } from '../types.js';
import { getGlobal, getProducts, getStoreCollectionSlug, mediaUrl, normalizeProduct, type GetProductsOptions } from '../delivery.js';
import { getItem, getItemRoute, queryCollection, type CollectionQuery, type CollectionQueryResult, type FilterValue, type ItemRouteOptions } from '../collections.js';
import { editAttrs } from '../attrs.js';
import { getPath } from '../paths.js';
import { focalToObjectPosition, safeHref, str } from '../fields.js';
import { ItemContext, useCms, type ItemScope } from './context.js';

// ───────────── colecciones ─────────────

/** Productos del payload en vivo (contrato 2.5 normalizado). */
export function useProducts(opts: GetProductsOptions = {}): Product[] {
  const { payload } = useCms();
  const key = JSON.stringify(opts);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  return useMemo(() => getProducts(payload, opts), [payload, key]);
}

/** Ítem de una colección por slug o id (del payload en vivo: refleja ediciones del portal). */
export function useItem<T extends CollectionItem = CollectionItem>(collection: string | undefined, itemSlug: string | undefined): T | undefined {
  const { payload } = useCms();
  return useMemo(() => {
    const col = collection || getStoreCollectionSlug(payload);
    if (!col || !itemSlug) return undefined;
    return getItem(payload, col, itemSlug) as T | undefined;
  }, [payload, collection, itemSlug]);
}

/** Producto normalizado por slug o id. */
export function useProduct(slugOrId: string | undefined, collection?: string): Product | undefined {
  const item = useItem(collection, slugOrId);
  return useMemo(() => (item ? normalizeProduct(item) : undefined), [item]);
}

/** Ruta de detalle de un ítem (routeBase de la colección o `pattern`). */
export function useItemRoute(collection: string, item: Pick<CollectionItem, 'slug' | 'id'> | string, opts?: ItemRouteOptions): string | undefined {
  const { payload } = useCms();
  return getItemRoute(payload, collection, item, opts);
}

export interface UseCollectionQuery<T> extends CollectionQueryResult<T> {
  query: CollectionQuery;
  setQuery(patch: Partial<CollectionQuery>): void;
  setFilter(field: string, value: FilterValue): void;
  setSearch(search: string): void;
  setSort(sort: string): void;
  setPage(page: number): void;
  reset(): void;
}

/**
 * Búsqueda, filtros (select, rango de precio, booleanos según `collectionDefinitions[col].filters`),
 * orden y paginación en el cliente sobre la colección del payload en vivo.
 * El argumento es el estado inicial; cambia el estado con los setters.
 */
export function useCollectionQuery<T extends CollectionItem = CollectionItem>(initial: CollectionQuery = {}): UseCollectionQuery<T> {
  const { payload } = useCms();
  const seed = JSON.stringify(initial);
  const [query, setQueryState] = useState<CollectionQuery>(initial);
  useEffect(() => setQueryState(JSON.parse(seed)), [seed]);
  const result = useMemo(() => queryCollection<T>(payload, query), [payload, query]);
  const setQuery = useCallback((patch: Partial<CollectionQuery>) => setQueryState((q) => ({ ...q, ...patch })), []);
  const setFilter = useCallback(
    (field: string, value: FilterValue) => setQueryState((q) => ({ ...q, page: 1, filters: { ...(q.filters || {}), [field]: value } })),
    [],
  );
  return {
    ...result,
    query,
    setQuery,
    setFilter,
    setSearch: useCallback((search: string) => setQueryState((q) => ({ ...q, search, page: 1 })), []),
    setSort: useCallback((sort: string) => setQueryState((q) => ({ ...q, sort, page: 1 })), []),
    setPage: useCallback((page: number) => setQueryState((q) => ({ ...q, page })), []),
    reset: useCallback(() => setQueryState(JSON.parse(seed)), [seed]),
  };
}

// ───────────── ítems editables ─────────────

function useItemScope(item?: (Record<string, any> & { id: string }) | null, collection?: string): ItemScope | null {
  const scope = useContext(ItemContext);
  const { payload } = useCms();
  const it = item || scope?.item;
  if (!it) return null;
  const col = collection || scope?.collection || getStoreCollectionSlug(payload) || '';
  return { item: it, collection: col };
}

type Rest = Omit<React.HTMLAttributes<HTMLElement>, 'children'> & Record<string, any>;

/** Envuelve una tarjeta/ficha de ítem: marca `data-cms-item` y da contexto a CmsItemText/CmsItemImage. */
export function CmsItem({ item, collection, as: Tag = 'div', children, ...rest }: Rest & { item: Record<string, any> & { id: string }; collection?: string; as?: React.ElementType; children?: React.ReactNode }) {
  const { payload } = useCms();
  const col = collection || getStoreCollectionSlug(payload) || '';
  return (
    <ItemContext.Provider value={{ item, collection: col }}>
      <Tag {...rest} {...editAttrs({ item: { collection: col, id: item.id } })}>
        {children}
      </Tag>
    </ItemContext.Provider>
  );
}

export interface CmsItemTextProps extends Rest {
  item?: Record<string, any> & { id: string };
  /** Campo del ítem (`title`, `brand`, `summary`, `price`…). */
  f: string;
  collection?: string;
  as?: React.ElementType;
  fallback?: string;
  multiline?: boolean;
  /** Con formato (p. ej. precio) el campo se edita desde el editor del ítem. */
  format?: (value: unknown, item: Record<string, any>) => string;
  editable?: boolean;
}

/** Texto de un ítem de colección: en línea → INLINE_COLLECTION_ITEM_CHANGE; con formato → FOCUS_COLLECTION_ITEM. */
export function CmsItemText({ item, f, collection, as: Tag = 'span', fallback = '', multiline, format, editable = true, className, ...rest }: CmsItemTextProps) {
  const cms = useCms();
  const scope = useItemScope(item, collection);
  if (!scope) return null;
  const raw = getPath(scope.item, f);
  const value = format ? format(raw, scope.item) : str(raw) || fallback;
  if (!value && !cms.isBuilder) return null;
  const inline = cms.isBuilder && editable && !format;
  return (
    <Tag
      key={inline ? `e:${value}` : undefined}
      {...rest}
      {...editAttrs({ item: { collection: scope.collection, id: scope.item.id }, field: f, type: multiline ? 'textarea' : 'text' })}
      className={className}
      contentEditable={inline || undefined}
      suppressContentEditableWarning={inline || undefined}
      data-cms-multiline={multiline ? '' : undefined}
      data-cms-empty={cms.isBuilder && !value ? 'true' : undefined}
      data-cms-placeholder={cms.isBuilder ? f : undefined}
    >
      {value}
    </Tag>
  );
}

export interface CmsItemImageProps extends Omit<React.ImgHTMLAttributes<HTMLImageElement>, 'src'> {
  item?: Record<string, any> & { id: string };
  /** Campo de imagen (por defecto `imageUrl`, con respaldo `image` y la primera de `gallery`). */
  f?: string;
  collection?: string;
  as?: React.ElementType;
  /** Índice de `gallery` si `f="gallery"`. */
  index?: number;
}

/** Imagen de un ítem; en el editor un clic abre el editor del ítem en ese campo (FOCUS_COLLECTION_ITEM). */
export function CmsItemImage({ item, f, collection, as: Img = 'img', index = 0, alt, style, ...rest }: CmsItemImageProps) {
  const cms = useCms();
  const scope = useItemScope(item, collection);
  if (!scope) return null;
  const it = scope.item;
  const field = f || (it.imageUrl ? 'imageUrl' : it.image ? 'image' : it.gallery ? 'gallery' : 'imageUrl');
  const v = getPath(it, field);
  const list = Array.isArray(v) ? v : typeof v === 'string' && field === 'gallery' ? v.split(/\s*[|,\n]\s*/) : null;
  const src = str(list ? list[index] : v);
  const attrs = editAttrs({ item: { collection: scope.collection, id: it.id }, field, type: field === 'gallery' ? 'gallery' : 'image' });
  if (!src) return cms.isBuilder ? <span {...attrs} className="cms-ui-empty-media">Agregar imagen</span> : null;
  const focal = focalToObjectPosition(it[`${field}Focal`]);
  return (
    <Img
      loading="lazy"
      decoding="async"
      {...rest}
      {...attrs}
      src={mediaUrl(src, cms.cmsUrl)}
      alt={alt ?? (str(it[`${field}Alt`]) || str(it.title))}
      style={focal ? { objectPosition: focal, ...(style || {}) } : style}
    />
  );
}

/** Botón (solo editor) para crear un ítem en la colección → CREATE_COLLECTION_ITEM. */
export function CmsAddItem({ collection, category, label = 'Agregar ítem', className }: { collection?: string; category?: string; label?: string; className?: string }) {
  const cms = useCms();
  if (!cms.isBuilder) return null;
  const col = collection || getStoreCollectionSlug(cms.payload) || '';
  return (
    <span className={['cms-ui', className].filter(Boolean).join(' ')}>
      <button type="button" className="cms-ui-add-item" onClick={() => cms.bridge?.createCollectionItem(col, category)}>
        {`+ ${label}`}
      </button>
    </span>
  );
}

// ───────────── globales ─────────────

/** Valor de `global` en vivo (ruta con puntos). */
export function useGlobal<T = any>(path: string, fallback?: T): T {
  const { payload } = useCms();
  return getGlobal<T>(payload, path, fallback);
}

export interface CmsGlobalTextProps extends Rest {
  f: string;
  as?: React.ElementType;
  fallback?: string;
  multiline?: boolean;
  editable?: boolean;
  format?: (value: unknown) => string;
}

/** Texto de `globalData` (marca, horario, dirección…). En línea → INLINE_GLOBAL_CHANGE; si no → FOCUS_GLOBAL. */
export function CmsGlobalText({ f, as: Tag = 'span', fallback = '', multiline, editable = true, format, className, ...rest }: CmsGlobalTextProps) {
  const cms = useCms();
  const raw = getGlobal(cms.payload, f);
  const value = format ? format(raw) : str(raw) || fallback;
  if (!value && !cms.isBuilder) return null;
  const inline = cms.isBuilder && editable && !format;
  return (
    <Tag
      key={inline ? `e:${value}` : undefined}
      {...rest}
      {...editAttrs({ global: f, type: multiline ? 'textarea' : 'text' })}
      className={className}
      contentEditable={inline || undefined}
      suppressContentEditableWarning={inline || undefined}
      data-cms-multiline={multiline ? '' : undefined}
      data-cms-empty={cms.isBuilder && !value ? 'true' : undefined}
      data-cms-placeholder={cms.isBuilder ? f : undefined}
    >
      {value}
    </Tag>
  );
}

/** Imagen de `globalData` (logo, sello…). En el editor, un clic → FOCUS_GLOBAL. */
export function CmsGlobalImage({ f, as: Img = 'img', alt, ...rest }: Omit<React.ImgHTMLAttributes<HTMLImageElement>, 'src'> & { f: string; as?: React.ElementType }) {
  const cms = useCms();
  const src = str(getGlobal(cms.payload, f));
  const attrs = editAttrs({ global: f, type: 'image' });
  if (!src) return cms.isBuilder ? <span {...attrs} className="cms-ui-empty-media">Agregar imagen</span> : null;
  return <Img {...rest} {...attrs} src={mediaUrl(src, cms.cmsUrl)} alt={alt ?? str(getGlobal(cms.payload, `${f}Alt`) || getGlobal(cms.payload, 'brandName'))} />;
}

// ───────────── navegación ─────────────

export type NavList = 'header' | 'footer';

/** Enlaces visibles del menú con su índice original (el que espera el portal). */
export function useNavLinks(list: NavList = 'header'): Array<NavLink & { index: number }> {
  const { payload } = useCms();
  return useMemo(() => {
    const links = (payload.navigation?.[list === 'footer' ? 'footerLinks' : 'headerLinks'] || []) as NavLink[];
    return links.map((l, index) => ({ ...l, index })).filter((l) => l.isVisible !== false);
  }, [payload, list]);
}

export interface CmsNavLinkProps extends Omit<React.AnchorHTMLAttributes<HTMLAnchorElement>, 'href'> {
  link: NavLink & { index?: number };
  index?: number;
  list?: NavList;
  as?: React.ElementType;
}

/** Enlace del menú: etiqueta en línea (INLINE_NAV_CHANGE) y botón del editor → FOCUS_NAV. */
export function CmsNavLink({ link, index, list = 'header', as: A = 'a', className, ...rest }: CmsNavLinkProps) {
  const cms = useCms();
  const i = index ?? link.index ?? 0;
  const nav = list === 'footer' ? `footer.${i}` : String(i);
  const href = safeHref(link.href);
  return (
    <A {...rest} {...editAttrs({ nav, type: 'link' })} href={href || (cms.isBuilder ? '#' : undefined)} className={className}>
      <span
        key={cms.isBuilder ? `e:${link.label}` : undefined}
        {...editAttrs({ nav, field: 'label', type: 'text' })}
        contentEditable={cms.isBuilder || undefined}
        suppressContentEditableWarning={cms.isBuilder || undefined}
      >
        {link.label}
      </span>
      {cms.isBuilder ? (
        <span className="cms-ui cms-ui-link-btn">
          <button
            type="button"
            title="Editar menú"
            aria-label="Editar menú"
            onClick={(e) => {
              e.preventDefault();
              e.stopPropagation();
              cms.bridge?.focusNav(i, list === 'footer' ? 'footerLinks' : undefined);
            }}
          >
            🔗
          </button>
        </span>
      ) : null}
    </A>
  );
}

/** Menú completo: `<CmsNav list="header" className="menu" linkClassName="menu-link" />`. */
export function CmsNav({ list = 'header', as: Tag = 'nav', linkClassName, renderLink, ...rest }: Rest & { list?: NavList; as?: React.ElementType; linkClassName?: string; renderLink?: (link: NavLink & { index: number }) => React.ReactNode }) {
  const links = useNavLinks(list);
  if (!links.length) return null;
  return (
    <Tag {...rest} data-cms-nav-list={list}>
      {links.map((l) => (renderLink ? <React.Fragment key={l.id || l.index}>{renderLink(l)}</React.Fragment> : <CmsNavLink key={l.id || l.index} link={l} list={list} className={linkClassName} />))}
    </Tag>
  );
}

/** Texto plano de la navegación (`headerCtaText`) o del banner (`promo` → `promoBanner.<f>`). */
export function CmsNavText({ f, promo, as: Tag = 'span', fallback = '', className, ...rest }: Rest & { f: string; promo?: boolean; as?: React.ElementType; fallback?: string }) {
  const cms = useCms();
  const nav = (cms.payload.navigation || {}) as Record<string, any>;
  const value = str(promo ? nav.promoBanner?.[f] : nav[f]) || fallback;
  if (!value && !cms.isBuilder) return null;
  const key = promo ? `promoBanner.${f}` : f;
  return (
    <Tag
      key={cms.isBuilder ? `e:${value}` : undefined}
      {...rest}
      {...editAttrs({ nav: key, type: 'text' })}
      className={className}
      contentEditable={cms.isBuilder || undefined}
      suppressContentEditableWarning={cms.isBuilder || undefined}
      data-cms-empty={cms.isBuilder && !value ? 'true' : undefined}
      data-cms-placeholder={cms.isBuilder ? f : undefined}
    >
      {value}
    </Tag>
  );
}
