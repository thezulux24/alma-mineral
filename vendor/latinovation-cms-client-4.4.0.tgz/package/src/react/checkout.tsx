'use client';

/**
 * Checkout completo para storefronts headless React / Next.js (mismo flujo que el carrito de /site):
 * datos del comprador, dirección, envío a domicilio o retiro en tienda, franja de entrega, opciones
 * de envío por zona, métodos de pago del país (incluidos BNPL), cupones y tarjetas de regalo con la
 * cotización del servidor, medición (event_id) y redirección a la pasarela.
 *
 *   <CmsProvider initial={initial} slug="mi-tienda">
 *     <ShopAccountProvider slug="mi-tienda"><CartProvider slug="mi-tienda">…</CartProvider></ShopAccountProvider>
 *   </CmsProvider>
 *
 *   const co = useCheckout();
 *   <input value={co.form.customerEmail} onChange={(e) => co.setField('customerEmail', e.target.value)} />
 *   co.shipping.options.map((o) => …co.shipping.select(o.id))
 *   co.paymentMethods.map((m) => …co.setProvider(m.id))
 *   <CmsPricingTotals pricing={co.pricing} />
 *   <button disabled={co.submitting} onClick={co.submit}>…</button>
 *
 *   // página de retorno de la pasarela:
 *   const ret = usePaymentReturn();   // ret.status: 'checking' | 'paid' | 'failed' | 'pending' | 'none'
 *
 * Todos los textos salen de `global.ui` (useShopUi); el total final siempre lo calcula el servidor.
 */
import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  checkoutExtrasBody,
  checkoutOptions,
  createShopClient,
  paymentOptions,
  pricingRows,
  ShopError,
  type ShopCheckoutInput,
  type ShopCheckoutItem,
  type ShopCheckoutOptionsConfig,
  type ShopCheckoutResult,
  type ShopClient,
  type ShopConfirmResult,
  type ShopDeliverySlot,
  type ShopFulfillment,
  type ShopPaymentOption,
  type ShopPricing,
  type ShopPublicConfig,
  type ShopRetryResult,
} from '../shop.js';
import { normalizeCode } from '../cart.js';
import { newEventId, trackingContext } from '../tracking/core.js';
import type { ShopUi } from '../ui.js';
import { useOptionalCms } from './context.js';
import { useOptionalCart, type CartCodeResult } from './cart.js';
import { useOptionalShopAccount } from './shop.js';
import { useShippingOptions, type UseShippingOptionsValue } from './shipping.js';
import { useMoney, useShopUi } from './ui.js';

/* ------------------------------------------------------------------ */
/* Cliente y configuración                                            */
/* ------------------------------------------------------------------ */

export interface ShopSourceOptions {
  client?: ShopClient;
  slug?: string;
  apiUrl?: string;
}

/**
 * Cliente de la tienda del árbol: el que pases, el del <CartProvider>, el del <ShopAccountProvider>
 * o uno nuevo con el slug y la URL del <CmsProvider>. null si no hay de dónde sacarlo.
 */
export function useShopClient(opts: ShopSourceOptions = {}): ShopClient | null {
  const cms = useOptionalCms();
  const cart = useOptionalCart();
  const account = useOptionalShopAccount();
  const slug = opts.slug || cms?.slug || '';
  const apiUrl = opts.apiUrl || cms?.cmsUrl || undefined;
  return useMemo<ShopClient | null>(() => {
    if (opts.client) return opts.client;
    for (const c of [cart?.client, account?.client]) if (c && (!opts.slug || c.slug === opts.slug)) return c;
    return slug ? createShopClient({ slug, apiUrl }) : null;
  }, [opts.client, opts.slug, cart?.client, account?.client, slug, apiUrl]);
}

const configCache = new Map<string, Promise<ShopPublicConfig>>();

/** Vacía la caché de `useShopConfig` (pruebas, o tras cambiar la tienda en el portal). */
export function clearShopConfigCache(): void {
  configCache.clear();
}

export interface UseShopConfig {
  config: ShopPublicConfig | null;
  loading: boolean;
  error: ShopError | null;
  reload(): Promise<ShopPublicConfig | null>;
}

/** Config pública de la tienda (métodos de pago, envío, extras, moneda), una sola petición por tienda. */
export function useShopConfig(opts: ShopSourceOptions & { config?: ShopPublicConfig | null } = {}): UseShopConfig {
  const client = useShopClient(opts);
  const given = opts.config;
  const key = client ? `${client.apiUrl}|${client.slug}` : '';
  const [state, setState] = useState<{ key: string; config: ShopPublicConfig | null; error: ShopError | null }>({ key: '', config: null, error: null });
  const load = useCallback(
    async (fresh = false): Promise<ShopPublicConfig | null> => {
      if (!client) return null;
      if (fresh) configCache.delete(key);
      let p = configCache.get(key);
      if (!p) {
        p = client.config();
        configCache.set(key, p);
        p.catch(() => configCache.delete(key));
      }
      try {
        const config = await p;
        setState({ key, config, error: null });
        return config;
      } catch (e) {
        setState({ key, config: null, error: e as ShopError });
        return null;
      }
    },
    [client, key],
  );
  useEffect(() => {
    if (given === undefined) void load();
  }, [load, given]);
  if (given !== undefined) return { config: given, loading: false, error: null, reload: async () => given };
  const current = state.key === key ? state : { config: null, error: null };
  return { config: current.config, loading: Boolean(client) && !current.config && !current.error, error: current.error, reload: () => load(true) };
}

export interface UsePaymentMethods {
  /** Métodos del país de la tienda, en su orden; los BNPL fuera de rango con `available: false`. */
  options: ShopPaymentOption[];
  /** Solo los que se pueden elegir con el monto actual. */
  available: ShopPaymentOption[];
  config: ShopPublicConfig | null;
  loading: boolean;
}

/** Métodos de pago para el selector del checkout (`paymentOptions` con la config de la tienda). */
export function usePaymentMethods(opts: ShopSourceOptions & { amount?: number; country?: 'CO' | 'MX' | null; config?: ShopPublicConfig | null } = {}): UsePaymentMethods {
  const { config, loading } = useShopConfig(opts);
  const options = useMemo(() => paymentOptions(config, { amount: opts.amount, country: opts.country }), [config, opts.amount, opts.country]);
  return { options, available: options.filter((o) => o.available), config, loading };
}

/* ------------------------------------------------------------------ */
/* useCheckout                                                         */
/* ------------------------------------------------------------------ */

export interface CheckoutForm {
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  documentType: string;
  documentId: string;
  address: string;
  city: string;
  department: string;
  country: string;
  postalCode: string;
  daneCode: string;
  /** Indicaciones para la entrega (van en `shippingAddress.notes`). */
  notes: string;
}

const EMPTY_FORM: CheckoutForm = {
  customerName: '',
  customerEmail: '',
  customerPhone: '',
  documentType: 'CC',
  documentId: '',
  address: '',
  city: '',
  department: '',
  country: '',
  postalCode: '',
  daneCode: '',
  notes: '',
};

export type CheckoutErrors = Partial<Record<keyof CheckoutForm | 'provider' | 'shipping' | 'pickup' | 'deliverySlot' | 'pricing' | 'items', string>>;

export interface UseCheckoutOptions extends ShopSourceOptions {
  /** Líneas si no usas <CartProvider> (por defecto, las del carrito). */
  items?: ShopCheckoutItem[];
  /** Cupones y tarjetas sin <CartProvider>. */
  couponCodes?: string[];
  giftCardCodes?: string[];
  /** Valores iniciales (por defecto, los del cliente con sesión y su dirección predeterminada). */
  initial?: Partial<CheckoutForm>;
  /** Vuelta tras pagar (por defecto la página actual); debe ser un origen permitido del proyecto. */
  redirectUrl?: string;
  /** true (por defecto): con `checkoutUrl` lleva al comprador a la pasarela. */
  autoRedirect?: boolean;
  /** Guarda la dirección en la cuenta del cliente. */
  saveAddress?: boolean;
  /** Espera antes de re-cotizar (ms, por defecto 300). */
  quoteDelayMs?: number;
  /** Config ya cargada (evita la petición). */
  config?: ShopPublicConfig | null;
  /** Rótulos propios (por defecto global.ui). */
  labels?: Partial<ShopUi>;
}

export interface UseCheckout {
  form: CheckoutForm;
  setField<K extends keyof CheckoutForm>(key: K, value: CheckoutForm[K]): void;
  setForm(patch: Partial<CheckoutForm>): void;
  config: ShopPublicConfig | null;
  /** Retiro, franjas y notas que ofrece la tienda. */
  options: ShopCheckoutOptionsConfig & { deliveryDates: string[] };
  fulfillment: ShopFulfillment;
  setFulfillment(f: ShopFulfillment): void;
  pickupLocationId: string;
  setPickupLocation(id: string): void;
  deliverySlot: Partial<ShopDeliverySlot>;
  setDeliverySlot(slot: Partial<ShopDeliverySlot>): void;
  /** Opciones de envío por zona (vacías con retiro en tienda). */
  shipping: UseShippingOptionsValue;
  paymentMethods: ShopPaymentOption[];
  provider: string;
  setProvider(id: string): void;
  /** El comprador aceptó recordatorios del carrito (se guarda con el contacto). */
  reminderConsent: boolean;
  setReminderConsent(v: boolean): void;
  couponCodes: string[];
  giftCardCodes: string[];
  applyCoupon(code: string): Promise<CartCodeResult>;
  removeCoupon(code: string): void;
  applyGiftCard(code: string): Promise<CartCodeResult>;
  removeGiftCard(code: string): void;
  /** Cotización del servidor con envío, retiro, método de pago, cupones y tarjetas. */
  pricing: ShopPricing | null;
  quoting: boolean;
  /** Errores por campo de la última validación. */
  errors: CheckoutErrors;
  validate(): CheckoutErrors;
  submitting: boolean;
  error: string | null;
  result: ShopCheckoutResult | null;
  /** Instrucciones de pago (transferencia, contraentrega) del resultado. */
  instructions: string;
  /** event_id del último intento (el mismo del Purchase de la API de conversiones si es contraentrega). */
  eventId: string | null;
  /** Crea el pedido; null si la validación falla o el servidor lo rechaza (ver `errors` / `error`). */
  submit(e?: { preventDefault?: () => void }): Promise<ShopCheckoutResult | null>;
  reset(): void;
  client: ShopClient | null;
}

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const codeEq = (code: string, masked: string) => code.endsWith(String(masked).replace(/^•+/, ''));

export function useCheckout(opts: UseCheckoutOptions = {}): UseCheckout {
  const client = useShopClient(opts);
  const cart = useOptionalCart();
  const account = useOptionalShopAccount();
  const ui = useShopUi(opts.labels);
  const { config } = useShopConfig({ client: client || undefined, config: opts.config });
  const money = useMoney(config?.currency ? { currency: config.currency, locale: config.locale } : undefined);
  const options = useMemo(() => checkoutOptions(config), [config]);

  const customer = account?.customer || null;
  const defaultAddress = customer?.addresses?.find((a) => a.isDefault) || customer?.addresses?.[0];
  const [form, setFormState] = useState<CheckoutForm>(() => ({ ...EMPTY_FORM, ...(opts.initial || {}) }));
  const touched = useRef(new Set<keyof CheckoutForm>());
  // Prellenado con la cuenta (sin pisar lo que el comprador ya escribió).
  useEffect(() => {
    if (!customer) return;
    const fill: Partial<CheckoutForm> = {
      customerName: customer.name || '',
      customerEmail: customer.email || '',
      customerPhone: customer.phone || '',
      documentType: customer.documentType || '',
      documentId: customer.documentId || '',
      ...(defaultAddress
        ? { address: defaultAddress.address || '', city: defaultAddress.city || '', department: defaultAddress.department || '', country: defaultAddress.country || '', postalCode: defaultAddress.postalCode || '' }
        : {}),
    };
    setFormState((f) => {
      const next = { ...f };
      for (const [k, v] of Object.entries(fill) as Array<[keyof CheckoutForm, string]>) if (v && !touched.current.has(k) && !f[k]) next[k] = v;
      return next;
    });
  }, [customer?.id]); // eslint-disable-line react-hooks/exhaustive-deps

  const setField = useCallback(<K extends keyof CheckoutForm>(key: K, value: CheckoutForm[K]) => {
    touched.current.add(key);
    setFormState((f) => ({ ...f, [key]: value }));
  }, []);
  const setForm = useCallback((patch: Partial<CheckoutForm>) => {
    for (const k of Object.keys(patch)) touched.current.add(k as keyof CheckoutForm);
    setFormState((f) => ({ ...f, ...patch }));
  }, []);

  const [fulfillment, setFulfillmentState] = useState<ShopFulfillment>('shipping');
  const [pickupLocationId, setPickupLocation] = useState('');
  const [deliverySlot, setDeliverySlotState] = useState<Partial<ShopDeliverySlot>>({});
  const [provider, setProviderState] = useState('');
  const [reminderConsent, setReminderConsent] = useState(false);
  const pickup = options.pickup.enabled && fulfillment === 'pickup';
  const setFulfillment = useCallback(
    (f: ShopFulfillment) => {
      setFulfillmentState(f);
      if (f === 'pickup') setPickupLocation((cur) => cur || options.pickup.locations[0]?.id || '');
    },
    [options.pickup.locations],
  );
  const setDeliverySlot = useCallback((slot: Partial<ShopDeliverySlot>) => setDeliverySlotState((s) => ({ ...s, ...slot })), []);

  // Líneas y códigos: del carrito o de las opciones.
  const items = useMemo<ShopCheckoutItem[]>(
    () => opts.items || (cart?.items || []).map((i) => ({ productId: i.productId, quantity: i.quantity, ...(i.variant ? { variant: i.variant } : {}) })),
    [opts.items, cart?.items],
  );
  const [ownCoupons, setOwnCoupons] = useState<string[]>(() => (opts.couponCodes || []).map(normalizeCode).filter(Boolean));
  const [ownGifts, setOwnGifts] = useState<string[]>(() => (opts.giftCardCodes || []).map(normalizeCode).filter(Boolean));
  const couponCodes = cart ? cart.couponCodes : ownCoupons;
  const giftCardCodes = cart ? cart.giftCardCodes : ownGifts;

  // Contacto al carrito (carrito abandonado): con correo o teléfono queda guardado en el CMS.
  const email = form.customerEmail.trim().toLowerCase();
  useEffect(() => {
    if (!cart) return;
    const t = setTimeout(() => {
      const c = cart.contact;
      const next = { email: EMAIL_RE.test(email) ? email : undefined, phone: form.customerPhone.trim() || undefined, name: form.customerName.trim() || undefined, consent: reminderConsent };
      if (c.email !== next.email || c.phone !== next.phone || c.name !== next.name || Boolean(c.consent) !== next.consent) cart.setContact(next);
    }, 500);
    return () => clearTimeout(t);
  }, [cart, email, form.customerPhone, form.customerName, reminderConsent]);

  const address = useMemo(
    () =>
      pickup
        ? null
        : { address: form.address, city: form.city, department: form.department, country: form.country || undefined, postalCode: form.postalCode || undefined, daneCode: form.daneCode || undefined },
    [pickup, form.address, form.city, form.department, form.country, form.postalCode, form.daneCode],
  );
  const shipping = useShippingOptions({ client: client || undefined, slug: client ? undefined : opts.slug, address, items, enabled: !pickup && Boolean(client) });

  // Cotización completa del checkout (con envío, retiro y método de pago).
  const [pricing, setPricing] = useState<ShopPricing | null>(null);
  const [quoting, setQuoting] = useState(false);
  const qseq = useRef(0);
  const quoteKey = JSON.stringify([items, couponCodes, giftCardCodes, EMAIL_RE.test(email) ? email : '', pickup ? 'pickup' : address && { c: address.city, d: address.department, p: address.postalCode, n: address.daneCode }, shipping.selectedId, provider]);
  const quoteInput = useCallback(
    (over: { codes?: string[]; giftCardCodes?: string[] } = {}) => ({
      items,
      codes: over.codes ?? couponCodes,
      giftCardCodes: over.giftCardCodes ?? giftCardCodes,
      ...(EMAIL_RE.test(email) ? { customerEmail: email } : {}),
      ...(address && (address.city || address.postalCode || address.daneCode) ? { shippingAddress: { city: address.city, department: address.department, country: address.country, postalCode: address.postalCode, daneCode: address.daneCode } } : {}),
      ...(!pickup && shipping.selectedId ? { shippingOptionId: shipping.selectedId } : {}),
      ...(options.pickup.enabled ? { fulfillment: (pickup ? 'pickup' : 'shipping') as ShopFulfillment } : {}),
      ...(provider ? { paymentMethod: provider } : {}),
    }),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [quoteKey],
  );
  useEffect(() => {
    if (!client || !items.length) {
      setPricing(null);
      return;
    }
    const id = ++qseq.current;
    const t = setTimeout(async () => {
      setQuoting(true);
      try {
        const p = await client.quote(quoteInput());
        if (id === qseq.current) setPricing(p);
      } catch {
        // la cotización del carrito (si existe) sigue sirviendo de respaldo
      } finally {
        if (id === qseq.current) setQuoting(false);
      }
    }, opts.quoteDelayMs ?? 300);
    return () => clearTimeout(t);
  }, [client, quoteInput, items.length, opts.quoteDelayMs]);

  const amount = (pricing || cart?.pricing)?.amountDue;
  const methods = useMemo(() => {
    const list = paymentOptions(config, amount === undefined ? {} : { amount });
    // Contraentrega: la opción de envío elegida puede no admitirla.
    return shipping.selected && shipping.selected.codAllowed === false && !pickup ? list.map((m) => (m.id === 'cod' ? { ...m, available: false } : m)) : list;
  }, [config, amount, shipping.selected, pickup]);
  useEffect(() => {
    const cur = methods.find((m) => m.id === provider);
    if (!cur || !cur.available) {
      const first = methods.find((m) => m.available);
      if ((first?.id || '') !== provider) setProviderState(first?.id || '');
    }
  }, [methods, provider]);

  // Cupones y tarjetas: con carrito se guardan en él; sin carrito, aquí.
  const applyCoupon = useCallback(
    async (raw: string): Promise<CartCodeResult> => {
      if (cart) return cart.applyCoupon(raw);
      const code = normalizeCode(raw);
      if (!code) return { ok: false, message: ui.couponInvalid };
      if (!client) return { ok: false, message: ui.couponInvalid };
      try {
        const r = await client.validateDiscount(code, quoteInput());
        if (!r.valid) return { ok: false, message: r.message || ui.couponInvalid, reason: r.reason };
        setOwnCoupons((l) => (l.includes(code) ? l : [...l, code]));
        if (r.pricing) setPricing(r.pricing);
        return { ok: true, applied: r.applied, message: r.message };
      } catch (e) {
        return { ok: false, message: (e as Error)?.message || ui.couponInvalid };
      }
    },
    [cart, client, quoteInput, ui.couponInvalid],
  );
  const applyGiftCard = useCallback(
    async (raw: string): Promise<CartCodeResult> => {
      if (cart) return cart.applyGiftCard(raw);
      const code = normalizeCode(raw);
      if (!code || !client) return { ok: false, message: ui.giftCardInvalid };
      try {
        const p = await client.quote(quoteInput({ giftCardCodes: [...ownGifts, code] }));
        const bad = p.rejectedGiftCards.find((g) => codeEq(code, g.code));
        if (bad && bad.reason !== 'NOT_NEEDED') return { ok: false, message: bad.message || ui.giftCardInvalid, reason: bad.reason };
        setOwnGifts((l) => (l.includes(code) ? l : [...l, code]));
        setPricing(p);
        return { ok: true, applied: !bad };
      } catch (e) {
        return { ok: false, message: (e as Error)?.message || ui.giftCardInvalid };
      }
    },
    [cart, client, quoteInput, ownGifts, ui.giftCardInvalid],
  );
  const removeCoupon = useCallback((c: string) => (cart ? cart.removeCoupon(c) : setOwnCoupons((l) => l.filter((x) => x !== normalizeCode(c)))), [cart]);
  const removeGiftCard = useCallback((c: string) => (cart ? cart.removeGiftCard(c) : setOwnGifts((l) => l.filter((x) => x !== normalizeCode(c)))), [cart]);

  const [errors, setErrors] = useState<CheckoutErrors>({});
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<ShopCheckoutResult | null>(null);
  const [eventId, setEventId] = useState<string | null>(null);

  const effectivePricing = pricing || cart?.pricing || null;
  const validate = useCallback((): CheckoutErrors => {
    const e: CheckoutErrors = {};
    if (!items.length) e.items = ui.emptyCart;
    if (!form.customerName.trim()) e.customerName = ui.required;
    if (!EMAIL_RE.test(form.customerEmail.trim())) e.customerEmail = ui.invalidEmail;
    if (!form.customerPhone.trim()) e.customerPhone = ui.required;
    if (!pickup) {
      if (!form.address.trim()) e.address = ui.required;
      if (!form.city.trim() && !form.postalCode.trim()) e.city = ui.required;
      if (shipping.quote && !shipping.options.length) e.shipping = shipping.quote.message || ui.shippingUnavailable;
      else if (shipping.quote?.mode === 'zones' && !shipping.selectedId) e.shipping = ui.chooseShipping;
    } else if (!pickupLocationId && options.pickup.locations.length > 1) e.pickup = ui.choosePickupPoint;
    if (options.deliverySlots.enabled && options.deliverySlots.required && !(deliverySlot.date && deliverySlot.windowId)) e.deliverySlot = ui.chooseDeliverySlot;
    const m = methods.find((x) => x.id === provider);
    if (!m || !m.available) e.provider = ui.choosePaymentMethod;
    // Addi pide documento (igual que el checkout de /site).
    if (provider === 'addi' && !form.documentId.trim()) e.documentId = ui.required;
    if (effectivePricing?.belowMinimum && effectivePricing.minOrderAmount) e.pricing = `${ui.minOrderAmount} ${money(effectivePricing.minOrderAmount)}`;
    else if (effectivePricing?.purchaseLimitIssues?.length) e.pricing = `${ui.purchaseLimit} “${effectivePricing.purchaseLimitIssues[0].title}”`;
    setErrors(e);
    return e;
  }, [items.length, form, pickup, shipping.quote, shipping.options.length, shipping.selectedId, pickupLocationId, options, deliverySlot, methods, provider, effectivePricing, ui, money]);

  const submit = useCallback(
    async (ev?: { preventDefault?: () => void }): Promise<ShopCheckoutResult | null> => {
      ev?.preventDefault?.();
      if (!client || submitting) return null;
      const errs = validate();
      if (Object.keys(errs).length) return null;
      setSubmitting(true);
      setError(null);
      const id = newEventId('ck');
      setEventId(id);
      const loc = (globalThis as any).location;
      const redirectUrl = opts.redirectUrl ?? (loc ? `${loc.origin}${loc.pathname}` : undefined);
      const input: Omit<ShopCheckoutInput, 'items'> = {
        customerName: form.customerName.trim(),
        customerEmail: form.customerEmail.trim().toLowerCase(),
        customerPhone: form.customerPhone.trim(),
        ...(form.documentId.trim() ? { documentType: form.documentType, documentId: form.documentId.trim() } : {}),
        shippingAddress: {
          address: form.address.trim(),
          city: form.city.trim(),
          department: form.department.trim(),
          ...(form.country ? { country: form.country } : {}),
          ...(form.postalCode ? { postalCode: form.postalCode.trim() } : {}),
          ...(form.daneCode ? { daneCode: form.daneCode.trim() } : {}),
          notes: form.notes.trim(),
        },
        provider,
        ...(redirectUrl ? { redirectUrl } : {}),
        ...(!pickup && shipping.selected ? { shippingOptionId: shipping.selected.id, shippingAmount: shipping.selected.amount } : {}),
        ...checkoutExtrasBody(config, { fulfillment, pickupLocationId, deliverySlot }),
        tracking: trackingContext(id),
      };
      try {
        const res = cart
          ? await cart.checkout(input, opts.saveAddress === undefined ? undefined : { saveAddress: opts.saveAddress })
          : await client.checkout(
              { ...(input as ShopCheckoutInput), items, ...(couponCodes.length ? { couponCodes } : {}), ...(giftCardCodes.length ? { giftCardCodes } : {}) },
              opts.saveAddress === undefined ? undefined : { saveAddress: opts.saveAddress },
            );
        if (!cart) {
          setOwnCoupons([]);
          setOwnGifts([]);
        }
        setResult(res);
        const url = String(res.checkoutUrl || (res as any).paymentSession?.checkoutUrl || '');
        if (url && /^https:\/\//.test(url) && opts.autoRedirect !== false && loc && typeof loc.assign === 'function') loc.assign(url);
        return res;
      } catch (e) {
        const err = e as ShopError;
        if (err?.code === 'SHIPPING_AMOUNT_CHANGED' || err?.code === 'SHIPPING_OPTION_INVALID') {
          void shipping.refresh();
          setError(ui.shippingChanged);
        } else setError(err?.message || ui.checkoutError);
        return null;
      } finally {
        setSubmitting(false);
      }
    },
    [client, submitting, validate, opts.redirectUrl, opts.saveAddress, opts.autoRedirect, form, provider, pickup, shipping, config, fulfillment, pickupLocationId, deliverySlot, cart, items, couponCodes, giftCardCodes, ui],
  );

  const reset = useCallback(() => {
    setResult(null);
    setError(null);
    setErrors({});
    setEventId(null);
  }, []);

  const instructions = String((result as any)?.paymentSession?.instructions || '');
  return {
    form,
    setField,
    setForm,
    config,
    options,
    fulfillment: pickup ? 'pickup' : 'shipping',
    setFulfillment,
    pickupLocationId,
    setPickupLocation,
    deliverySlot,
    setDeliverySlot,
    shipping,
    paymentMethods: methods,
    provider,
    setProvider: setProviderState,
    reminderConsent,
    setReminderConsent,
    couponCodes,
    giftCardCodes,
    applyCoupon,
    removeCoupon,
    applyGiftCard,
    removeGiftCard,
    pricing: effectivePricing,
    quoting: quoting || Boolean(cart?.loading && !pricing),
    errors,
    validate,
    submitting,
    error,
    result,
    instructions,
    eventId,
    submit,
    reset,
    client,
  };
}

/* ------------------------------------------------------------------ */
/* Retorno de la pasarela                                              */
/* ------------------------------------------------------------------ */

export interface UsePaymentReturn {
  /** none: no hay pago pendiente en este navegador. */
  status: 'none' | 'checking' | 'paid' | 'failed' | 'pending' | 'error';
  result: ShopConfirmResult | null;
  error: ShopError | null;
  orderNumber: string | null;
  /** Nuevo intento de pago (pedido rechazado o pendiente): lleva a la pasarela salvo `redirect: false`. */
  retry(opts?: { email?: string; redirectUrl?: string; redirect?: boolean }): Promise<ShopRetryResult | null>;
  /** Vuelve a consultar el estado. */
  check(): Promise<ShopConfirmResult | null>;
}

/**
 * Página de retorno de Wompi, MercadoPago, Bold, Stripe o BNPL: lee la URL (`readPaymentReturn`),
 * confirma con el backend y sondea hasta que el pago deja de estar pendiente (`resumePayment`).
 * Emite `purchase` cuando el servidor responde PAID.
 */
export function usePaymentReturn(opts: ShopSourceOptions & { search?: string; intervalMs?: number; timeoutMs?: number; auto?: boolean } = {}): UsePaymentReturn {
  const client = useShopClient(opts);
  const [status, setStatus] = useState<UsePaymentReturn['status']>('none');
  const [result, setResult] = useState<ShopConfirmResult | null>(null);
  const [error, setError] = useState<ShopError | null>(null);
  const [orderNumber, setOrderNumber] = useState<string | null>(null);
  const check = useCallback(async () => {
    if (!client) return null;
    const pending = client.pendingPayment();
    if (!pending) {
      setStatus((s) => (s === 'none' || s === 'checking' ? 'none' : s));
      return null;
    }
    setOrderNumber(pending.orderNumber);
    setStatus('checking');
    try {
      const r = await client.resumePayment({ search: opts.search, intervalMs: opts.intervalMs, timeoutMs: opts.timeoutMs });
      setResult(r);
      setError(null);
      setStatus(!r ? 'none' : r.paymentStatus === 'PAID' ? 'paid' : r.paymentStatus === 'FAILED' ? 'failed' : 'pending');
      return r;
    } catch (e) {
      setError(e as ShopError);
      setStatus('error');
      return null;
    }
  }, [client, opts.search, opts.intervalMs, opts.timeoutMs]);
  useEffect(() => {
    if (opts.auto !== false) void check();
  }, [check, opts.auto]);
  const retry = useCallback(
    async (r: { email?: string; redirectUrl?: string; redirect?: boolean } = {}) => {
      const num = result?.orderNumber || orderNumber;
      if (!client || !num) return null;
      try {
        const res = await client.retryPayment(num, { email: r.email, redirectUrl: r.redirectUrl });
        const loc = (globalThis as any).location;
        if (r.redirect !== false && res.checkoutUrl && loc?.assign) loc.assign(res.checkoutUrl);
        return res;
      } catch (e) {
        setError(e as ShopError);
        return null;
      }
    },
    [client, result, orderNumber],
  );
  return { status, result, error, orderNumber: result?.orderNumber || orderNumber, retry, check };
}

/* ------------------------------------------------------------------ */
/* Componentes                                                         */
/* ------------------------------------------------------------------ */

export interface CmsPricingTotalsProps {
  pricing: ShopPricing | null | undefined;
  /** Respaldo sin cotización: subtotal y envío estimados. */
  subtotal?: number;
  shipping?: number;
  loading?: boolean;
  className?: string;
  labels?: Partial<ShopUi>;
}

/**
 * Resumen de totales sin estilos propios (`<dl data-cms-totals>`): descuentos, envío, impuestos
 * incluidos o agregados, tarjetas de regalo, total a pagar, pedido mínimo y límites por cliente.
 */
export function CmsPricingTotals({ pricing, subtotal = 0, shipping = 0, loading, className, labels }: CmsPricingTotalsProps) {
  const ui = useShopUi(labels);
  const money = useMoney(pricing ? { currency: pricing.currency, locale: pricing.locale } : undefined);
  const rows = pricing
    ? pricingRows(pricing, { labels: ui })
    : [
        { kind: 'subtotal', label: ui.subtotal, text: money(subtotal) },
        { kind: 'shipping', label: ui.shipping, text: shipping === 0 ? ui.shippingFree : money(shipping) },
        { kind: 'total', label: ui.total, text: money(subtotal + shipping) },
      ];
  return (
    <div className={className} data-cms-totals="" aria-busy={loading || undefined} aria-live="polite">
      <dl>
        {rows.map((r: any, i) => (
          <div key={`${r.kind}-${i}`} data-cms-total={r.kind} data-cms-inclusive={r.inclusive ? '' : undefined}>
            <dt>{r.label}</dt>
            <dd>
              {r.text}
              {r.was ? <s> {money(r.was)}</s> : null}
            </dd>
          </div>
        ))}
      </dl>
      {pricing?.belowMinimum && pricing.minOrderAmount ? (
        <p role="alert" data-cms-total-error="">
          {ui.minOrderAmount} {money(pricing.minOrderAmount)}.
        </p>
      ) : null}
      {(pricing?.purchaseLimitIssues || []).map((p) => (
        <p key={p.productId} role="alert" data-cms-total-error="">
          {ui.purchaseLimit} “{p.title}” ({p.limit}).
        </p>
      ))}
      <p data-cms-total-note="">{loading ? ui.updatingTotals : ui.pricesConfirmed}</p>
    </div>
  );
}

/**
 * Botón «Pedir por WhatsApp» del carrito: crea el pedido PENDING_WHATSAPP con los precios del
 * servidor y abre wa.me. Solo se pinta si la tienda lo activó (`globalData.site.whatsappOrders`).
 */
export function CmsWhatsAppOrderButton({ className, onError, keepCart, children }: { className?: string; onError?: (e: Error) => void; keepCart?: boolean; children?: React.ReactNode }) {
  const cms = useOptionalCms();
  const cart = useOptionalCart();
  const ui = useShopUi();
  const [busy, setBusy] = useState(false);
  const site = cms?.payload?.global?.site?.whatsappOrders;
  const enabled = site?.enabled === true && site?.cart !== false;
  if (!cart || !enabled || !cart.items.length) return null;
  return (
    <button
      type="button"
      className={className}
      data-cms-whatsapp-order=""
      disabled={busy}
      onClick={async () => {
        setBusy(true);
        try {
          const r = await cart.buildWhatsAppOrder({ keepCart });
          const loc = (globalThis as any).location;
          if (r.whatsappUrl && loc?.assign) loc.assign(r.whatsappUrl);
        } catch (e) {
          onError?.(e as Error);
        } finally {
          setBusy(false);
        }
      }}
    >
      {children ?? (busy ? ui.orderingByWhatsApp : ui.orderByWhatsApp)}
    </button>
  );
}
