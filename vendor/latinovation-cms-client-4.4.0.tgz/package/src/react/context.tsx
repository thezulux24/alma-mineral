'use client';

import { createContext, useContext } from 'react';
import type { CmsSectionRef, DeliveryPayload } from '../types.js';
import type { CanvasAction, LivePreviewBridge, NavChangeTarget, SectionTarget } from '../live.js';
import type { ArrayOp } from '../paths.js';
import type { SelectedElement } from '../dom.js';

export interface CmsActions {
  /** INLINE_FIELD_CHANGE con ruta con puntos (o INLINE_WIDGET_CHANGE para `widgets.<i>.<campo>`) + cambio local. */
  field(section: SectionTarget & { id: string }, path: string, value: unknown): void;
  /** ARRAY_ITEM_ACTION + cambio local (salvo `add`). */
  arrayItem(section: SectionTarget & { id: string }, path: string, index: number, op: ArrayOp): void;
  focusField(section: SectionTarget & { id: string }, path: string, type?: string): void;
  elementStyle(section: SectionTarget & { id: string }, elementId: string, patch: Record<string, unknown> | null): void;
  sectionStyle(section: SectionTarget & { id: string }, patch: Record<string, unknown>): void;
  global(fieldKey: string, value: unknown): void;
  nav(target: NavChangeTarget, value: unknown): void;
  item(collection: string, itemId: string, fieldKey: string, value: unknown): void;
}

export interface CmsContextValue {
  payload: DeliveryPayload;
  /** Dentro del iframe del portal con ?builder=1: edición en línea, toolbars y selección. */
  isBuilder: boolean;
  /** ?preview=1: muestra borradores (requiere previewToken válido). */
  isPreview: boolean;
  /** Página activa del CMS (la que fija <CmsPage> o la deducida de la ruta). */
  pageSlug: string;
  /** Slug del proyecto. */
  slug: string;
  /** URL del CMS (para medios relativos `/uploads/…`). */
  cmsUrl: string;
  /** Sección seleccionada en el editor. */
  selectedKey: string;
  selectedElement: SelectedElement | null;
  setSelectedElement(sel: SelectedElement | null): void;
  /** <CmsPage> registra su página para que el estado en vivo caiga en la correcta. */
  setActivePage(pageSlug: string): void;
  bridge: LivePreviewBridge | null;
  actions: CmsActions;
  // compatibilidad v4.0
  selectSection: (sectionKey: string, sectionId?: string) => void;
  commitField: (sectionKey: string, sectionId: string, fieldKey: string, value: unknown) => void;
  commitWidgetField: (sectionKey: string, sectionId: string, widgetIndex: number, fieldKey: string, value: unknown) => void;
  commitGlobal: (fieldKey: string, value: unknown) => void;
  post: (action: CanvasAction, payload?: Record<string, unknown>) => void;
}

export const CmsContext = createContext<CmsContextValue | null>(null);

export function useCms(): CmsContextValue {
  const ctx = useContext(CmsContext);
  if (!ctx) throw new Error('useCms debe usarse dentro de <CmsProvider>');
  return ctx;
}

/** Igual que useCms pero devuelve null fuera del provider. */
export function useOptionalCms(): CmsContextValue | null {
  return useContext(CmsContext);
}

export interface SectionScope {
  section: CmsSectionRef;
  index: number;
  total: number;
}

export const SectionContext = createContext<SectionScope | null>(null);

/** Sección que envuelve al componente (<CmsSection> / <CmsPage>), o null. */
export function useCurrentSection(): CmsSectionRef | null {
  return useContext(SectionContext)?.section || null;
}

/** Prefijo de ruta para campos dentro de un repetidor (<CmsList>). */
export const PathContext = createContext<string>('');

export interface ItemScope {
  collection: string;
  item: Record<string, any> & { id: string };
}

export const ItemContext = createContext<ItemScope | null>(null);
