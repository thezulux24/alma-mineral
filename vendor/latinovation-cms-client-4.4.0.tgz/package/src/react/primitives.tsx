'use client';

import React, { useContext } from 'react';
import type { CmsSectionRef, FieldType, LinkValue } from '../types.js';
import { mediaUrl } from '../delivery.js';
import { editAttrs, elementId } from '../attrs.js';
import { getPath, joinPath } from '../paths.js';
import { fieldSchema, galleryField, imageField, markdownToHtml, normalizeLink, resolveFieldType, safeHref, str } from '../fields.js';
import { PathContext, SectionContext, useCms, type CmsContextValue } from './context.js';

type SectionLike = Pick<CmsSectionRef, 'id' | 'key'> & { block?: string | null; data: Record<string, any> };

/** Ruta absoluta: relativa al repetidor actual; `/items.0.title` es absoluta. */
export function useFieldPath(f: string): string {
  const prefix = useContext(PathContext);
  if (f.startsWith('/')) return f.slice(1);
  return joinPath(prefix, f);
}

function useFieldSection(s?: SectionLike): SectionLike {
  const scope = useContext(SectionContext);
  const sec = s || scope?.section;
  if (!sec) throw new Error('Los campos del CMS necesitan una sección: pasa `s` o úsalos dentro de <CmsSection>/<CmsPage>.');
  return sec as SectionLike;
}

function placeholderFor(sec: SectionLike, path: string, explicit?: string): string {
  return explicit || fieldSchema(sec.block || sec.data?._block, path)?.label || 'Escribe aquí';
}

/** `data-el-id` estable para un elemento propio dentro de la sección actual: `<div {...useElementId('tarjeta')}>`. */
export function useElementId(name: string): { 'data-el-id': string } {
  const scope = useContext(SectionContext);
  const prefix = useContext(PathContext);
  const key = scope?.section.key || 'sec';
  return { 'data-el-id': elementId(key, prefix ? `${prefix}.${name}` : name) };
}

type Rest = Omit<React.HTMLAttributes<HTMLElement>, 'children'> & Record<string, any>;

export interface CmsTextProps extends Rest {
  /** Ruta del campo (`headline`, `cta.label`, `items.2.title`; relativa dentro de <CmsList>). */
  f: string;
  s?: SectionLike;
  /** Índice de widget (s.data.widgets[widget][f]) — compatibilidad v4.0. */
  widget?: number;
  as?: React.ElementType;
  fallback?: string;
  /** Permite saltos de línea (Enter no confirma). Por defecto true si as="p". */
  multiline?: boolean;
  placeholder?: string;
  /** false: no editable en línea (un clic abre el campo en el inspector). */
  editable?: boolean;
  /** Formato de presentación (p. ej. precio). Con formato el campo se edita desde el inspector. */
  format?: (value: unknown) => string;
}

/**
 * Texto de un campo de sección. Siempre emite `data-cms-field`/`data-cms-type`/`data-el-id`;
 * en el editor es contentEditable y al salir envía INLINE_FIELD_CHANGE con la ruta completa.
 */
export function CmsText({ f, s, widget, as: Tag = 'span', fallback = '', multiline, placeholder, editable = true, format, className, ...rest }: CmsTextProps) {
  const cms = useCms();
  const sec = useFieldSection(s);
  const rel = useFieldPath(f);
  const path = widget !== undefined ? `widgets.${widget}.${f}` : rel;
  const raw = getPath(sec.data, path);
  const value = format ? format(raw) : str(raw) || fallback;
  const allowNewlines = multiline ?? Tag === 'p';
  const inline = cms.isBuilder && editable && !format;
  if (!value && !cms.isBuilder) return null;
  const attrs = editAttrs({ field: path, type: allowNewlines ? 'textarea' : 'text', elId: elementId(sec.key, path) });
  return (
    <Tag
      key={inline ? `e:${value}` : undefined}
      {...rest}
      {...attrs}
      className={className}
      contentEditable={inline || undefined}
      suppressContentEditableWarning={inline || undefined}
      spellCheck={inline ? true : undefined}
      data-cms-multiline={allowNewlines ? '' : undefined}
      data-cms-empty={cms.isBuilder && !value ? 'true' : undefined}
      data-cms-placeholder={cms.isBuilder ? placeholderFor(sec, path, placeholder) : undefined}
      style={allowNewlines ? { whiteSpace: 'pre-line', ...(rest.style || {}) } : rest.style}
    >
      {value}
    </Tag>
  );
}

export interface CmsRichTextProps extends Rest {
  f: string;
  s?: SectionLike;
  as?: React.ElementType;
  placeholder?: string;
  /** Render propio del Markdown (por defecto el subconjunto seguro del CMS). */
  render?: (markdown: string) => string;
}

/** Markdown como HTML seguro. En el editor, un clic abre el campo en el inspector (FOCUS_FIELD richtext). */
export function CmsRichText({ f, s, as: Tag = 'div', placeholder, render = markdownToHtml, className, ...rest }: CmsRichTextProps) {
  const cms = useCms();
  const sec = useFieldSection(s);
  const path = useFieldPath(f);
  const md = str(getPath(sec.data, path));
  const attrs = editAttrs({ field: path, type: 'richtext', elId: elementId(sec.key, path) });
  if (!md) {
    if (!cms.isBuilder) return null;
    return (
      <Tag {...rest} {...attrs} className={[className, 'cms-ui-empty-text'].filter(Boolean).join(' ')}>
        {placeholderFor(sec, path, placeholder)}
      </Tag>
    );
  }
  return <Tag {...rest} {...attrs} className={className} dangerouslySetInnerHTML={{ __html: render(md) }} />;
}

export interface CmsImageProps extends Omit<React.ImgHTMLAttributes<HTMLImageElement>, 'src' | 'alt'> {
  f: string;
  s?: SectionLike;
  /** Texto alternativo si no hay `<campo>Alt`. */
  alt?: string;
  /** Componente de imagen propio (p. ej. `next/image`): recibe src, alt, style y los atributos de marcado. */
  as?: React.ElementType;
  priority?: boolean;
  /** Resolver URLs relativas (`/uploads/…`) contra el CMS. Por defecto true. */
  absolute?: boolean;
  emptyLabel?: string;
}

/** Imagen con compañeros `<campo>Alt` y `<campo>Focal` (§8.4). En el editor: "Cambiar imagen" → FOCUS_FIELD image. */
export function CmsImage({ f, s, alt, as: Img = 'img', priority, absolute = true, emptyLabel = 'Agregar imagen', style, className, ...rest }: CmsImageProps) {
  const cms = useCms();
  const sec = useFieldSection(s);
  const path = useFieldPath(f);
  const img = imageField(sec.data, path, alt || '');
  const attrs = editAttrs({ field: path, type: 'image', elId: elementId(sec.key, path) });
  if (!img.src) {
    if (!cms.isBuilder) return null;
    return (
      <span {...attrs} className={[className, 'cms-ui-empty-media'].filter(Boolean).join(' ')} style={style as React.CSSProperties}>
        {emptyLabel}
      </span>
    );
  }
  const src = absolute ? mediaUrl(img.src, cms.cmsUrl) : img.src;
  return (
    <Img
      loading={priority ? 'eager' : 'lazy'}
      decoding="async"
      {...(priority ? { fetchPriority: 'high' } : {})}
      {...rest}
      {...attrs}
      src={src}
      alt={img.alt}
      className={className}
      style={img.objectPosition ? { objectPosition: img.objectPosition, ...(style || {}) } : style}
    />
  );
}

export interface CmsGalleryProps extends Rest {
  f: string;
  s?: SectionLike;
  as?: React.ElementType;
  /** Render de cada imagen (por defecto `<img>`). */
  renderImage?: (img: { url: string; alt: string }, index: number) => React.ReactNode;
  imageClassName?: string;
}

/** Galería (lista de URLs). En el editor, un clic abre la mediateca (FOCUS_FIELD gallery). */
export function CmsGallery({ f, s, as: Tag = 'div', renderImage, imageClassName, className, ...rest }: CmsGalleryProps) {
  const cms = useCms();
  const sec = useFieldSection(s);
  const path = useFieldPath(f);
  const images = galleryField(getPath(sec.data, path));
  const attrs = editAttrs({ field: path, type: 'gallery', elId: elementId(sec.key, path) });
  if (!images.length && !cms.isBuilder) return null;
  return (
    <Tag {...rest} {...attrs} className={className}>
      {images.length ? (
        images.map((img, i) =>
          renderImage ? (
            <React.Fragment key={`${img.url}-${i}`}>{renderImage({ ...img, url: mediaUrl(img.url, cms.cmsUrl) }, i)}</React.Fragment>
          ) : (
            <img key={`${img.url}-${i}`} src={mediaUrl(img.url, cms.cmsUrl)} alt={img.alt} loading="lazy" decoding="async" className={imageClassName} />
          ),
        )
      ) : (
        <span className="cms-ui-empty-media">Agregar imágenes</span>
      )}
    </Tag>
  );
}

export interface CmsLinkProps extends Omit<React.AnchorHTMLAttributes<HTMLAnchorElement>, 'href'> {
  /** Campo `link` ({label, href, newTab}). */
  f?: string;
  /** Alternativa con campos planos: `labelField="ctaText" hrefField="ctaHref"`. */
  labelField?: string;
  hrefField?: string;
  s?: SectionLike;
  as?: React.ElementType;
  fallbackLabel?: string;
  /** Contenido propio en lugar de la etiqueta editable. */
  children?: React.ReactNode;
}

/** Enlace/botón. Etiqueta editable en línea; botón 🔗 en el editor → FOCUS_FIELD link (editor de enlace). */
export function CmsLink({ f, labelField, hrefField, s, as: A = 'a', fallbackLabel = '', children, className, target, rel, ...rest }: CmsLinkProps) {
  const cms = useCms();
  const sec = useFieldSection(s);
  const base = useFieldPath(f || '');
  const labelAbs = useFieldPath(labelField || '');
  const hrefAbs = useFieldPath(hrefField || '');
  const labelPath = labelField ? labelAbs : '';
  const hrefPath = hrefField ? hrefAbs : '';
  const flat = !f;
  const link: LinkValue = flat ? { label: str(getPath(sec.data, labelPath)), href: str(getPath(sec.data, hrefPath)) } : normalizeLink(getPath(sec.data, base));
  const label = link.label || fallbackLabel;
  const href = safeHref(link.href);
  if (!cms.isBuilder && !href && !(label || children)) return null;
  if (!cms.isBuilder && !label && !children) return null;
  const fieldPath = flat ? hrefPath || labelPath : base;
  const linkAttrs = editAttrs({ field: fieldPath, type: flat ? 'text' : 'link', elId: elementId(sec.key, fieldPath) });
  const ext = /^https?:/i.test(href);
  const newTab = link.newTab || target === '_blank';
  const lp = flat ? labelPath : `${base}.label`;
  return (
    <A
      {...rest}
      {...linkAttrs}
      href={href || (cms.isBuilder ? '#' : undefined)}
      target={newTab ? '_blank' : target}
      rel={newTab || ext ? rel || 'noopener noreferrer' : rel}
      className={className}
    >
      {children ?? (
        <span
          key={cms.isBuilder ? `e:${label}` : undefined}
          {...editAttrs({ field: lp || undefined, type: lp ? 'text' : undefined })}
          contentEditable={cms.isBuilder || undefined}
          suppressContentEditableWarning={cms.isBuilder || undefined}
          data-cms-empty={cms.isBuilder && !label ? 'true' : undefined}
          data-cms-placeholder={cms.isBuilder ? 'Texto del botón' : undefined}
        >
          {label}
        </span>
      )}
      {cms.isBuilder && fieldPath ? (
        <span className="cms-ui cms-ui-link-btn">
          <button
            type="button"
            title="Editar enlace"
            aria-label="Editar enlace"
            onClick={(e) => {
              e.preventDefault();
              e.stopPropagation();
              cms.actions.focusField({ key: sec.key, id: sec.id }, fieldPath, flat ? 'text' : 'link');
            }}
          >
            🔗
          </button>
        </span>
      ) : null}
    </A>
  );
}

export interface CmsListHelpers {
  /** Ruta del elemento (`items.2`). */
  path: string;
  index: number;
  isFirst: boolean;
  isLast: boolean;
  /** Atributos de marcado del elemento (si `wrap={false}`, espárcelos en tu raíz). */
  attrs: Record<string, string | undefined>;
  /** Mini barra del editor (si `wrap={false}`, renderízala dentro de tu raíz). */
  toolbar: React.ReactNode;
}

export interface CmsListProps<T = any> extends Rest {
  f: string;
  s?: SectionLike;
  as?: React.ElementType;
  itemAs?: React.ElementType;
  itemClassName?: string | ((item: T, index: number) => string | undefined);
  /** false: no envuelve cada elemento; usa `helpers.attrs` y `helpers.toolbar`. */
  wrap?: boolean;
  renderItem: (item: T, index: number, helpers: CmsListHelpers) => React.ReactNode;
  /** Contenido público cuando la lista está vacía (por defecto nada). */
  empty?: React.ReactNode;
  addLabel?: string;
  /** Máximo de elementos (oculta "agregar" al llegar). */
  max?: number;
}

/**
 * Repetidor (`items`, `plans`, `columns.0.links`…). Cada elemento lleva `data-cms-field="<ruta>.<i>"`
 * y, en el editor, mini barra agregar/duplicar/quitar/subir/bajar (ARRAY_ITEM_ACTION). Los campos
 * dentro de `renderItem` usan rutas relativas: `<CmsText f="title" />` → `items.2.title`.
 */
export function CmsList<T = any>({ f, s, as: Tag = 'div', itemAs: ItemTag = 'div', itemClassName, wrap = true, renderItem, empty = null, addLabel = 'Agregar elemento', max, className, ...rest }: CmsListProps<T>) {
  const cms = useCms();
  const sec = useFieldSection(s);
  const path = useFieldPath(f);
  const raw = getPath(sec.data, path);
  const list: T[] = Array.isArray(raw) ? raw : [];
  const target = { key: sec.key, id: sec.id };
  const op = (index: number, o: 'add' | 'duplicate' | 'remove' | 'move_up' | 'move_down') => cms.actions.arrayItem(target, path, index, o);
  const attrs = editAttrs({ field: path, type: 'array', elId: elementId(sec.key, path) });
  if (!list.length) {
    if (!cms.isBuilder) return empty ? <>{empty}</> : null;
    return (
      <Tag {...rest} {...attrs} className={className}>
        <div className="cms-ui cms-ui-list-empty">
          <button type="button" onClick={() => op(-1, 'add')}>
            {`+ ${addLabel}`}
          </button>
        </div>
      </Tag>
    );
  }
  const canAdd = max === undefined || list.length < max;
  return (
    <Tag {...rest} {...attrs} className={className}>
      {list.map((item, i) => {
        const itemPath = `${path}.${i}`;
        const itemAttrs = editAttrs({ field: itemPath, type: 'item', elId: elementId(sec.key, itemPath) });
        const toolbar = cms.isBuilder ? (
          <span className="cms-ui cms-ui-item-tools" role="toolbar" aria-label={`Elemento ${i + 1}`}>
            <button type="button" disabled={i === 0} onClick={() => op(i, 'move_up')} title="Subir" aria-label="Subir">
              ↑
            </button>
            <button type="button" disabled={i === list.length - 1} onClick={() => op(i, 'move_down')} title="Bajar" aria-label="Bajar">
              ↓
            </button>
            {canAdd ? (
              <button type="button" onClick={() => op(i, 'duplicate')} title="Duplicar" aria-label="Duplicar">
                ⧉
              </button>
            ) : null}
            {canAdd ? (
              <button type="button" onClick={() => op(i, 'add')} title="Agregar debajo" aria-label="Agregar debajo">
                +
              </button>
            ) : null}
            <button type="button" data-tone="danger" onClick={() => op(i, 'remove')} title="Quitar" aria-label="Quitar">
              ✕
            </button>
          </span>
        ) : null;
        const key = (item as any)?.id ?? i;
        const helpers: CmsListHelpers = { path: itemPath, index: i, isFirst: i === 0, isLast: i === list.length - 1, attrs: itemAttrs, toolbar };
        const content = renderItem(item, i, helpers);
        const cls = typeof itemClassName === 'function' ? itemClassName(item, i) : itemClassName;
        return (
          <PathContext.Provider key={key} value={itemPath}>
            {wrap ? (
              <ItemTag {...itemAttrs} className={cls}>
                {toolbar}
                {content}
              </ItemTag>
            ) : (
              content
            )}
          </PathContext.Provider>
        );
      })}
    </Tag>
  );
}

export interface CmsFieldProps extends Rest {
  f: string;
  s?: SectionLike;
  /** Tipo explícito; si falta, el del catálogo del bloque o el inferido del valor. */
  type?: FieldType;
  as?: React.ElementType;
}

/** Despacha al primitivo según el tipo del campo (text/textarea/richtext/image/gallery/link; el resto se muestra como texto y abre el inspector). */
export function CmsField({ f, s, type, as, ...rest }: CmsFieldProps) {
  const cms = useCms();
  const sec = useFieldSection(s);
  const path = useFieldPath(f);
  const value = getPath(sec.data, path);
  const t = type || resolveFieldType(sec.block || sec.data?._block, path, value);
  switch (t) {
    case 'richtext':
      return <CmsRichText f={'/' + path} s={sec} as={as} {...rest} />;
    case 'image':
      return <CmsImage f={'/' + path} s={sec} as={as} {...(rest as any)} />;
    case 'gallery':
      return <CmsGallery f={'/' + path} s={sec} as={as} {...rest} />;
    case 'link':
      return <CmsLink f={'/' + path} s={sec} as={as} {...(rest as any)} />;
    case 'text':
    case 'textarea':
      return <CmsText f={'/' + path} s={sec} as={as} multiline={t === 'textarea'} {...rest} />;
    default: {
      const Tag = as || 'span';
      const shown = typeof value === 'boolean' ? (value ? 'Sí' : 'No') : str(value);
      if (!shown && !cms.isBuilder) return null;
      return (
        <Tag {...rest} {...editAttrs({ field: path, type: t, elId: elementId(sec.key, path) })}>
          {shown}
        </Tag>
      );
    }
  }
}

/** Contenedor que respeta `_style.contentWidth`/`maxWidth` de la sección (`data-cms-container`). */
export function CmsContainer({ as: Tag = 'div', children, ...rest }: Rest & { as?: React.ElementType; children?: React.ReactNode }) {
  return (
    <Tag data-cms-container="" {...rest}>
      {children}
    </Tag>
  );
}

export type { CmsContextValue };
