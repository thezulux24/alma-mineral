'use client';

import React, { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import { createShopClient, type ShopAuthResult, type ShopClient, type ShopClientOptions, type ShopCustomer, type ShopError, type ShopRegisterInput } from '../shop.js';

export interface ShopAccountValue {
  /** Cliente con sesión, o null si no hay (o se venció). */
  customer: ShopCustomer | null;
  /** true mientras se valida el token guardado (también en el primer render, para que SSR e hidratación coincidan). */
  loading: boolean;
  /** Último error de refresh() (los de login/register se lanzan al llamador). */
  error: ShopError | null;
  login(input: { email: string; password: string }): Promise<ShopCustomer>;
  register(input: ShopRegisterInput): Promise<ShopAuthResult & { claimedOrders: string[] }>;
  /** Cierra la sesión en este navegador. */
  logout(): void;
  /** Vuelve a leer /me (p. ej. tras editar el perfil o las direcciones). */
  refresh(): Promise<ShopCustomer | null>;
  client: ShopClient;
}

const ShopAccountContext = createContext<ShopAccountValue | null>(null);

export type ShopAccountProviderProps = { children?: React.ReactNode } & (
  | { client: ShopClient; slug?: never; apiUrl?: never; storage?: never; fetch?: never }
  | ({ client?: undefined } & ShopClientOptions)
);

/**
 * Sesión de cliente de la tienda para storefronts React / Next.js ('use client').
 *
 *   <ShopAccountProvider slug="arsenal">{children}</ShopAccountProvider>
 *   const { customer, loading, login, logout } = useShopAccount();
 */
export function ShopAccountProvider(props: ShopAccountProviderProps) {
  const { children } = props;
  const external = props.client;
  const slug = external ? external.slug : props.slug;
  const apiUrl = external ? undefined : props.apiUrl;
  const optsRef = useRef(props);
  optsRef.current = props;
  const client = useMemo<ShopClient>(() => {
    if (external) return external;
    const p = optsRef.current as ShopClientOptions;
    return createShopClient({ slug: p.slug, apiUrl: p.apiUrl, storage: p.storage, fetch: p.fetch });
  }, [external, slug, apiUrl]);

  const [customer, setCustomer] = useState<ShopCustomer | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<ShopError | null>(null);
  const seq = useRef(0);

  const refresh = useCallback(async (): Promise<ShopCustomer | null> => {
    const id = ++seq.current;
    if (!client.getToken()) {
      setCustomer(null);
      setLoading(false);
      return null;
    }
    setLoading(true);
    try {
      const me = await client.account.me();
      if (id === seq.current) {
        setCustomer(me);
        setError(null);
      }
      return me;
    } catch (e) {
      if (id === seq.current) {
        // 401: el cliente ya olvidó el token; cualquier otro error deja la sesión sin datos por ahora.
        setCustomer(null);
        setError(e as ShopError);
      }
      return null;
    } finally {
      if (id === seq.current) setLoading(false);
    }
  }, [client]);

  useEffect(() => {
    void refresh();
    return client.onTokenChange((token) => {
      if (!token) {
        seq.current++;
        setCustomer(null);
        setLoading(false);
      }
    });
  }, [client, refresh]);

  const login = useCallback(
    async (input: { email: string; password: string }) => {
      const res = await client.account.login(input);
      seq.current++;
      setCustomer(res.customer);
      setError(null);
      setLoading(false);
      return res.customer;
    },
    [client],
  );

  const register = useCallback(
    async (input: ShopRegisterInput) => {
      const res = await client.account.register(input);
      seq.current++;
      setCustomer(res.customer);
      setError(null);
      setLoading(false);
      return res;
    },
    [client],
  );

  const logout = useCallback(() => client.account.logout(), [client]);

  const value = useMemo<ShopAccountValue>(() => ({ customer, loading, error, login, register, logout, refresh, client }), [customer, loading, error, login, register, logout, refresh, client]);
  return <ShopAccountContext.Provider value={value}>{children}</ShopAccountContext.Provider>;
}

/** Sesión del cliente de la tienda. Requiere <ShopAccountProvider>. */
export function useShopAccount(): ShopAccountValue {
  const ctx = useContext(ShopAccountContext);
  if (!ctx) throw new Error('useShopAccount() requiere <ShopAccountProvider slug="…"> más arriba en el árbol.');
  return ctx;
}

/** Igual que useShopAccount() pero devuelve null fuera del provider. */
export function useOptionalShopAccount(): ShopAccountValue | null {
  return useContext(ShopAccountContext);
}
