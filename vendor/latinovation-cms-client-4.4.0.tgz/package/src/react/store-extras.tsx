'use client';

/**
 * Reseñas, favoritos, avisos de stock, relacionados y vistos recientemente para storefronts React
 * (docs/REVIEWS-AND-CHANNELS.md). Funcionan dentro de <CmsProvider> (toman slug y URL del CMS) y,
 * si hay <ShopAccountProvider>, usan la cuenta del cliente para los favoritos.
 *
 *   const { items, summary, submit } = useReviews(product.id);
 *   <CmsRatingStars value={product.ratingAverage} count={product.ratingCount} />
 *   <CmsReviews productId={product.id} />
 *   const wl = useWishlist(); wl.toggle(product.id)
 *   const { subscribe } = useBackInStock(product.id)
 *   const recent = useRecentlyViewed(product.id)
 *
 * Los rótulos salen de `global.ui` (los mismos que el renderer de /site; se editan en
 * Tienda › Más opciones › Textos) con respaldo en español neutro, o de la prop `labels`.
 */
import React, { useCallback, useEffect, useId, useMemo, useRef, useState } from 'react';
import { createStoreExtrasClient, readReviewInvite, relatedProducts, type PublicReview, type ReviewInput, type ReviewsPage, type StoreExtrasClient } from '../store-extras.js';
import { useShopUi } from './ui.js';
import type { CollectionItem } from '../types.js';
import { getGlobal, getStoreCollectionSlug } from '../delivery.js';
import { useOptionalCms } from './context.js';
import { useOptionalShopAccount } from './shop.js';

/**
 * Rótulos de reseñas (subconjunto de `SHOP_UI`).
 * @deprecated Desde 4.4: usa `SHOP_UI` / `useShopUi()`, que cubren toda la tienda con las mismas claves.
 */
export const REVIEW_LABELS = {
  reviewsCount: '{n} opiniones',
  ratingOutOf: '{n} de 5 estrellas',
  noReviews: 'Todavía no hay opiniones. Sé la primera persona en contar cómo le fue.',
  verifiedPurchase: 'Compra verificada',
  storeReply: 'Respuesta de la tienda',
  moreReviews: 'Ver más opiniones',
  yourRating: 'Tu calificación',
  reviewTitle: 'Título (opcional)',
  reviewBody: 'Tu opinión',
  reviewName: 'Nombre que se publica',
  reviewEmail: 'Correo (no se publica)',
  reviewSubmit: 'Publicar opinión',
  reviewThanks: 'Gracias. Publicaremos tu opinión después de revisarla.',
  reviewPublished: '¡Gracias! Tu opinión ya está publicada.',
  reviewError: 'No pudimos enviar tu opinión. Revisa los datos e inténtalo de nuevo.',
  sending: 'Enviando…',
  loading: 'Cargando…',
};
export type ReviewLabels = typeof REVIEW_LABELS;

const fill = (tpl: string, n: string | number) => String(tpl).replace('{n}', String(n));
const fmt = (n: number) => (Math.round(n * 10) / 10).toLocaleString('es-CO', { minimumFractionDigits: 1, maximumFractionDigits: 1 });

/** Cliente de extras ligado al <CmsProvider> (slug + URL) y a la sesión de la tienda si existe. */
export function useStoreExtras(opts: { slug?: string; apiUrl?: string } = {}): StoreExtrasClient | null {
  const cms = useOptionalCms();
  const account = useOptionalShopAccount();
  const slug = opts.slug || cms?.slug || account?.client.slug;
  const apiUrl = opts.apiUrl || cms?.cmsUrl || account?.client.apiUrl;
  const tokenRef = useRef(account?.client);
  tokenRef.current = account?.client;
  return useMemo(() => (slug ? createStoreExtrasClient({ slug, apiUrl, getToken: () => tokenRef.current?.getToken() || null }) : null), [slug, apiUrl]);
}

/** Rótulos: `labels` > global.ui del sitio > valores por defecto. */
export function useReviewLabels(labels?: Partial<ReviewLabels>): ReviewLabels {
  const cms = useOptionalCms();
  const ui = (cms ? getGlobal<Record<string, string>>(cms.payload, 'ui', {}) : {}) || {};
  return useMemo(() => {
    const out: Record<string, string> = { ...REVIEW_LABELS };
    for (const k of Object.keys(REVIEW_LABELS)) if (typeof ui[k] === 'string' && ui[k].trim()) out[k] = ui[k];
    return { ...(out as ReviewLabels), ...(labels || {}) };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [JSON.stringify(ui), JSON.stringify(labels || {})]);
}

export interface UseReviews {
  items: PublicReview[];
  summary: ReviewsPage['summary'] | null;
  total: number;
  loading: boolean;
  error: Error | null;
  hasMore: boolean;
  loadMore(): void;
  reload(): void;
  /** Envía la reseña (con `photos`: ids de `uploadPhoto`; con `token`: compra verificada del correo). */
  submit(input: Omit<ReviewInput, 'productId'> & { productId?: string }): Promise<{ status: string; message: string }>;
  /** Sube una foto (máx. 6 MB; se convierte a WebP) y devuelve su id para `submit({ photos })`. */
  uploadPhoto(file: Blob, fileName?: string): Promise<{ id: string; url: string }>;
}

/** Reseñas aprobadas de un producto (o de toda la tienda con `null`), paginadas. */
export function useReviews(productId: string | null | undefined, opts: { pageSize?: number; sort?: 'highest' | 'lowest' | 'photos'; client?: StoreExtrasClient } = {}): UseReviews {
  const own = useStoreExtras();
  const client = opts.client || own;
  const [page, setPage] = useState(1);
  const [items, setItems] = useState<PublicReview[]>([]);
  const [data, setData] = useState<ReviewsPage | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<Error | null>(null);
  const [version, setVersion] = useState(0);
  useEffect(() => setPage(1), [productId, opts.sort, version]);
  useEffect(() => {
    if (!client) return;
    let alive = true;
    setLoading(true);
    client.reviews
      .list(productId || null, { page, limit: opts.pageSize || 6, sort: opts.sort })
      .then((r) => {
        if (!alive) return;
        setData(r);
        setItems((prev) => (page === 1 ? r.items : [...prev, ...r.items.filter((x) => !prev.some((p) => p.id === x.id))]));
        setError(null);
      })
      .catch((e) => alive && setError(e))
      .finally(() => alive && setLoading(false));
    return () => {
      alive = false;
    };
  }, [client, productId, page, opts.pageSize, opts.sort, version]);
  const submit = useCallback(
    async (input: Omit<ReviewInput, 'productId'> & { productId?: string }) => {
      if (!client) throw new Error('useReviews necesita <CmsProvider> o un client');
      const r = await client.reviews.submit({ ...input, productId: input.productId || productId || undefined });
      if (r.status === 'APPROVED') setVersion((v) => v + 1);
      return r;
    },
    [client, productId],
  );
  return {
    items,
    summary: data?.summary || null,
    total: data?.total || 0,
    loading,
    error,
    hasMore: Boolean(data && page < data.totalPages),
    loadMore: () => setPage((p) => p + 1),
    reload: () => setVersion((v) => v + 1),
    submit,
    uploadPhoto: (file: Blob, fileName?: string) => {
      if (!client) return Promise.reject(new Error('useReviews necesita <CmsProvider> o un client'));
      return client.reviews.uploadPhoto(file, fileName);
    },
  };
}

/**
 * Enlace del correo «Califica tu compra» (`?resena=<token>&estrellas=N`): datos del producto para
 * prellenar el formulario. `token` va en `submit({ token })` y marca la compra como verificada.
 */
export function useReviewInvite(opts: { search?: string; client?: StoreExtrasClient } = {}) {
  const own = useStoreExtras();
  const client = opts.client || own;
  const [invite, setInvite] = useState<{ token: string; stars: number } | null>(null);
  const [data, setData] = useState<Awaited<ReturnType<StoreExtrasClient['reviews']['invite']>> | null>(null);
  const [error, setError] = useState<Error | null>(null);
  useEffect(() => {
    const inv = readReviewInvite(opts.search);
    setInvite(inv);
    if (!inv || !client) return;
    let alive = true;
    client.reviews
      .invite(inv.token)
      .then((r) => alive && setData(r))
      .catch((e) => alive && setError(e));
    return () => {
      alive = false;
    };
  }, [client, opts.search]);
  return { token: invite?.token || null, stars: invite?.stars || 0, product: data?.product || null, name: data?.name || '', alreadyReviewed: Boolean(data?.alreadyReviewed), error };
}

/** Promedio y conteo de reseñas de varios productos (tarjetas que no vienen del delivery). */
export function useReviewSummaries(productIds: string[], opts: { client?: StoreExtrasClient } = {}) {
  const own = useStoreExtras();
  const client = opts.client || own;
  const key = [...new Set(productIds.filter(Boolean))].sort().join(',');
  const [map, setMap] = useState<Record<string, { average: number; count: number }>>({});
  useEffect(() => {
    if (!client || !key) return;
    let alive = true;
    client.reviews
      .summaries(key.split(','))
      .then((r) => alive && setMap(r || {}))
      .catch(() => undefined);
    return () => {
      alive = false;
    };
  }, [client, key]);
  return map;
}

/** Estrellas con relleno parcial (accesibles: role=img + aria-label). Colores con --cms-*. */
export function CmsRatingStars({ value, count, size = 16, label, className, showValue }: { value: number | null | undefined; count?: number; size?: number; label?: string; className?: string; showValue?: boolean }) {
  const labels = useReviewLabels();
  const v = Math.max(0, Math.min(5, Number(value) || 0));
  const pct = `${(v / 5) * 100}%`;
  return (
    <span className={className} data-cms-rating={fmt(v)} style={{ display: 'inline-flex', alignItems: 'center', gap: '0.35em', lineHeight: 1 }}>
      <span role="img" aria-label={label || fill(labels.ratingOutOf, fmt(v))} style={{ position: 'relative', display: 'inline-block', fontSize: size, letterSpacing: '0.08em' }}>
        <span aria-hidden="true" style={{ color: 'color-mix(in oklab, var(--cms-color-text, currentColor) 18%, transparent)' }}>★★★★★</span>
        <span aria-hidden="true" style={{ position: 'absolute', inset: 0, width: pct, overflow: 'hidden', whiteSpace: 'nowrap', color: 'var(--cms-color-accent, var(--cms-color-primary, #B7791F))' }}>★★★★★</span>
      </span>
      {showValue ? <span style={{ fontWeight: 600 }}>{fmt(v)}</span> : null}
      {count !== undefined ? <span style={{ opacity: 0.7 }}>({count})</span> : null}
    </span>
  );
}

function ReviewFormInline({
  onSubmit,
  onUpload,
  labels,
  token,
  initialRating = 0,
  maxPhotos = 0,
  photosLabel,
}: {
  onSubmit: UseReviews['submit'];
  onUpload?: UseReviews['uploadPhoto'];
  labels: ReviewLabels;
  token?: string;
  initialRating?: number;
  maxPhotos?: number;
  photosLabel?: string;
}) {
  const id = useId();
  const [rating, setRating] = useState(initialRating);
  useEffect(() => {
    if (initialRating) setRating(initialRating);
  }, [initialRating]);
  const [f, setF] = useState({ title: '', body: '', name: '', email: '', website: '' });
  const [photos, setPhotos] = useState<Array<{ id: string; url: string }>>([]);
  const [state, setState] = useState<{ busy?: boolean; done?: string; error?: string }>({});
  if (state.done) return <p role="status" data-cms-review-done="">{state.done}</p>;
  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => setF({ ...f, [k]: e.target.value });
  return (
    <form
      data-cms-review-form=""
      onSubmit={async (e) => {
        e.preventDefault();
        setState({ busy: true });
        try {
          const r = await onSubmit({ ...f, rating, token, ...(photos.length ? { photos: photos.map((p) => p.id) } : {}) });
          setState({ done: r.status === 'APPROVED' ? labels.reviewPublished : labels.reviewThanks });
        } catch (err: any) {
          setState({ error: err?.message || labels.reviewError });
        }
      }}
    >
      <fieldset>
        <legend>{labels.yourRating}</legend>
        {[1, 2, 3, 4, 5].map((n) => (
          <label key={n}>
            <input type="radio" name={`${id}-r`} value={n} checked={rating === n} onChange={() => setRating(n)} required />
            <span aria-hidden="true">{n <= rating ? '★' : '☆'}</span>
            <span style={{ position: 'absolute', width: 1, height: 1, overflow: 'hidden', clip: 'rect(0 0 0 0)' }}>{fill(labels.ratingOutOf, n)}</span>
          </label>
        ))}
      </fieldset>
      <label htmlFor={`${id}-t`}>{labels.reviewTitle}</label>
      <input id={`${id}-t`} maxLength={120} value={f.title} onChange={set('title')} />
      <label htmlFor={`${id}-b`}>{labels.reviewBody}</label>
      <textarea id={`${id}-b`} required minLength={10} maxLength={4000} value={f.body} onChange={set('body')} />
      <label htmlFor={`${id}-n`}>{labels.reviewName}</label>
      <input id={`${id}-n`} required minLength={2} maxLength={80} value={f.name} onChange={set('name')} />
      {token ? null : (
        <>
          <label htmlFor={`${id}-e`}>{labels.reviewEmail}</label>
          <input id={`${id}-e`} type="email" required value={f.email} onChange={set('email')} />
        </>
      )}
      {onUpload && maxPhotos > 0 ? (
        <div data-cms-review-photos="">
          <label htmlFor={`${id}-p`}>{photosLabel}</label>
          <input
            id={`${id}-p`}
            type="file"
            accept="image/*"
            multiple
            disabled={photos.length >= maxPhotos || state.busy}
            onChange={async (e) => {
              const files = Array.from(e.target.files || []).slice(0, Math.max(0, maxPhotos - photos.length));
              e.target.value = '';
              for (const file of files) {
                try {
                  const up = await onUpload(file, (file as File).name || 'foto.jpg');
                  setPhotos((l) => [...l, up].slice(0, maxPhotos));
                } catch (err: any) {
                  setState({ error: err?.message || labels.reviewError });
                }
              }
            }}
          />
          {photos.map((p) => (
            <img key={p.id} src={p.url} alt="" width={56} height={56} loading="lazy" />
          ))}
        </div>
      ) : null}
      <input aria-hidden="true" tabIndex={-1} autoComplete="off" value={f.website} onChange={set('website')} style={{ position: 'absolute', left: -10000, width: 1, height: 1 }} />
      {state.error ? <p role="alert">{state.error}</p> : null}
      <button type="submit" disabled={state.busy}>
        {state.busy ? labels.sending : labels.reviewSubmit}
      </button>
    </form>
  );
}

export interface CmsReviewsProps {
  productId: string | null;
  pageSize?: number;
  showForm?: boolean;
  showSummary?: boolean;
  labels?: Partial<ReviewLabels>;
  className?: string;
  /** Pinta cada reseña a tu manera (por defecto, un <article> sencillo con las clases data-cms-review). */
  renderReview?: (r: PublicReview, labels: ReviewLabels) => React.ReactNode;
  /** Fotos en el formulario (máximo por reseña; 0 = sin fotos). Usa `storeExtras.reviews.maxPhotos`. */
  maxPhotos?: number;
  /** v4.4: lee `?resena=<token>&estrellas=N` del correo y prellena (por defecto true). */
  invite?: boolean;
  sort?: 'highest' | 'lowest' | 'photos';
}

/** Lista + resumen + formulario sin estilos propios (atributos data-cms-review-* para tu CSS). */
export function CmsReviews({ productId, pageSize = 6, showForm = true, showSummary = true, labels: overrides, className, renderReview, maxPhotos = 0, invite = true, sort }: CmsReviewsProps) {
  const labels = useReviewLabels(overrides);
  const ui = useShopUi();
  const r = useReviews(productId, { pageSize, sort });
  const inv = useReviewInvite({ search: invite ? undefined : '' });
  return (
    <section className={className} data-cms-reviews="">
      {showSummary && r.summary && r.summary.count > 0 ? (
        <div data-cms-review-summary="">
          <CmsRatingStars value={r.summary.average} showValue />
          <span>{fill(labels.reviewsCount, r.summary.count)}</span>
        </div>
      ) : null}
      {r.items.length ? (
        <ul data-cms-review-list="">
          {r.items.map((it) => (
            <li key={it.id}>
              {renderReview ? (
                renderReview(it, labels)
              ) : (
                <article data-cms-review="">
                  <CmsRatingStars value={it.rating} />
                  {it.verifiedPurchase ? <span data-cms-review-verified="">{labels.verifiedPurchase}</span> : null}
                  {it.title ? <h3>{it.title}</h3> : null}
                  <p>{it.body}</p>
                  {it.photos.map((p) => (
                    <img key={p.url} src={p.url} alt={p.alt} loading="lazy" width={72} height={72} />
                  ))}
                  <footer>{it.name}</footer>
                  {it.reply ? (
                    <blockquote data-cms-review-reply="">
                      <strong>{labels.storeReply}</strong> {it.reply}
                    </blockquote>
                  ) : null}
                </article>
              )}
            </li>
          ))}
        </ul>
      ) : r.loading ? (
        <p aria-busy="true">{labels.loading}</p>
      ) : (
        <p data-cms-review-empty="">{labels.noReviews}</p>
      )}
      {r.hasMore ? (
        <button type="button" onClick={r.loadMore} disabled={r.loading}>
          {labels.moreReviews}
        </button>
      ) : null}
      {showForm && productId ? (
        <ReviewFormInline
          onSubmit={r.submit}
          onUpload={r.uploadPhoto}
          labels={labels}
          token={inv.token && !inv.alreadyReviewed ? inv.token : undefined}
          initialRating={inv.stars}
          maxPhotos={maxPhotos}
          photosLabel={ui.reviewPhotos}
        />
      ) : null}
    </section>
  );
}

/** Favoritos: con sesión de cliente se guardan en la cuenta (y se suben los del navegador); sin sesión, en este navegador. */
export function useWishlist(opts: { client?: StoreExtrasClient } = {}) {
  const own = useStoreExtras();
  const client = opts.client || own;
  const account = useOptionalShopAccount();
  const customerId = account?.customer?.id || null;
  const [ids, setIds] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);
  useEffect(() => {
    if (!client) return;
    if (!customerId) {
      setIds(client.wishlist.local());
      return;
    }
    let alive = true;
    setLoading(true);
    const local = client.wishlist.local();
    (local.length ? client.wishlist.merge(local) : client.wishlist.list())
      .then((r) => {
        if (!alive) return;
        setIds(r.productIds);
        client.wishlist.setLocal([]);
      })
      .catch(() => alive && setIds(client.wishlist.local()))
      .finally(() => alive && setLoading(false));
    return () => {
      alive = false;
    };
  }, [client, customerId]);
  const toggle = useCallback(
    async (productId: string) => {
      if (!client) return false;
      const on = ids.includes(productId);
      if (!customerId) {
        const now = client.wishlist.toggleLocal(productId);
        setIds(client.wishlist.local());
        return now;
      }
      setIds((prev) => (on ? prev.filter((x) => x !== productId) : [productId, ...prev]));
      try {
        const r = on ? await client.wishlist.remove(productId) : await client.wishlist.add(productId);
        setIds(r.productIds);
      } catch {
        setIds((prev) => (on ? [productId, ...prev] : prev.filter((x) => x !== productId)));
      }
      return !on;
    },
    [client, customerId, ids],
  );
  return { ids, loading, has: (id: string) => ids.includes(id), toggle, synced: Boolean(customerId) };
}

/** "Avísame cuando llegue" de un producto (o variante) agotado. */
export function useBackInStock(productId: string, opts: { client?: StoreExtrasClient } = {}) {
  const own = useStoreExtras();
  const client = opts.client || own;
  const [status, setStatus] = useState<'idle' | 'sending' | 'done' | 'error'>('idle');
  const [error, setError] = useState<string | null>(null);
  const subscribe = useCallback(
    async (email: string, variant?: string) => {
      if (!client) return false;
      setStatus('sending');
      setError(null);
      try {
        await client.backInStock.subscribe({ productId, email, variant });
        setStatus('done');
        return true;
      } catch (e: any) {
        setStatus('error');
        setError(e?.message || 'No pudimos registrar el aviso');
        return false;
      }
    },
    [client, productId],
  );
  return { subscribe, status, error };
}

/** Vistos recientemente (en este navegador). Pasa el producto actual para registrarlo. */
export function useRecentlyViewed(currentId?: string | null, opts: { max?: number; client?: StoreExtrasClient } = {}) {
  const own = useStoreExtras();
  const client = opts.client || own;
  const [ids, setIds] = useState<string[]>([]);
  useEffect(() => {
    if (!client) return;
    setIds(currentId ? client.recentlyViewed.add(currentId, opts.max || 12) : client.recentlyViewed.list());
  }, [client, currentId, opts.max]);
  return { ids: currentId ? ids.filter((x) => x !== currentId) : ids, clear: () => (client?.recentlyViewed.clear(), setIds([])) };
}

/** Productos relacionados del payload en vivo (relación manual `related` y misma categoría). */
export function useRelatedProducts<T extends CollectionItem = CollectionItem>(item: T | null | undefined, opts: { collection?: string; count?: number } = {}): T[] {
  const cms = useOptionalCms();
  return useMemo(() => {
    if (!cms || !item) return [];
    const col = opts.collection || getStoreCollectionSlug(cms.payload);
    const list = ((col && (cms.payload.collections as any)?.[col]) || []) as T[];
    return relatedProducts(item as any, list as any[], opts.count ?? 4) as T[];
  }, [cms, item, opts.collection, opts.count]);
}

/**
 * Corazón de favoritos (aria-pressed). Textos de `global.ui` (addToWishlist / removeFromWishlist).
 * Pasa `wishlist` (de useWishlist) si pintas muchos: comparten una sola lista.
 */
export function CmsWishlistButton({
  productId,
  wishlist,
  className,
  children,
}: {
  productId: string;
  wishlist?: ReturnType<typeof useWishlist>;
  className?: string;
  /** Contenido propio (p. ej. un ícono); recibe si está guardado. */
  children?: (saved: boolean) => React.ReactNode;
}) {
  const own = useWishlist();
  const wl = wishlist || own;
  const ui = useShopUi();
  const saved = wl.has(productId);
  const label = saved ? ui.removeFromWishlist : ui.addToWishlist;
  return (
    <button type="button" className={className} aria-pressed={saved} aria-label={label} title={label} data-cms-wishlist={saved ? 'on' : 'off'} onClick={() => void wl.toggle(productId)}>
      {children ? children(saved) : <span aria-hidden="true">{saved ? '♥' : '♡'}</span>}
    </button>
  );
}

/** «Avísame cuando llegue» para un producto o variante agotado (correo + trampa para bots). */
export function CmsBackInStockForm({ productId, variant, className }: { productId: string; variant?: string; className?: string }) {
  const { subscribe, status, error } = useBackInStock(productId);
  const ui = useShopUi();
  const id = useId();
  const [email, setEmail] = useState('');
  if (status === 'done') return <p role="status" data-cms-back-in-stock-done="">{ui.notifyMeDone}</p>;
  return (
    <form
      className={className}
      data-cms-back-in-stock=""
      onSubmit={(e) => {
        e.preventDefault();
        void subscribe(email.trim(), variant);
      }}
    >
      <p>{ui.notifyMeHelp}</p>
      <label htmlFor={`${id}-e`}>{ui.email}</label>
      <input id={`${id}-e`} type="email" required autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} />
      {error ? <p role="alert">{error}</p> : null}
      <button type="submit" disabled={status === 'sending'}>
        {status === 'sending' ? ui.sending : ui.notifyMeSubmit}
      </button>
    </form>
  );
}
