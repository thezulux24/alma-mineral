'use client';

/**
 * Formularios propios y aviso de cookies en storefronts React.
 *
 *   const lead = useLeadForm({ formId: 'cotizacion' });
 *   <form onSubmit={(e) => { e.preventDefault(); lead.submit({ payload: { nombre, email } }); }}>…</form>
 *   lead.status === 'done' && <p>{ui.formSuccess}</p>
 *
 *   const consent = useTrackingConsent();
 *   consent.visible && <div>{consent.banner.text} <button onClick={consent.accept}>{consent.banner.acceptLabel}</button></div>
 *
 * Los textos salen de los globales (`global.ui`, `globalData.site.cookieBanner`), editables en /portal.
 */
import { useCallback, useEffect, useState } from 'react';
import { cookieBannerConfig, saveConsent, type CookieBannerConfig } from '../consent.js';
import { submitLead, type LeadInput, type LeadResult } from '../leads.js';
import { readConsent, type ConsentState } from '../tracking/core.js';
import { useOptionalCms } from './context.js';
import { useShopUi } from './ui.js';

export interface UseLeadForm {
  status: 'idle' | 'sending' | 'done' | 'error';
  error: string | null;
  result: LeadResult | null;
  submit(input: Omit<LeadInput, 'slug' | 'apiUrl'>): Promise<LeadResult | null>;
  reset(): void;
}

/** Envía leads a `POST /api/public/leads/:slug` (con `generate_lead` y el contexto para Meta). */
export function useLeadForm(opts: { formId?: string; formName?: string; slug?: string; apiUrl?: string; fetch?: typeof fetch } = {}): UseLeadForm {
  const cms = useOptionalCms();
  const ui = useShopUi();
  const slug = opts.slug || cms?.slug || '';
  const apiUrl = opts.apiUrl || cms?.cmsUrl;
  const [status, setStatus] = useState<UseLeadForm['status']>('idle');
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<LeadResult | null>(null);
  const submit = useCallback(
    async (input: Omit<LeadInput, 'slug' | 'apiUrl'>) => {
      if (!slug) {
        setStatus('error');
        setError(ui.formError);
        return null;
      }
      setStatus('sending');
      setError(null);
      try {
        const r = await submitLead({ formId: opts.formId, formName: opts.formName, fetch: opts.fetch, ...input, slug, apiUrl });
        setResult(r);
        setStatus('done');
        return r;
      } catch (e) {
        setStatus('error');
        setError((e as Error)?.message || ui.formError);
        return null;
      }
    },
    [slug, apiUrl, opts.formId, opts.formName, opts.fetch, ui.formError],
  );
  const reset = useCallback(() => {
    setStatus('idle');
    setError(null);
    setResult(null);
  }, []);
  return { status, error, result, submit, reset };
}

export interface UseTrackingConsent {
  /** granted | denied | pending (aún no decide). `pending` también en SSR. */
  state: ConsentState;
  /** El banner está activo y el visitante no ha decidido. */
  visible: boolean;
  banner: CookieBannerConfig;
  accept(): void;
  reject(): void;
}

/** Banner de cookies headless: mismo almacenamiento y evento que el renderer (la medición reacciona sola). */
export function useTrackingConsent(opts: { slug?: string } = {}): UseTrackingConsent {
  const cms = useOptionalCms();
  const slug = opts.slug || cms?.slug || '';
  const banner = cookieBannerConfig(cms?.payload?.global);
  const [state, setState] = useState<ConsentState>('pending');
  useEffect(() => {
    if (slug) setState(readConsent(slug));
  }, [slug]);
  const decide = useCallback(
    (granted: boolean) => {
      if (!slug) return;
      saveConsent(slug, granted);
      setState(granted ? 'granted' : 'denied');
    },
    [slug],
  );
  return {
    state,
    visible: banner.enabled && state === 'pending' && !cms?.isBuilder,
    banner,
    accept: () => decide(true),
    reject: () => decide(false),
  };
}
