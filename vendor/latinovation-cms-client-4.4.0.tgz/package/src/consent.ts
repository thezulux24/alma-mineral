/**
 * Aviso de cookies para storefronts headless (docs/TRACKING.md): mismo almacenamiento y mismo
 * evento que el banner del renderer de /site, así la medición (`initTracking`) reacciona igual.
 *
 *   const banner = cookieBannerConfig(payload.global);
 *   if (banner.enabled && readConsent(slug) === 'pending') mostrarBanner(banner.text);
 *   saveConsent(slug, true);   // «Aceptar»: guarda y avisa a los píxeles
 *
 * Los textos del banner son globales del sitio (`globalData.site.cookieBanner`), editables en /portal.
 */
import { consentStorageKey } from './tracking/core.js';

export interface CookieBannerConfig {
  enabled: boolean;
  text: string;
  acceptLabel: string;
  rejectLabel: string;
  policyLabel: string;
  policyHref: string;
}

const s = (v: unknown, d = '') => (typeof v === 'string' && v.trim() ? v : d);

/** `globalData.site.cookieBanner` con los mismos textos por defecto del renderer (y `global.ui`). */
export function cookieBannerConfig(global: Record<string, any> | null | undefined): CookieBannerConfig {
  const g: Record<string, any> = global && typeof global === 'object' ? global : {};
  const c: Record<string, any> = g.site && typeof g.site === 'object' && g.site.cookieBanner && typeof g.site.cookieBanner === 'object' ? g.site.cookieBanner : {};
  const ui: Record<string, any> = g.ui && typeof g.ui === 'object' ? g.ui : {};
  return {
    enabled: c.enabled === true,
    text: s(c.text, s(ui.cookieText, 'Usamos cookies para que el sitio funcione y para entender cómo se usa.')),
    acceptLabel: s(c.acceptLabel, s(ui.cookieAccept, 'Aceptar')),
    rejectLabel: s(c.rejectLabel, s(ui.cookieReject, 'Solo necesarias')),
    policyLabel: s(c.policyLabel, s(ui.cookiePolicy, 'Política de privacidad')),
    policyHref: s(c.policyHref),
  };
}

/**
 * Guarda la decisión del visitante (`bk-cookies:<slug>` = accepted | rejected) y emite
 * `cms:cookie-consent`, que `initTracking` / `<CmsTracking>` escuchan para cargar o frenar píxeles.
 */
export function saveConsent(slug: string, granted: boolean): void {
  const value = granted ? 'accepted' : 'rejected';
  try {
    (globalThis as any).localStorage?.setItem(consentStorageKey(slug), value);
  } catch {
    // almacenamiento bloqueado: la decisión vale para esta visita
  }
  const w = (globalThis as any).window;
  // El constructor del mismo window (evita mezclar realms en iframes o entornos de prueba).
  const CE = w?.CustomEvent || (globalThis as any).CustomEvent;
  if (w && typeof w.dispatchEvent === 'function' && typeof CE === 'function') {
    try {
      w.dispatchEvent(new CE('cms:cookie-consent', { detail: value }));
    } catch {
      // sin eventos: la decisión ya quedó guardada
    }
  }
}
