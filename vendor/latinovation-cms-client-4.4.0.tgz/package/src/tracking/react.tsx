'use client';

/**
 * Medición para storefronts headless (docs/TRACKING.md). Lee la configuración de los globales del
 * delivery (`global.site.tracking`, con respaldo en `seo`), respeta el consentimiento y emite page_view
 * en cada navegación.
 *
 *   <CmsProvider initial={initial} slug="demo">
 *     <CmsTracking pathname={usePathname()} />   // Next: pasa la ruta para page_view en navegaciones
 *     {children}
 *   </CmsProvider>
 *
 *   const track = useTrack();
 *   track('add_to_cart', { value: 89000, currency: 'COP', items: [{ item_id: p.id, item_name: p.title, quantity: 1 }] });
 */
import { useCallback, useEffect, useRef } from 'react';
import { useOptionalCms } from '../react/context.js';
import {
  initTracking,
  loadTrackingScripts,
  resolveTracking,
  track as dispatchTrack,
  type StandardEvent,
  type TrackingConfig,
  type TrackingHandle,
  type TrackingScript,
  type TrackParams,
} from './core.js';

export interface CmsTrackingProps {
  /** Configuración explícita; por defecto, la de `<CmsProvider>` (global.site.tracking). */
  config?: TrackingConfig | null;
  /** Slug del proyecto; por defecto, el de `<CmsProvider>`. */
  slug?: string;
  /** URL del CMS para el aviso de "probar conexión" en el portal. Por defecto, la del provider. */
  apiBase?: string;
  /** Ruta actual: cada cambio emite page_view. Sin ella, se emite uno al montar. */
  pathname?: string;
  /** false: no emite page_view (lo hace el sitio). */
  pageViews?: boolean;
  /** Cargador propio (p. ej. next/script). Por defecto inserta <script async> en <head>. */
  loadScripts?: (scripts: TrackingScript[], handle: TrackingHandle) => void;
  /** Sin medición (por defecto: dentro del editor o en vista previa). */
  disabled?: boolean;
}

/** Instala píxeles y etiquetas del sitio. No pinta nada. */
export function CmsTracking(props: CmsTrackingProps): null {
  const cms = useOptionalCms();
  const slug = props.slug || cms?.slug || cms?.payload?.project?.slug || '';
  const config = props.config !== undefined ? props.config : resolveTracking(cms?.payload?.global, cms?.payload?.seo);
  const apiBase = props.apiBase ?? cms?.cmsUrl ?? '';
  const disabled = props.disabled ?? Boolean(cms?.isBuilder || cms?.isPreview);
  const key = JSON.stringify(config);
  const loaderRef = useRef(props.loadScripts);
  loaderRef.current = props.loadScripts;
  const handleRef = useRef<TrackingHandle | null>(null);

  useEffect(() => {
    if (!config || !slug || disabled) return;
    const handle = initTracking({ config, slug, apiBase, disabled });
    handleRef.current = handle;
    const load = (scripts: TrackingScript[]) => (loaderRef.current ? loaderRef.current(scripts, handle) : loadTrackingScripts(handle, scripts));
    load(handle.scripts);
    const off = handle.onScripts(load);
    return () => {
      off();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key, slug, apiBase, disabled]);

  const pageViews = props.pageViews !== false;
  useEffect(() => {
    if (!config || !slug || disabled || !pageViews) return;
    dispatchTrack('page_view');
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [props.pathname, key, slug, disabled, pageViews]);

  return null;
}

/**
 * Despachador de eventos estándar. Devuelve el event_id (pásalo como `tracking.eventId` al backend
 * para deduplicar con la API de conversiones). Fuera de `<CmsTracking>` no hace nada.
 */
export function useTrack(): (event: StandardEvent, params?: TrackParams) => string {
  return useCallback((event: StandardEvent, params?: TrackParams) => dispatchTrack(event, params), []);
}
