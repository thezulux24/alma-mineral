/**
 * Medición (v5 F1.1, docs/TRACKING.md): píxeles y etiquetas reales con consentimiento.
 *
 * Fuente única del despachador: la usan el renderer de /site/[slug] (copia en
 * frontend/src/sdk-generated/tracking, ver frontend/scripts/sync-sdk.mjs) y los storefronts headless
 * (`CmsTracking` / `useTrack` en `@latinovation/cms-client/react`). Sin dependencias: solo DOM.
 *
 *   const cfg = resolveTracking(payload.global, payload.seo);       // globalData.site.tracking (+ seoConfig viejo)
 *   const t = initTracking({ config: cfg, slug: 'demo', apiBase: 'https://webproai.tech' });
 *   t.scripts → [{ provider: 'ga4', id, src }]   // el cargador (next/script o DOM) los inserta
 *   track('add_to_cart', { value: 89000, currency: 'COP', items: [{ item_id: 'i1', item_name: 'Creatina' }] });
 *
 * Consentimiento (globalData.site.tracking.consentMode):
 *   - gdpr:    Google carga con Consent Mode v2 en "denied" hasta aceptar; Meta, TikTok y Clarity solo tras aceptar.
 *   - opt-out: todo carga con consentimiento concedido; si el visitante rechaza, se revoca.
 *   - none:    todo carga, sin señales de consentimiento.
 * El banner de cookies del sitio guarda la decisión en localStorage `bk-cookies:<slug>` y emite el
 * evento `cms:cookie-consent` (detail: 'accepted' | 'rejected'); un sitio headless puede emitir el
 * mismo evento o llamar a `setTrackingConsent(true|false)`.
 */

export type TrackingProvider = 'ga4' | 'gtm' | 'googleAds' | 'meta' | 'tiktok' | 'clarity';
export type ConsentMode = 'gdpr' | 'opt-out' | 'none';
export type ConsentState = 'granted' | 'denied' | 'pending';

export interface TrackingConfig {
  ga4?: string;
  gtm?: string;
  metaPixel?: string;
  tiktokPixel?: string;
  googleAds?: { id?: string; purchaseLabel?: string; leadLabel?: string };
  clarity?: string;
  consentMode: ConsentMode;
}

export type StandardEvent = 'page_view' | 'view_item' | 'add_to_cart' | 'begin_checkout' | 'purchase' | 'generate_lead' | 'contact' | 'schedule';

export interface TrackItem {
  item_id: string;
  item_name?: string;
  item_variant?: string;
  item_category?: string;
  price?: number;
  quantity?: number;
}

export interface TrackParams {
  value?: number;
  currency?: string;
  /** Número de pedido en `purchase` (también es el event_id que deduplica con la API de conversiones). */
  transaction_id?: string;
  items?: TrackItem[];
  /** `contact`: 'whatsapp' | 'phone' | 'email'. `generate_lead`: id del formulario. */
  method?: string;
  form_id?: string;
  page_path?: string;
  page_location?: string;
  page_title?: string;
  /** Id del evento para deduplicar navegador ↔ servidor (se genera si falta). */
  event_id?: string;
  [key: string]: unknown;
}

export interface TrackingScript {
  provider: TrackingProvider;
  /** id estable del <script> (cms-trk-<proveedor>). */
  id: string;
  src: string;
}

/** Validación de ids (la misma que aplica el backend al guardar, backend/src/tracking/tracking-config.ts). */
export const TRACKING_ID_PATTERNS = {
  ga4: /^G-[A-Z0-9]{4,16}$/,
  gtm: /^GTM-[A-Z0-9]{4,12}$/,
  metaPixel: /^\d{8,20}$/,
  tiktokPixel: /^[A-Z0-9]{10,30}$/,
  googleAdsId: /^AW-\d{6,14}$/,
  googleAdsLabel: /^[A-Za-z0-9_-]{4,64}$/,
  clarity: /^[a-z0-9]{6,16}$/,
} as const;

const CONSENT_MODES: ConsentMode[] = ['gdpr', 'opt-out', 'none'];
const GOOGLE: TrackingProvider[] = ['ga4', 'gtm', 'googleAds'];

const isObj = (v: unknown): v is Record<string, any> => Boolean(v) && typeof v === 'object' && !Array.isArray(v);
const clean = (v: unknown, re: RegExp, upper = false): string | undefined => {
  if (typeof v !== 'string' && typeof v !== 'number') return undefined;
  let s = String(v).trim();
  if (upper) s = s.toUpperCase();
  return re.test(s) ? s : undefined;
};

/**
 * Configuración de medición a partir de los globales del delivery: `global.site.tracking` y, como
 * respaldo, los campos viejos `seo.googleTagManagerId` / `seo.metaPixelId`. Ids inválidos se ignoran.
 * Devuelve null si no hay ningún proveedor configurado.
 */
export function resolveTracking(global: unknown, seo?: unknown): TrackingConfig | null {
  const site = isObj(global) && isObj(global.site) ? global.site : {};
  const raw: Record<string, any> = isObj(site.tracking) ? site.tracking : {};
  const old: Record<string, any> = isObj(seo) ? seo : {};
  const P = TRACKING_ID_PATTERNS;
  const ads = isObj(raw.googleAds) ? raw.googleAds : {};
  const cfg: TrackingConfig = {
    ga4: clean(raw.ga4, P.ga4, true),
    gtm: clean(raw.gtm, P.gtm, true) ?? clean(old.googleTagManagerId, P.gtm, true),
    metaPixel: clean(raw.metaPixel, P.metaPixel) ?? clean(old.metaPixelId, P.metaPixel),
    tiktokPixel: clean(raw.tiktokPixel, P.tiktokPixel, true),
    clarity: clean(typeof raw.clarity === 'string' ? raw.clarity.toLowerCase() : raw.clarity, P.clarity),
    consentMode: CONSENT_MODES.includes(raw.consentMode) ? raw.consentMode : 'gdpr',
  };
  const adsId = clean(ads.id, P.googleAdsId, true);
  if (adsId) {
    cfg.googleAds = {
      id: adsId,
      purchaseLabel: clean(ads.purchaseLabel, P.googleAdsLabel),
      leadLabel: clean(ads.leadLabel, P.googleAdsLabel),
    };
  }
  return configuredProviders(cfg).length ? cfg : null;
}

/** Proveedores con id en la configuración. */
export function configuredProviders(cfg: TrackingConfig | null | undefined): TrackingProvider[] {
  if (!cfg) return [];
  const out: TrackingProvider[] = [];
  if (cfg.ga4) out.push('ga4');
  if (cfg.gtm) out.push('gtm');
  if (cfg.googleAds?.id) out.push('googleAds');
  if (cfg.metaPixel) out.push('meta');
  if (cfg.tiktokPixel) out.push('tiktok');
  if (cfg.clarity) out.push('clarity');
  return out;
}

/* ------------------------------------------------------------------ */
/* Consentimiento                                                      */
/* ------------------------------------------------------------------ */

export const consentStorageKey = (slug: string) => `bk-cookies:${slug}`;

/** Decisión guardada por el banner de cookies: granted | denied | pending (aún no decide). */
export function readConsent(slug: string): ConsentState {
  try {
    const v = typeof localStorage !== 'undefined' ? localStorage.getItem(consentStorageKey(slug)) : null;
    return v === 'accepted' ? 'granted' : v === 'rejected' ? 'denied' : 'pending';
  } catch {
    return 'pending';
  }
}

/** Consentimiento efectivo según el modo: `none` siempre concede; `opt-out` concede hasta que rechacen. */
export function effectiveConsent(mode: ConsentMode, state: ConsentState): 'granted' | 'denied' {
  if (mode === 'none') return 'granted';
  if (mode === 'opt-out') return state === 'denied' ? 'denied' : 'granted';
  return state === 'granted' ? 'granted' : 'denied';
}

/** Proveedores que pueden cargarse ahora: Google siempre (Consent Mode decide qué guarda); el resto con consentimiento. */
export function allowedProviders(cfg: TrackingConfig | null, state: ConsentState): TrackingProvider[] {
  const granted = cfg ? effectiveConsent(cfg.consentMode, state) === 'granted' : false;
  return configuredProviders(cfg).filter((p) => GOOGLE.includes(p) || granted);
}

/* ------------------------------------------------------------------ */
/* Nombres por proveedor                                               */
/* ------------------------------------------------------------------ */

export const META_EVENTS: Record<StandardEvent, string> = {
  page_view: 'PageView',
  view_item: 'ViewContent',
  add_to_cart: 'AddToCart',
  begin_checkout: 'InitiateCheckout',
  purchase: 'Purchase',
  generate_lead: 'Lead',
  contact: 'Contact',
  schedule: 'Schedule',
};

/** TikTok: `page_view` usa ttq.page(). */
export const TIKTOK_EVENTS: Record<Exclude<StandardEvent, 'page_view'>, string> = {
  view_item: 'ViewContent',
  add_to_cart: 'AddToCart',
  begin_checkout: 'InitiateCheckout',
  purchase: 'CompletePayment',
  generate_lead: 'SubmitForm',
  contact: 'Contact',
  schedule: 'Schedule',
};

const ECOMMERCE: StandardEvent[] = ['view_item', 'add_to_cart', 'begin_checkout', 'purchase'];

/** Parámetros de Meta (ViewContent/AddToCart/…): content_ids, contents, value, currency. */
export function metaParams(event: StandardEvent, p: TrackParams): Record<string, unknown> {
  const out: Record<string, unknown> = {};
  if (p.value !== undefined) out.value = p.value;
  if (p.currency) out.currency = p.currency;
  if (p.items?.length) {
    out.content_ids = p.items.map((i) => i.item_id);
    out.contents = p.items.map((i) => ({ id: i.item_id, quantity: i.quantity ?? 1, ...(i.price !== undefined ? { item_price: i.price } : {}) }));
    out.content_type = 'product';
    out.num_items = p.items.reduce((n, i) => n + (i.quantity ?? 1), 0);
    if (p.items.length === 1 && p.items[0].item_name) out.content_name = p.items[0].item_name;
  }
  if (event === 'generate_lead' && p.form_id) out.content_name = p.form_id;
  if (event === 'contact' && p.method) out.content_category = p.method;
  return out;
}

/** Parámetros de TikTok: contents [{ content_id, content_name, quantity, price }], value, currency. */
export function tiktokParams(p: TrackParams): Record<string, unknown> {
  const out: Record<string, unknown> = {};
  if (p.value !== undefined) out.value = p.value;
  if (p.currency) out.currency = p.currency;
  if (p.items?.length) {
    out.contents = p.items.map((i) => ({
      content_id: i.item_id,
      ...(i.item_name ? { content_name: i.item_name } : {}),
      quantity: i.quantity ?? 1,
      ...(i.price !== undefined ? { price: i.price } : {}),
    }));
    out.content_type = 'product';
  }
  return out;
}

/* ------------------------------------------------------------------ */
/* Estado del rastreador                                               */
/* ------------------------------------------------------------------ */

export interface TrackLogEntry {
  event: StandardEvent;
  eventId: string;
  providers: TrackingProvider[];
  params: TrackParams;
  at: number;
}

interface TrackerState {
  config: TrackingConfig;
  slug: string;
  apiBase: string;
  consent: ConsentState;
  /** Proveedores con stub e init hechos. */
  active: Set<TrackingProvider>;
  /** Proveedores cuyo script terminó de cargar. */
  loaded: Set<TrackingProvider>;
  /** Proveedores que ya recibieron un evento en esta página. */
  fired: Set<TrackingProvider>;
  scripts: TrackingScript[];
  lastPage: TrackParams | null;
  listeners: Set<(scripts: TrackingScript[]) => void>;
  log: TrackLogEntry[];
  beaconTimer: any;
  beaconPending: Set<TrackingProvider>;
  disabled: boolean;
  offConsent?: () => void;
}

type W = Window & Record<string, any>;
const win = (): W | null => (typeof window === 'undefined' ? null : (window as unknown as W));
const STATE_KEY = '__cmsTracking';

function state(): TrackerState | null {
  const w = win();
  return w && w[STATE_KEY] ? (w[STATE_KEY] as TrackerState) : null;
}

/** Id de evento para deduplicar (navegador ↔ API de conversiones). */
export function newEventId(prefix = 'ev'): string {
  const c: any = typeof crypto !== 'undefined' ? crypto : null;
  const rnd = c?.randomUUID ? c.randomUUID() : `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 10)}`;
  return `${prefix}-${rnd}`;
}

function debugOn(): boolean {
  try {
    const w = win();
    return Boolean(w && (/[?&]cms_debug=1\b/.test(w.location.search) || w.localStorage?.getItem('cms-tracking-debug') === '1'));
  } catch {
    return false;
  }
}

/* ---------- stubs (equivalentes a los fragmentos oficiales, sin insertar el <script>) ---------- */

function gtagStub(w: W) {
  w.dataLayer = w.dataLayer || [];
  if (typeof w.gtag !== 'function') {
    // gtag.js reconoce el objeto `arguments`, no un arreglo.
    w.gtag = function gtag() {
      // eslint-disable-next-line prefer-rest-params
      w.dataLayer.push(arguments);
    };
    w.gtag('js', new Date());
  }
}

function metaStub(w: W) {
  if (w.fbq) return;
  const n: any = function (...args: unknown[]) {
    if (n.callMethod) n.callMethod(...args);
    else n.queue.push(args);
  };
  w.fbq = n;
  if (!w._fbq) w._fbq = n;
  n.push = n;
  n.loaded = true;
  n.version = '2.0';
  n.queue = [];
}

const TTQ_METHODS = ['page', 'track', 'identify', 'instances', 'debug', 'on', 'off', 'once', 'ready', 'alias', 'group', 'enableCookie', 'disableCookie', 'holdConsent', 'revokeConsent', 'grantConsent'];

function tiktokStub(w: W, id: string) {
  w.TiktokAnalyticsObject = 'ttq';
  const ttq: any = (w.ttq = w.ttq || []);
  ttq.methods = TTQ_METHODS;
  ttq.setAndDefer = (t: any, e: string) => {
    t[e] = (...args: unknown[]) => t.push([e, ...args]);
  };
  for (const m of TTQ_METHODS) if (typeof ttq[m] !== 'function') ttq.setAndDefer(ttq, m);
  ttq.instance = (t: string) => {
    const e = ttq._i[t] || [];
    for (const m of TTQ_METHODS) ttq.setAndDefer(e, m);
    return e;
  };
  // ttq.load sin insertar el script: lo inserta el cargador (next/script o DOM).
  const u = 'https://analytics.tiktok.com/i18n/pixel/events.js';
  ttq._i = ttq._i || {};
  ttq._i[id] = ttq._i[id] || [];
  ttq._i[id]._u = u;
  ttq._t = ttq._t || {};
  ttq._t[id] = +new Date();
  ttq._o = ttq._o || {};
  ttq._o[id] = {};
}

function clarityStub(w: W) {
  if (typeof w.clarity === 'function') return;
  w.clarity = function clarity(...args: unknown[]) {
    (w.clarity.q = w.clarity.q || []).push(args);
  };
}

function consentPayload(granted: boolean) {
  const v = granted ? 'granted' : 'denied';
  return { ad_storage: v, ad_user_data: v, ad_personalization: v, analytics_storage: v };
}

/** Activa (stub + init) un proveedor y devuelve su script, o null si ya estaba activo. */
function activate(s: TrackerState, p: TrackingProvider): TrackingScript | null {
  const w = win();
  if (!w || s.active.has(p)) return null;
  const c = s.config;
  const granted = effectiveConsent(c.consentMode, s.consent) === 'granted';
  s.active.add(p);
  const g = (src: string): TrackingScript => ({ provider: p, id: `cms-trk-${p}`, src });
  switch (p) {
    case 'ga4':
      gtagStub(w);
      w.gtag('config', c.ga4, { send_page_view: false });
      return g(`https://www.googletagmanager.com/gtag/js?id=${encodeURIComponent(c.ga4!)}`);
    case 'googleAds':
      gtagStub(w);
      w.gtag('config', c.googleAds!.id);
      // Con GA4 basta un gtag.js; solo con Google Ads se carga con su id.
      return c.ga4 ? null : g(`https://www.googletagmanager.com/gtag/js?id=${encodeURIComponent(c.googleAds!.id!)}`);
    case 'gtm':
      w.dataLayer = w.dataLayer || [];
      w.dataLayer.push({ 'gtm.start': Date.now(), event: 'gtm.js' });
      return g(`https://www.googletagmanager.com/gtm.js?id=${encodeURIComponent(c.gtm!)}`);
    case 'meta':
      metaStub(w);
      if (c.consentMode !== 'none' && !granted) w.fbq('consent', 'revoke');
      w.fbq('init', c.metaPixel);
      return g('https://connect.facebook.net/en_US/fbevents.js');
    case 'tiktok':
      tiktokStub(w, c.tiktokPixel!);
      return g(`https://analytics.tiktok.com/i18n/pixel/events.js?sdkid=${encodeURIComponent(c.tiktokPixel!)}&lib=ttq`);
    case 'clarity':
      clarityStub(w);
      if (c.consentMode !== 'none') w.clarity('consent', granted);
      return g(`https://www.clarity.ms/tag/${encodeURIComponent(c.clarity!)}`);
  }
  return null;
}

function emitScripts(s: TrackerState) {
  const list = [...s.scripts];
  for (const fn of s.listeners) {
    try {
      fn(list);
    } catch {
      /* un listener roto no detiene la medición */
    }
  }
}

function activateAllowed(s: TrackerState): TrackingProvider[] {
  const fresh: TrackingProvider[] = [];
  for (const p of allowedProviders(s.config, s.consent)) {
    const wasActive = s.active.has(p);
    const script = activate(s, p);
    if (!wasActive) fresh.push(p);
    if (script && !s.scripts.some((x) => x.id === script.id)) s.scripts.push(script);
  }
  if (fresh.length) emitScripts(s);
  return fresh;
}

export interface InitTrackingOptions {
  config: TrackingConfig | null;
  slug: string;
  /** URL del CMS para el aviso "vimos un evento" (`POST /api/public/tracking/:slug/seen`). Vacío: sin aviso. */
  apiBase?: string;
  /** Sin medición (editor, vista previa). */
  disabled?: boolean;
}

export interface TrackingHandle {
  scripts: TrackingScript[];
  /** Avisa cuando cambian los scripts a cargar (p. ej. tras aceptar cookies). Devuelve la baja. */
  onScripts(fn: (scripts: TrackingScript[]) => void): () => void;
  /** El cargador lo llama en el `onload` del script. */
  markLoaded(provider: TrackingProvider): void;
  destroy(): void;
}

/**
 * Instala el rastreador en `window` (idempotente por proyecto) y aplica el consentimiento guardado.
 * Devuelve los scripts que el cargador debe insertar.
 */
export function initTracking(opts: InitTrackingOptions): TrackingHandle {
  const w = win();
  const noop: TrackingHandle = { scripts: [], onScripts: () => () => {}, markLoaded: () => {}, destroy: () => {} };
  if (!w || !opts.config || opts.disabled) return noop;
  let s = state();
  if (!s || s.slug !== opts.slug || JSON.stringify(s.config) !== JSON.stringify(opts.config)) {
    s?.offConsent?.();
    s = {
      config: opts.config,
      slug: opts.slug,
      apiBase: String(opts.apiBase || '').replace(/\/+$/, ''),
      consent: readConsent(opts.slug),
      active: new Set(),
      loaded: new Set(),
      fired: new Set(),
      scripts: [],
      lastPage: null,
      listeners: new Set(),
      log: s?.log || [],
      beaconTimer: null,
      beaconPending: new Set(),
      disabled: false,
    };
    w[STATE_KEY] = s;
    const google = configuredProviders(s.config).some((p) => GOOGLE.includes(p));
    if (google && s.config.consentMode !== 'none') {
      gtagStub(w);
      const granted = effectiveConsent(s.config.consentMode, s.consent) === 'granted';
      // Consent Mode v2: valores por defecto ANTES de cualquier config/gtm.js.
      w.gtag('consent', 'default', { ...consentPayload(granted), wait_for_update: 500 });
    }
    activateAllowed(s);
    const onConsent = (e: Event) => {
      const d = (e as CustomEvent).detail;
      if (d === 'accepted' || d === 'rejected') setTrackingConsent(d === 'accepted');
    };
    w.addEventListener('cms:cookie-consent', onConsent);
    s.offConsent = () => w.removeEventListener('cms:cookie-consent', onConsent);
  }
  const cur = s;
  return {
    scripts: [...cur.scripts],
    onScripts(fn) {
      cur.listeners.add(fn);
      return () => cur.listeners.delete(fn);
    },
    markLoaded(p) {
      cur.loaded.add(p);
      if (p === 'ga4' && cur.config.googleAds?.id) cur.loaded.add('googleAds');
      if (cur.fired.has(p)) queueBeacon(cur, p);
    },
    destroy() {
      cur.offConsent?.();
      if (win()?.[STATE_KEY] === cur) delete win()![STATE_KEY];
    },
  };
}

/**
 * Cambia el consentimiento (lo llama el banner vía `cms:cookie-consent`, o un sitio headless).
 * Al aceptar se cargan Meta/TikTok/Clarity y reciben el page_view de la página actual.
 */
export function setTrackingConsent(granted: boolean): void {
  const s = state();
  const w = win();
  if (!s || !w) return;
  s.consent = granted ? 'granted' : 'denied';
  const c = s.config;
  if (c.consentMode === 'none') return;
  if (typeof w.gtag === 'function' && configuredProviders(c).some((p) => GOOGLE.includes(p))) w.gtag('consent', 'update', consentPayload(granted));
  if (granted) {
    if (s.active.has('meta')) w.fbq?.('consent', 'grant');
    if (s.active.has('tiktok')) w.ttq?.grantConsent?.();
    if (s.active.has('clarity')) w.clarity?.('consent', true);
    const fresh = activateAllowed(s).filter((p) => !GOOGLE.includes(p));
    if (fresh.length && s.lastPage) dispatch(s, 'page_view', s.lastPage, fresh, newEventId('pv'));
  } else {
    if (s.active.has('meta')) w.fbq?.('consent', 'revoke');
    if (s.active.has('tiktok')) w.ttq?.revokeConsent?.();
    if (s.active.has('clarity')) w.clarity?.('consent', false);
  }
}

/* ------------------------------------------------------------------ */
/* Despacho                                                            */
/* ------------------------------------------------------------------ */

const DONE_KEY = (slug: string) => `cms-trk-done:${slug}`;

function alreadyTracked(slug: string, txId: string): boolean {
  try {
    const list: string[] = JSON.parse(localStorage.getItem(DONE_KEY(slug)) || '[]');
    if (list.includes(txId)) return true;
    localStorage.setItem(DONE_KEY(slug), JSON.stringify([...list, txId].slice(-50)));
  } catch {
    /* sin almacenamiento: se envía (la deduplicación del servidor usa transaction_id) */
  }
  return false;
}

function dispatch(s: TrackerState, event: StandardEvent, p: TrackParams, only: TrackingProvider[] | null, eventId: string) {
  const w = win()!;
  const c = s.config;
  const targets = [...s.active].filter((x) => !only || only.includes(x));
  const sent: TrackingProvider[] = [];
  const clean: TrackParams = { ...p };
  delete clean.event_id;
  for (const prov of targets) {
    try {
      if (prov === 'ga4' && typeof w.gtag === 'function') {
        w.gtag('event', event, { ...clean, send_to: c.ga4, event_id: eventId });
        sent.push(prov);
      } else if (prov === 'googleAds' && typeof w.gtag === 'function') {
        const label = event === 'purchase' ? c.googleAds?.purchaseLabel : event === 'generate_lead' ? c.googleAds?.leadLabel : undefined;
        if (label) {
          w.gtag('event', 'conversion', {
            send_to: `${c.googleAds!.id}/${label}`,
            ...(clean.value !== undefined ? { value: clean.value } : {}),
            ...(clean.currency ? { currency: clean.currency } : {}),
            transaction_id: clean.transaction_id || eventId,
          });
          sent.push(prov);
        }
      } else if (prov === 'gtm') {
        w.dataLayer = w.dataLayer || [];
        if (ECOMMERCE.includes(event)) {
          w.dataLayer.push({ ecommerce: null });
          const { items, value, currency, transaction_id, ...rest } = clean;
          w.dataLayer.push({ event, event_id: eventId, ...rest, ecommerce: { items: items || [], value, currency, transaction_id } });
        } else {
          w.dataLayer.push({ event, event_id: eventId, ...clean });
        }
        sent.push(prov);
      } else if (prov === 'meta' && typeof w.fbq === 'function') {
        w.fbq('track', META_EVENTS[event], metaParams(event, clean), { eventID: eventId });
        sent.push(prov);
      } else if (prov === 'tiktok' && w.ttq) {
        if (event === 'page_view') w.ttq.page();
        else w.ttq.track(TIKTOK_EVENTS[event], tiktokParams(clean), { event_id: eventId });
        sent.push(prov);
      } else if (prov === 'clarity' && typeof w.clarity === 'function') {
        if (event !== 'page_view') w.clarity('event', event);
        sent.push(prov);
      }
    } catch {
      /* un proveedor roto no afecta a los demás */
    }
  }
  for (const prov of sent) {
    s.fired.add(prov);
    if (s.loaded.has(prov)) queueBeacon(s, prov);
  }
  s.log.push({ event, eventId, providers: sent, params: clean, at: Date.now() });
  if (s.log.length > 50) s.log.splice(0, s.log.length - 50);
  if (debugOn()) console.info('[cms-tracking]', event, { eventId, providers: sent, params: clean });
}

/**
 * Envía un evento estándar a todos los proveedores activos con su nombre propio
 * (Meta: PageView/ViewContent/AddToCart/InitiateCheckout/Purchase/Lead/Contact; TikTok equivalentes).
 * Devuelve el event_id (pásalo al backend para deduplicar con la API de conversiones).
 * `purchase` se envía una sola vez por transaction_id en este navegador. Sin rastreador: no hace nada.
 */
export function track(event: StandardEvent, params: TrackParams = {}): string {
  const s = state();
  const eventId =
    params.event_id || (event === 'purchase' && params.transaction_id ? String(params.transaction_id) : newEventId(event === 'page_view' ? 'pv' : 'ev'));
  if (!s || s.disabled) return eventId;
  const w = win()!;
  let p: TrackParams = params;
  if (event === 'page_view') {
    p = {
      page_path: w.location.pathname,
      page_location: w.location.href,
      page_title: typeof document !== 'undefined' ? document.title : undefined,
      ...params,
    };
    s.lastPage = p;
  }
  if (event === 'purchase' && p.transaction_id && alreadyTracked(s.slug, String(p.transaction_id))) return eventId;
  dispatch(s, event, p, null, eventId);
  return eventId;
}

/** Últimos eventos despachados (para depurar y para pruebas). */
export function trackingLog(): TrackLogEntry[] {
  return [...(state()?.log || [])];
}

/** Proveedores activos ahora mismo. */
export function activeProviders(): TrackingProvider[] {
  return [...(state()?.active || [])];
}

/* ------------------------------------------------------------------ */
/* Pedidos                                                             */
/* ------------------------------------------------------------------ */

/** Contraentrega: la compra cuenta al hacer el pedido (no hay pago en línea que confirmar). */
export function purchaseOnPlacement(provider: unknown): boolean {
  return /^(cod|contraentrega)$/i.test(String(provider || '').trim());
}

/**
 * Parámetros de begin_checkout / purchase desde la respuesta del checkout o de confirm-order
 * (precios calculados por el servidor). Con `purchase`, transaction_id = número de pedido.
 */
export function orderTrackParams(order: Record<string, any> | null | undefined, purchase: boolean): TrackParams {
  const o = order || {};
  const lines: any[] = Array.isArray(o.items) ? o.items : [];
  const value = Number(o.totalAmount ?? o.total);
  const out: TrackParams = {
    ...(Number.isFinite(value) ? { value } : {}),
    ...(o.currency ? { currency: String(o.currency).toUpperCase() } : {}),
    items: lines.map((it) => ({
      item_id: String(it?.productId ?? it?.id ?? it?.sku ?? it?.title ?? ''),
      ...(it?.title ? { item_name: String(it.title) } : {}),
      ...(it?.variantLabel || it?.variant ? { item_variant: String(it.variantLabel || it.variant) } : {}),
      ...(Number.isFinite(Number(it?.unitPrice)) ? { price: Number(it.unitPrice) } : {}),
      quantity: Number(it?.quantity) || 1,
    })),
  };
  if (purchase && o.orderNumber) out.transaction_id = String(o.orderNumber);
  return out;
}

/* ------------------------------------------------------------------ */
/* Contexto para el servidor (API de conversiones)                     */
/* ------------------------------------------------------------------ */

function cookie(name: string): string | undefined {
  if (typeof document === 'undefined') return undefined;
  const m = document.cookie.match(new RegExp(`(?:^|; )${name}=([^;]*)`));
  return m ? decodeURIComponent(m[1]) : undefined;
}

export interface TrackingContext {
  eventId?: string;
  fbp?: string;
  fbc?: string;
  sourceUrl?: string;
}

/**
 * Datos que el backend necesita para la API de conversiones de Meta: event_id (deduplicación),
 * cookies _fbp/_fbc (o fbclid de la URL) y la URL de origen. Se adjunta como `tracking` en
 * POST /api/public/leads/:slug y en el checkout. Sin consentimiento efectivo no lleva cookies.
 */
export function trackingContext(eventId?: string): TrackingContext {
  const s = state();
  const w = win();
  if (!w) return eventId ? { eventId } : {};
  const granted = s ? effectiveConsent(s.config.consentMode, s.consent) === 'granted' : false;
  const out: TrackingContext = { ...(eventId ? { eventId } : {}), sourceUrl: w.location.href.slice(0, 500) };
  if (!granted || !s?.config.metaPixel) return out;
  const fbp = cookie('_fbp');
  let fbc = cookie('_fbc');
  if (!fbc) {
    const clid = new URLSearchParams(w.location.search).get('fbclid');
    if (clid) fbc = `fb.1.${Date.now()}.${clid}`;
  }
  if (fbp) out.fbp = fbp;
  if (fbc) out.fbc = fbc;
  return out;
}

/* ------------------------------------------------------------------ */
/* Aviso "vimos un evento" (portal → Medición → probar conexión)       */
/* ------------------------------------------------------------------ */

const SEEN_KEY = (slug: string) => `cms-trk-seen:${slug}`;

function queueBeacon(s: TrackerState, p: TrackingProvider) {
  if (!s.apiBase) return;
  try {
    const sent: string[] = JSON.parse(sessionStorage.getItem(SEEN_KEY(s.slug)) || '[]');
    if (sent.includes(p)) return;
    sessionStorage.setItem(SEEN_KEY(s.slug), JSON.stringify([...sent, p]));
  } catch {
    /* sin sessionStorage: se envía igual (el servidor limita) */
  }
  s.beaconPending.add(p);
  if (s.beaconTimer) return;
  s.beaconTimer = setTimeout(() => {
    s.beaconTimer = null;
    const providers = [...s.beaconPending];
    s.beaconPending.clear();
    if (!providers.length || typeof fetch === 'undefined') return;
    fetch(`${s.apiBase}/api/public/tracking/${encodeURIComponent(s.slug)}/seen`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ providers }),
      keepalive: true,
    }).catch(() => {});
  }, 1500);
}

/* ------------------------------------------------------------------ */
/* Cargador DOM (storefronts sin next/script)                          */
/* ------------------------------------------------------------------ */

/** Inserta los scripts en <head> (async) y avisa `markLoaded` al cargar. Idempotente por id. */
export function loadTrackingScripts(handle: TrackingHandle, scripts: TrackingScript[] = handle.scripts): void {
  if (typeof document === 'undefined') return;
  for (const sc of scripts) {
    if (document.getElementById(sc.id)) continue;
    const el = document.createElement('script');
    el.id = sc.id;
    el.async = true;
    el.src = sc.src;
    el.onload = () => handle.markLoaded(sc.provider);
    document.head.appendChild(el);
  }
}
