/**
 * Tipos del payload público de delivery (GET /api/v1/delivery/:slug).
 * Reflejan backend/src/delivery/delivery.controller.ts y los contratos v4 (docs/PLAN-V4.md §2).
 */

/** Tipos de campo del catálogo y de `data-cms-type` (docs/LIVE-PREVIEW.md §8.1). */
export type FieldType =
  | 'text'
  | 'textarea'
  | 'richtext'
  | 'image'
  | 'gallery'
  | 'link'
  | 'number'
  | 'select'
  | 'boolean'
  | 'color'
  | 'collection'
  | 'array';

/** Campo del esquema de un bloque (compacto, generado desde shared/blocks.catalog.json). */
export interface FieldSchema {
  key: string;
  type: FieldType | string;
  label?: string;
  /** "style" = control de presentación (no es contenido visible). */
  group?: string;
  /** Subcampos de un repetidor (`type: 'array'`). */
  fields?: FieldSchema[];
}

export interface BlockSchema {
  label?: string;
  category?: string;
  fields: FieldSchema[];
}

/** Valor de un campo `link`. */
export interface LinkValue {
  label?: string;
  href?: string;
  newTab?: boolean;
  [key: string]: any;
}

/** Claves de estilo de sección (`data._style`, §8.3). Todas opcionales. */
export interface SectionStyle {
  backgroundColor?: string;
  textColor?: string;
  accentColor?: string;
  backgroundImage?: string;
  paddingTop?: number | string;
  paddingBottom?: number | string;
  textAlign?: 'left' | 'center' | 'right' | string;
  maxWidth?: number | string;
  borderRadius?: number | string;
  fontFamily?: string;
  hideOnMobile?: boolean;
  hideOnDesktop?: boolean;
  anchorId?: string;
  minHeight?: 'auto' | 'screen' | 'half' | string;
  /** 0–90: oscurece `backgroundImage`. */
  overlayOpacity?: number | string;
  contentWidth?: 'narrow' | 'standard' | 'wide' | 'full' | string;
  [key: string]: any;
}

/** Estilo por elemento (`data._elementStyles[elementId]`). */
export interface ElementStyle {
  backgroundColor?: string;
  textColor?: string;
  positionPreset?: 'top-left' | 'top-right' | 'center' | 'bottom-left' | 'bottom-right' | string;
  offsetX?: number;
  offsetY?: number;
  scale?: number;
  width?: string;
  maxWidth?: string;
  padding?: string;
  borderRadius?: string;
  fontSize?: string;
  border?: string;
  boxShadow?: string;
  backdropBlur?: string;
  opacity?: number | string;
  zIndex?: number | string;
  hidden?: boolean;
  customCss?: string;
  [key: string]: any;
}

export type SectionData = Record<string, any> & {
  /** Tipo de bloque del catálogo (contrato 2.3), ej. "hero.split". */
  _block?: string;
  _style?: SectionStyle;
  _elementStyles?: Record<string, ElementStyle>;
  _customCss?: string;
  _customHtml?: string;
  widgets?: Widget[];
};

export interface Widget {
  id: string;
  type?: string;
  badge?: string;
  title?: string;
  body?: string;
  imageUrl?: string;
  ctaText?: string;
  ctaHref?: string;
  metric?: string;
  metricLabel?: string;
  [key: string]: any;
}

export interface SectionRow {
  id: string;
  key: string;
  name?: string;
  isVisible?: boolean;
  order?: number;
  data?: SectionData;
  /** Solo presente en el estado en vivo que envía el portal. */
  draftData?: SectionData;
}

export interface CmsPage {
  id: string;
  title: string;
  slug: string;
  seoTitle?: string;
  seoImage?: string;
  /** Mapa clave → datos (solo visibles). */
  sections: Record<string, SectionData>;
  /** Lista ordenada con id, visibilidad y datos. */
  sectionsList: SectionRow[];
}

export interface NavLink {
  id: string;
  label: string;
  href: string;
  isVisible?: boolean;
  children?: NavLink[];
}

export interface Navigation {
  headerLinks?: NavLink[];
  footerLinks?: NavLink[];
  headerCtaText?: string;
  headerCtaHref?: string;
  promoBanner?: { enabled?: boolean; title?: string; description?: string; ctaText?: string; ctaHref?: string; [k: string]: any };
  [key: string]: any;
}

export interface CollectionDefinition {
  id: string;
  name: string;
  singularName?: string;
  slug: string;
  schema?: Array<{ key: string; type: string; label?: string; options?: any[] }>;
  categories?: string[];
  isStore?: boolean;
  /** v4.1: si existe, cada ítem tiene página propia `<routeBase>/<slug>`. */
  routeBase?: string;
  /** v4.1: filtros que el sitio ofrece para la colección. */
  filters?: CollectionFilterDef[];
  listDefaults?: { sort?: string; pageSize?: number };
  /** v4.1: secciones que forman la plantilla de detalle (`{{item.<campo>}}`). */
  detailLayout?: SectionData[];
  seo?: { titleField?: string; descriptionField?: string; imageField?: string };
  [key: string]: any;
}

export interface CollectionFilterDef {
  field: string;
  type: 'select' | 'range' | 'boolean' | 'search' | string;
  label?: string;
}

/** Ítem de colección aplanado: id/title/slug/status + todos los campos de `data`. */
export type CollectionItem = {
  id: string;
  title: string;
  slug: string;
  isFeatured?: boolean;
  status?: string;
  [key: string]: any;
};

export interface ProductVariant {
  label: string;
  price?: number;
  stock?: number;
  sku?: string;
  /** v5 F2.9: peso por unidad de la variante (kg) para cotizar envíos por peso. */
  weightKg?: number;
}

/** Categorías tributarias por producto (`data.taxCategory`, docs/PRICING.md §4). */
export type TaxCategory = 'iva19' | 'iva5' | 'exento' | 'excluido' | 'iva16' | 'iva8' | 'iva0' | (string & {});

/** Producto estándar de e-commerce (contrato 2.5), ya normalizado. */
export interface Product extends CollectionItem {
  price: number;
  compareAtPrice?: number;
  sku?: string;
  stock?: number;
  category?: string;
  imageUrl?: string;
  gallery: string[];
  summary?: string;
  description?: string;
  variants: ProductVariant[];
  inStock: boolean;
  /** v5 F2.3: promedio de reseñas aprobadas (solo llega si hay reseñas; normalizado a 0). */
  ratingAverage: number;
  /** v5 F2.3: número de reseñas aprobadas (0 si no hay). */
  ratingCount: number;
  /** v5 F2 precios: categoría tributaria (iva19, iva5, exento, excluido, iva16, iva8, iva0). */
  taxCategory?: TaxCategory;
  /** v5 F2: máximo de unidades por cliente (el servidor lo valida en la cotización). */
  maxPerCustomer?: number;
  /** v5 F2.9: peso por unidad en kg (de `weightKg` o `weight` + `weightUnit`). */
  weightKg?: number;
  weight?: number;
  weightUnit?: 'g' | 'kg' | 'lb' | (string & {});
  /** Medidas del paquete (cm) para transportadoras. */
  lengthCm?: number;
  widthCm?: number;
  heightCm?: number;
  /** v5 F2.11: producto digital (se entrega por descarga; sin envío). */
  isDigital: boolean;
  /** Catálogos (docs/REVIEWS-AND-CHANNELS.md §2). */
  brand?: string;
  gtin?: string;
  feedExclude?: boolean;
  /** Relación manual de relacionados (ids o slugs). */
  related?: string[] | string;
}

export interface DeliveryPayload {
  project: {
    id: string;
    name: string;
    slug: string;
    type?: string;
    framework?: string;
    productionUrl?: string;
    lastPublishedAt?: string | null;
    domains?: Array<{ domain: string; isPrimary?: boolean; status?: string }>;
  };
  global: Record<string, any>;
  seo: Record<string, any>;
  navigation: Navigation;
  ecommerce: {
    enabled: boolean;
    currency: string;
    freeShippingThreshold: number;
    flatShippingRate: number;
    /** v5 (docs/PRICING.md): formato de precios del proyecto (es-CO, es-MX…). */
    locale?: string;
    /** Pedido mínimo (0 = sin mínimo). */
    minOrderAmount?: number;
    /** true: los precios del catálogo ya incluyen impuestos. */
    taxIncludedInPrices?: boolean;
    [k: string]: any;
  };
  redirects?: Array<{ from: string; to: string; permanent?: boolean }>;
  pages: CmsPage[];
  /** Atajo a las secciones de la primera página. */
  sections?: Record<string, SectionData>;
  sectionsList?: SectionRow[];
  collections: Record<string, CollectionItem[]>;
  collectionDefinitions: Record<string, CollectionDefinition>;
  meta?: { mode: 'PUBLISHED' | 'PREVIEW_DRAFT' | string; generatedAt?: string };
}

/** Referencia a una sección lista para renderizar y editar. */
export interface CmsSectionRef<T extends SectionData = SectionData> {
  id: string;
  key: string;
  name?: string;
  block: string | null;
  isVisible: boolean;
  order: number;
  data: T;
}
