/**
 * Reseñas, lista de deseos, avisos de stock, productos relacionados, descargas digitales y vistos
 * recientemente para storefronts headless (docs/REVIEWS-AND-CHANNELS.md, v5 F2.3 / F2.11).
 *
 *   const extras = createStoreExtrasClient({ slug: 'demo', getToken: () => shop.getToken() });
 *   const page = await extras.reviews.list('crema-hidratante', { limit: 6 });
 *   await extras.reviews.submit({ productId, rating: 5, body: '…', name: 'Ana', email: 'ana@x.co' });
 *   await extras.backInStock.subscribe({ productId, email });
 *   extras.wishlist.toggleLocal(productId);           // sin cuenta (navegador)
 *   await extras.wishlist.add(productId);             // con cuenta (Bearer del cliente)
 *   extras.recentlyViewed.add(productId);
 *
 * Sin dependencias; funciona en el navegador, Node 18+ y Next.js (servidor o cliente).
 */
import { normalizeBaseUrl } from './delivery.js';
import type { CollectionItem } from './types.js';

export interface ReviewSummary {
  average: number;
  count: number;
  distribution: Record<'1' | '2' | '3' | '4' | '5', number>;
}

export interface PublicReview {
  id: string;
  productId: string;
  name: string;
  rating: number;
  title: string;
  body: string;
  photos: Array<{ url: string; alt: string }>;
  verifiedPurchase: boolean;
  /** Respuesta pública de la tienda ('' si no hay). */
  reply: string;
  repliedAt?: string | null;
  createdAt: string;
  product?: { id: string; title: string; slug: string } | null;
}

export interface ReviewsPage {
  enabled: boolean;
  product?: { id: string; slug: string; title: string } | null;
  items: PublicReview[];
  total: number;
  page: number;
  totalPages: number;
  summary: ReviewSummary;
}

export interface ReviewInput {
  /** Id o slug del producto (no hace falta con `token`). */
  productId?: string;
  rating: number;
  body: string;
  title?: string;
  name: string;
  /** Obligatorio sin `token` ni cuenta de cliente; nunca se publica. */
  email?: string;
  /** Ids devueltos por `reviews.uploadPhoto`. */
  photos?: string[];
  /** Enlace firmado del correo de solicitud (`?resena=`): marca la reseña como compra verificada. */
  token?: string;
  /** Trampa para bots: déjalo vacío (input oculto). */
  website?: string;
}

export interface ReviewSubmitResult {
  received: boolean;
  id?: string;
  status: 'PENDING' | 'APPROVED' | 'REJECTED';
  verifiedPurchase?: boolean;
  message: string;
}

export interface DigitalDownload {
  id: string;
  orderId: string;
  productId: string;
  title: string;
  downloads: number;
  maxDownloads: number;
  expiresAt: string;
  active: boolean;
  /** Enlace firmado nuevo (vence según la tienda); null si se agotaron las descargas o venció el acceso. */
  url: string | null;
}

export interface StoreExtrasStorage {
  getItem(key: string): string | null;
  setItem(key: string, value: string): void;
}

export interface StoreExtrasOptions {
  slug: string;
  /** URL del CMS (por defecto https://webproai.tech). */
  apiUrl?: string;
  fetch?: typeof fetch;
  /** Token del cliente de la tienda (createShopClient().getToken) para favoritos y descargas. */
  getToken?: () => string | null;
  /** Dónde guardar favoritos sin cuenta y vistos recientemente (por defecto localStorage o memoria). */
  storage?: StoreExtrasStorage | null;
}

export class StoreExtrasError extends Error {
  status: number;
  code: string;
  constructor(message: string, status: number, code: string) {
    super(message);
    this.name = 'StoreExtrasError';
    this.status = status;
    this.code = code;
  }
}

function memory(): StoreExtrasStorage {
  const m = new Map<string, string>();
  return { getItem: (k) => (m.has(k) ? (m.get(k) as string) : null), setItem: (k, v) => void m.set(k, String(v)) };
}

function defaultStorage(): StoreExtrasStorage {
  try {
    const ls = (globalThis as { localStorage?: StoreExtrasStorage }).localStorage;
    if (ls) return ls;
  } catch {
    // almacenamiento bloqueado
  }
  return memory();
}

function readList(storage: StoreExtrasStorage, key: string): string[] {
  try {
    const raw = JSON.parse(storage.getItem(key) || '[]');
    return Array.isArray(raw) ? raw.map(String).slice(0, 200) : [];
  } catch {
    return [];
  }
}

function writeList(storage: StoreExtrasStorage, key: string, list: string[]) {
  try {
    storage.setItem(key, JSON.stringify(list));
  } catch {
    // sin persistencia
  }
}

/** Claves de almacenamiento (las mismas del renderer de /site, para compartir favoritos). */
export const wishlistStorageKey = (slug: string) => `cms_wishlist_${slug}`;
export const recentlyViewedStorageKey = (slug: string) => `cms_recent_${slug}`;

export function createStoreExtrasClient(opts: StoreExtrasOptions) {
  if (!opts?.slug) throw new Error('createStoreExtrasClient requiere slug');
  const apiUrl = normalizeBaseUrl(opts.apiUrl);
  const fetchImpl = opts.fetch || (typeof fetch === 'function' ? fetch.bind(globalThis) : undefined);
  const storage = opts.storage === null ? memory() : opts.storage || defaultStorage();
  const base = `/api/shop/${encodeURIComponent(opts.slug)}`;
  const wishKey = wishlistStorageKey(opts.slug);
  const recentKey = recentlyViewedStorageKey(opts.slug);

  async function request<T>(method: string, path: string, init: { body?: unknown; form?: FormData; auth?: boolean } = {}): Promise<T> {
    if (!fetchImpl) throw new StoreExtrasError('No hay fetch disponible', 0, 'NO_FETCH');
    const headers: Record<string, string> = { Accept: 'application/json' };
    if (init.body !== undefined) headers['Content-Type'] = 'application/json';
    const token = init.auth ? opts.getToken?.() : null;
    if (init.auth && !token) throw new StoreExtrasError('Inicia sesión para continuar', 401, 'INVALID_TOKEN');
    if (token) headers.Authorization = `Bearer ${token}`;
    let res: Response;
    try {
      res = await fetchImpl(`${apiUrl}${path}`, { method, headers, body: init.form ? init.form : init.body === undefined ? undefined : JSON.stringify(init.body) });
    } catch {
      throw new StoreExtrasError('No se pudo conectar con la tienda', 0, 'NETWORK_ERROR');
    }
    const text = await res.text();
    let data: any;
    try {
      data = text ? JSON.parse(text) : undefined;
    } catch {
      data = { message: text };
    }
    if (!res.ok) {
      const msg = Array.isArray(data?.message) ? data.message.join('. ') : data?.message;
      throw new StoreExtrasError(typeof msg === 'string' && msg ? msg : 'Error de la tienda', res.status, typeof data?.code === 'string' ? data.code : `HTTP_${res.status}`);
    }
    return data as T;
  }

  return {
    slug: opts.slug,
    apiUrl,
    reviews: {
      /** Reseñas aprobadas de un producto (id o slug) o, sin producto, de toda la tienda. */
      list: (product?: string | null, q: { page?: number; limit?: number; sort?: 'highest' | 'lowest' | 'photos'; rating?: number } = {}) => {
        const qs = new URLSearchParams();
        if (product) qs.set('product', product);
        for (const [k, v] of Object.entries(q)) if (v !== undefined && v !== null && String(v) !== '') qs.set(k, String(v));
        return request<ReviewsPage>('GET', `${base}/reviews${qs.toString() ? `?${qs}` : ''}`);
      },
      /** Promedio y conteo de varios productos (tarjetas): `{ [idOSlug]: { average, count } }`. */
      summaries: (products: string[]) => request<Record<string, { average: number; count: number }>>('GET', `${base}/reviews/summary?products=${encodeURIComponent(products.join(','))}`),
      submit: (input: ReviewInput) => request<ReviewSubmitResult>('POST', `${base}/reviews`, { body: input }),
      uploadPhoto: (file: Blob, fileName = 'foto.jpg') => {
        const form = new FormData();
        form.append('file', file, fileName);
        return request<{ id: string; url: string }>('POST', `${base}/reviews/photos`, { form });
      },
      /** Datos del enlace del correo (`?resena=<token>`): producto y nombre para prellenar. */
      invite: (token: string) => request<{ product: { id: string; slug: string; title: string; imageUrl: string }; name: string; alreadyReviewed: boolean }>('GET', `${base}/reviews/invite/${encodeURIComponent(token)}`),
    },
    backInStock: {
      subscribe: (input: { productId: string; email: string; variant?: string; name?: string; website?: string }) =>
        request<{ subscribed: boolean; message?: string }>('POST', `${base}/back-in-stock`, { body: input, auth: false }),
    },
    wishlist: {
      /** Favoritos guardados en este navegador. */
      local: () => readList(storage, wishKey),
      setLocal: (ids: string[]) => writeList(storage, wishKey, Array.from(new Set(ids.map(String))).slice(0, 200)),
      /** Agrega o quita en este navegador; devuelve si quedó guardado. */
      toggleLocal(id: string): boolean {
        const cur = readList(storage, wishKey);
        const next = cur.includes(id) ? cur.filter((x) => x !== id) : [id, ...cur];
        writeList(storage, wishKey, next.slice(0, 200));
        return next.includes(id);
      },
      list: () => request<{ productIds: string[]; items: Array<{ productId: string; addedAt: string }> }>('GET', `${base}/wishlist`, { auth: true }),
      add: (productId: string) => request<{ productIds: string[] }>('PUT', `${base}/wishlist/${encodeURIComponent(productId)}`, { auth: true }),
      remove: (productId: string) => request<{ productIds: string[] }>('DELETE', `${base}/wishlist/${encodeURIComponent(productId)}`, { auth: true }),
      /** Sube los favoritos del navegador a la cuenta (al iniciar sesión). */
      merge: (productIds: string[]) => request<{ productIds: string[] }>('POST', `${base}/wishlist/merge`, { body: { productIds }, auth: true }),
    },
    downloads: {
      /** Descargas de la cuenta del cliente (enlaces firmados nuevos en cada llamada). */
      mine: () => request<{ items: DigitalDownload[] }>('GET', `${base}/downloads`, { auth: true }),
      /** Descargas de un pedido de invitado (número de pedido + correo de la compra). */
      forOrder: (orderNumber: string, email: string) => request<{ items: DigitalDownload[]; pendingPayment?: boolean }>('GET', `${base}/orders/${encodeURIComponent(orderNumber)}/downloads?email=${encodeURIComponent(email)}`),
    },
    recentlyViewed: {
      list: () => readList(storage, recentKey),
      /** Guarda el producto al frente (máx. `max`, 12 por defecto). */
      add(id: string, max = 12): string[] {
        const next = [String(id), ...readList(storage, recentKey).filter((x) => x !== String(id))].slice(0, Math.max(1, max));
        writeList(storage, recentKey, next);
        return next;
      },
      clear: () => writeList(storage, recentKey, []),
    },
  };
}

export type StoreExtrasClient = ReturnType<typeof createStoreExtrasClient>;

/**
 * Productos relacionados: primero los elegidos en el campo de relación del producto (`related`,
 * `relatedProducts` o `crossSell`: ids o slugs), luego los de la misma categoría y, solo si no hay
 * relación manual, el resto. Misma regla que el bloque `products.related`.
 */
export function relatedProducts<T extends Partial<CollectionItem> & Record<string, any>>(item: T | null | undefined, list: T[], count = 4): T[] {
  if (!item) return [];
  const others = list.filter((it) => it && it.id !== item.id);
  const raw = item.related ?? item.relatedProducts ?? item.crossSell;
  const ids = (Array.isArray(raw) ? raw : typeof raw === 'string' && raw ? raw.split(',') : []).map((s: unknown) => String(s).trim()).filter(Boolean);
  const manual = ids.map((id: string) => others.find((o) => o.id === id || o.slug === id)).filter(Boolean) as T[];
  const cat = String(item.category ?? '').trim();
  const same = cat ? others.filter((o) => String(o.category ?? '').trim() === cat && !manual.includes(o)) : [];
  const rest = others.filter((o) => !manual.includes(o) && !same.includes(o));
  return [...manual, ...same, ...(manual.length ? [] : rest)].slice(0, Math.max(0, count));
}

/** URLs de los catálogos de un sitio (`https://tienda.com` → /feeds/meta.xml y /feeds/google.xml). */
export function feedUrls(siteUrl: string): { meta: string; google: string } {
  const b = String(siteUrl || '').replace(/\/+$/, '');
  return { meta: `${b}/feeds/meta.xml`, google: `${b}/feeds/google.xml` };
}

/**
 * URLs de los catálogos servidos por el CMS (`GET /api/v1/feeds/:slug/meta.xml|google.xml`). Útil
 * para un storefront headless en otro dominio; `base` (un dominio del sitio) fija los enlaces.
 */
export function apiFeedUrls(slug: string, opts: { apiUrl?: string; base?: string } = {}): { meta: string; google: string } {
  const root = `${normalizeBaseUrl(opts.apiUrl)}/api/v1/feeds/${encodeURIComponent(slug)}`;
  const q = opts.base ? `?base=${encodeURIComponent(opts.base)}` : '';
  return { meta: `${root}/meta.xml${q}`, google: `${root}/google.xml${q}` };
}

/**
 * Enlace del correo de solicitud de reseña: `<producto>?resena=<token>&estrellas=N#resenas`.
 * Devuelve el token y las estrellas elegidas (1-5) para abrir el formulario prellenado.
 */
export function readReviewInvite(search?: string): { token: string; stars: number } | null {
  const q = search ?? (globalThis as any).location?.search ?? '';
  try {
    const p = new URLSearchParams(q);
    const token = p.get('resena');
    if (!token) return null;
    const stars = Math.round(Number(p.get('estrellas')) || 0);
    return { token, stars: stars >= 1 && stars <= 5 ? stars : 0 };
  } catch {
    return null;
  }
}

/** Calificación que el delivery entrega con cada producto (ratingAverage / ratingCount). */
export function productRating(item: Record<string, any> | null | undefined): { average: number; count: number } {
  const count = Number(item?.ratingCount) || 0;
  return { average: count ? Number(item?.ratingAverage) || 0 : 0, count };
}
