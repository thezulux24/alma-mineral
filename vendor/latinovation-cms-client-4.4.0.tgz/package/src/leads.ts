/**
 * Formularios y leads para sitios headless (`POST /api/public/leads/:slug`, el mismo endpoint de los
 * bloques `form.custom`, contacto y compositor del renderer).
 *
 *   const r = await submitLead({ slug: 'demo', formId: 'cotizacion', payload: { nombre: 'Ana', email: 'ana@x.co' } });
 *
 * Con `formId` el servidor usa la definición PUBLICADA del formulario (campos obligatorios, avisos);
 * sin él, exige nombre y correo o teléfono. Emite `generate_lead` (docs/TRACKING.md) con el mismo
 * event_id que el Lead de la API de conversiones de Meta. `website` es la trampa para bots.
 */
import { normalizeBaseUrl } from './delivery.js';
import { track, trackingContext, type TrackingContext } from './tracking/core.js';

export interface LeadInput {
  slug: string;
  apiUrl?: string;
  fetch?: typeof fetch;
  /** Id del formulario `form.custom` publicado (p. ej. `cotizacion`). */
  formId?: string;
  /** Nombre legible del formulario (por defecto el formId o «Contacto General»). */
  formName?: string;
  /** Respuestas por clave de campo del formulario. */
  payload?: Record<string, unknown>;
  fullName?: string;
  email?: string;
  phone?: string;
  message?: string;
  /** Ruta y sección de origen (para el portal). Por defecto la ruta actual. */
  sourcePage?: string;
  sourceSection?: string;
  /** Datos extra (UTM, producto…). */
  metadata?: Record<string, unknown>;
  /** Trampa para bots: déjalo vacío (input oculto). */
  website?: string;
  /** false: no emite `generate_lead` ni adjunta el contexto de medición. */
  tracking?: boolean | TrackingContext;
}

export interface LeadResult {
  received: boolean;
  leadId: string | null;
  createdAt: string;
  /** event_id del `generate_lead` (deduplicación con Meta). */
  eventId?: string;
  [k: string]: unknown;
}

export class LeadError extends Error {
  status: number;
  constructor(message: string, status: number) {
    super(message);
    this.name = 'LeadError';
    this.status = status;
  }
}

export async function submitLead(input: LeadInput): Promise<LeadResult> {
  if (!input?.slug) throw new Error('submitLead requiere slug');
  const fetchImpl = input.fetch || (typeof fetch === 'function' ? fetch.bind(globalThis) : undefined);
  if (!fetchImpl) throw new LeadError('No hay fetch disponible', 0);
  const { slug, apiUrl, fetch: _f, tracking, ...rest } = input;
  void _f;
  let eventId: string | undefined;
  let ctx: TrackingContext | undefined;
  if (tracking !== false) {
    if (tracking && typeof tracking === 'object') ctx = tracking;
    else {
      eventId = track('generate_lead', { form_id: input.formId || input.formName || 'contacto' });
      ctx = trackingContext(eventId);
    }
  }
  const sourcePage = rest.sourcePage ?? ((globalThis as any).location?.pathname || undefined);
  const body = { ...rest, ...(sourcePage ? { sourcePage } : {}), ...(ctx ? { tracking: ctx } : {}) };
  let res: Response;
  try {
    res = await fetchImpl(`${normalizeBaseUrl(apiUrl)}/api/public/leads/${encodeURIComponent(slug)}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
      body: JSON.stringify(body),
    });
  } catch {
    throw new LeadError('No pudimos enviar el formulario. Revisa tu conexión e inténtalo de nuevo.', 0);
  }
  const text = await res.text();
  let data: any = {};
  try {
    data = text ? JSON.parse(text) : {};
  } catch {
    data = { message: text };
  }
  if (!res.ok) {
    const m = Array.isArray(data?.message) ? data.message.join('. ') : data?.message;
    throw new LeadError(typeof m === 'string' && m ? m : `Error ${res.status}`, res.status);
  }
  return { ...data, ...(eventId ? { eventId } : {}) } as LeadResult;
}
