import type { ElementStyle, SectionData, SectionStyle } from './types.js';

/**
 * CSS por sección a partir de `data._style` (§8.3), `data._elementStyles` (estilos por elemento
 * `[data-el-id]`) y `data._customCss` (saneado y acotado a la sección).
 * Mismo resultado visual que `buildSectionElementCss` del renderer del CMS para las claves genéricas.
 */

export interface SectionCssInput {
  key: string;
  data?: SectionData | null;
}

export interface SectionCssOptions {
  /** Modo editor: las secciones ocultas por dispositivo se ven atenuadas en vez de desaparecer. */
  isBuilder?: boolean;
  /** Selector raíz (por defecto `[data-section-key="<key>"]`). */
  selector?: string;
  /** Punto de corte móvil/escritorio en px (por defecto 768). */
  breakpoint?: number;
}

export const CONTENT_WIDTHS: Record<string, string> = {
  narrow: '720px',
  standard: '1120px',
  wide: '1360px',
  full: 'none',
};

/** Escapa un valor para usarlo dentro de `[attr="…"]`. */
export function cssAttr(v: string): string {
  return String(v).replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/[\n\r]/g, ' ');
}

export function sectionSelector(key: string): string {
  return `[data-section-key="${cssAttr(key)}"]`;
}

const BAD_VALUE = /expression\s*\(|javascript\s*:|vbscript\s*:|-moz-binding|behavior\s*:|@import|<\/?style|<\/?script/i;

/** Valor de propiedad seguro: sin llaves, `;`, `<`, `>` ni construcciones peligrosas. '' si no es usable. */
export function cssValue(v: unknown): string {
  if (v === null || v === undefined) return '';
  const s = String(v).replace(/[{}<>;]/g, '').replace(/[\n\r]+/g, ' ').trim();
  if (!s || BAD_VALUE.test(s)) return '';
  return s;
}

/** Número → `px`; cadena con unidad se respeta. */
export function cssLength(v: unknown): string {
  if (v === null || v === undefined || v === '') return '';
  if (typeof v === 'number') return Number.isFinite(v) ? `${v}px` : '';
  const s = String(v).trim();
  if (/^-?\d+(\.\d+)?$/.test(s)) return `${s}px`;
  return cssValue(s);
}

export function cssUrl(url: unknown): string {
  const s = String(url ?? '').trim();
  if (!s || /^(javascript|vbscript|data:text\/html)/i.test(s)) return '';
  return `url("${s.replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/[\n\r]/g, '')}")`;
}

function fontFamily(v: unknown): string {
  const s = cssValue(v);
  if (!s) return '';
  if (/[,"']/.test(s)) return s;
  return /\s/.test(s) ? `"${s}"` : s;
}

/**
 * Sanea CSS libre: quita comentarios, `@import`, `expression()`, `javascript:`, `-moz-binding`,
 * `behavior:` y cualquier `<…>` que pudiera cerrar la etiqueta `<style>`.
 */
export function sanitizeCss(css: unknown): string {
  if (typeof css !== 'string' || !css.trim()) return '';
  return css
    .replace(/\/\*[\s\S]*?\*\//g, '')
    .replace(/<script\b[\s\S]*?(<\/script\s*>|$)/gi, '')
    .replace(/<\/?\s*(style|script)[^>]*>/gi, '')
    .replace(/[<>]/g, (c, i, all) => (isSelectorCombinator(all, i) ? c : ''))
    .replace(/@import[^;]*;?/gi, '')
    .replace(/@charset[^;]*;?/gi, '')
    .replace(/expression\s*\([^)]*\)/gi, '')
    .replace(/(javascript|vbscript)\s*:/gi, '')
    .replace(/-moz-binding\s*:[^;}]*/gi, '')
    .replace(/behavior\s*:[^;}]*/gi, '')
    .replace(/url\(\s*(['"]?)\s*data:text\/html[^)]*\)/gi, 'none')
    .trim();
}

// `>` como combinador hijo es válido en selectores (`.a > .b`); `<` nunca lo es.
function isSelectorCombinator(all: string, i: number): boolean {
  if (all[i] !== '>') return false;
  // Dentro de un bloque de declaraciones no hay `>` legítimo: si el último `{` está más cerca que el último `}`, descartar.
  const lastOpen = all.lastIndexOf('{', i);
  const lastClose = all.lastIndexOf('}', i);
  return lastOpen <= lastClose;
}

function splitTopLevel(s: string, sep: string): string[] {
  const out: string[] = [];
  let depth = 0;
  let quote = '';
  let cur = '';
  for (const ch of s) {
    if (quote) {
      cur += ch;
      if (ch === quote) quote = '';
      continue;
    }
    if (ch === '"' || ch === "'") quote = ch;
    else if (ch === '(' || ch === '[') depth++;
    else if (ch === ')' || ch === ']') depth--;
    if (ch === sep && depth === 0) {
      out.push(cur);
      cur = '';
    } else cur += ch;
  }
  out.push(cur);
  return out;
}

function scopeSelector(sel: string, scope: string): string {
  const s = sel.trim();
  if (!s) return '';
  if (s.includes('[data-section-key=')) return s; // ya acotado (CSS escrito para el renderer del CMS)
  if (s.includes('&')) return s.replace(/&/g, scope);
  if (/:scope\b/.test(s)) return s.replace(/:scope\b/g, scope);
  if (/^(:root|html|body)\b/.test(s)) return s.replace(/^(:root|html|body)\b\s*/, `${scope} `).trim();
  return `${scope} ${s}`;
}

const PASSTHROUGH_AT = /^@(-[a-z]+-)?(keyframes|font-face|page|property|counter-style|font-feature-values)\b/i;
const NESTING_AT = /^@(media|supports|container|layer|document)\b/i;

/**
 * Acota CSS a `scope`: cada selector queda bajo la sección (`&`/`:scope`/`:root` = la sección misma);
 * declaraciones sueltas (`color: red;`) se aplican a la sección. `@media`/`@supports` se recorren.
 */
export function scopeCss(css: string, scope: string): string {
  const src = sanitizeCss(css);
  if (!src) return '';
  const out: string[] = [];
  const bare: string[] = [];
  let i = 0;
  while (i < src.length) {
    // siguiente `{` o `;` de nivel superior
    let j = i;
    let quote = '';
    let paren = 0;
    while (j < src.length) {
      const ch = src[j];
      if (quote) {
        if (ch === quote) quote = '';
      } else if (ch === '"' || ch === "'") quote = ch;
      else if (ch === '(') paren++;
      else if (ch === ')') paren--;
      else if (paren <= 0 && (ch === '{' || ch === ';' || ch === '}')) break;
      j++;
    }
    const prelude = src.slice(i, j).trim();
    if (j >= src.length) {
      if (prelude) bare.push(prelude);
      break;
    }
    if (src[j] === ';' || src[j] === '}') {
      if (prelude && src[j] === ';') bare.push(prelude);
      i = j + 1;
      continue;
    }
    // bloque: buscar la llave de cierre correspondiente
    let depth = 1;
    let k = j + 1;
    quote = '';
    while (k < src.length && depth > 0) {
      const ch = src[k];
      if (quote) {
        if (ch === quote) quote = '';
      } else if (ch === '"' || ch === "'") quote = ch;
      else if (ch === '{') depth++;
      else if (ch === '}') depth--;
      k++;
    }
    const body = src.slice(j + 1, depth === 0 ? k - 1 : k);
    i = k;
    if (!prelude) continue;
    if (prelude.startsWith('@')) {
      if (PASSTHROUGH_AT.test(prelude)) out.push(`${prelude}{${body}}`);
      else if (NESTING_AT.test(prelude)) {
        const inner = scopeCss(body, scope);
        if (inner) out.push(`${prelude}{${inner}}`);
      }
      continue;
    }
    const selectors = splitTopLevel(prelude, ',').map((s) => scopeSelector(s, scope)).filter(Boolean);
    if (selectors.length) out.push(`${selectors.join(', ')}{${body.trim()}}`);
  }
  if (bare.length) out.unshift(`${scope}{${bare.map((d) => d.trim()).filter(Boolean).join(';')}}`);
  return out.join('\n');
}

function num(v: unknown): number | undefined {
  if (v === null || v === undefined || v === '') return undefined;
  const n = Number(v);
  return Number.isFinite(n) ? n : undefined;
}

/** Reglas de `_style` (§8.3) para la sección. */
export function buildSectionStyleCss(key: string, style: SectionStyle | undefined | null, opts: SectionCssOptions = {}): string {
  if (!style || typeof style !== 'object') return '';
  const sel = opts.selector || sectionSelector(key);
  const bp = opts.breakpoint || 768;
  const rules: string[] = [];
  const props: string[] = [];
  const vars: string[] = [];

  const bg = cssValue(style.backgroundColor);
  if (bg) props.push(`background-color:${bg} !important`);
  const fg = cssValue(style.textColor);
  if (fg) {
    props.push(`color:${fg} !important`);
    rules.push(`${sel} :is(h1,h2,h3,h4,h5,h6,p,li,blockquote){color:${fg} !important}`);
  }
  const accent = cssValue(style.accentColor);
  if (accent) vars.push(`--cms-accent:${accent}`);
  const img = cssUrl(style.backgroundImage);
  if (img) {
    const o = num(style.overlayOpacity);
    const shade = o && o > 0 ? Math.min(90, Math.max(0, o)) / 100 : 0;
    const layers = shade ? `linear-gradient(rgba(0,0,0,${shade}),rgba(0,0,0,${shade})),${img}` : img;
    props.push(`background-image:${layers} !important`, 'background-size:cover !important', 'background-position:center !important');
  }
  const pt = cssLength(style.paddingTop);
  if (pt) props.push(`padding-top:${pt} !important`);
  const pb = cssLength(style.paddingBottom);
  if (pb) props.push(`padding-bottom:${pb} !important`);
  const radius = cssLength(style.borderRadius);
  if (radius) props.push(`border-radius:${radius}`, 'overflow:hidden');
  const font = fontFamily(style.fontFamily);
  if (font) {
    props.push(`font-family:${font}`);
    rules.push(`${sel} :is(h1,h2,h3,h4,h5,h6){font-family:${font}}`);
  }
  const align = String(style.textAlign || '').toLowerCase();
  if (align === 'left' || align === 'center' || align === 'right') {
    props.push(`text-align:${align}`);
    const margins = align === 'center' ? 'margin-left:auto;margin-right:auto' : align === 'right' ? 'margin-left:auto;margin-right:0' : '';
    rules.push(`${sel} :is(h1,h2,h3,h4,h5,h6,p){text-align:${align} !important${margins ? `;${margins}` : ''}}`);
  }
  const minH = String(style.minHeight || '').toLowerCase();
  if (minH === 'screen') props.push('min-height:100vh', 'min-height:100svh');
  else if (minH === 'half') props.push('min-height:50vh', 'min-height:50svh');
  else if (minH && minH !== 'auto') {
    const v = cssLength(style.minHeight);
    if (v) props.push(`min-height:${v}`);
  }
  const width = CONTENT_WIDTHS[String(style.contentWidth || '').toLowerCase()] || cssLength(style.maxWidth);
  if (width) {
    vars.push(`--cms-content-width:${width}`);
    rules.push(`${sel} [data-cms-container]{max-width:var(--cms-content-width) !important;margin-left:auto;margin-right:auto}`);
  }
  const all = [...vars, ...props];
  if (all.length) rules.unshift(`${sel}{${all.join(';')}}`);

  const hiddenRule = opts.isBuilder ? `${sel}{opacity:.38 !important;outline:2px dashed var(--cms-ui-muted,#94a3b8);outline-offset:-2px}` : `${sel}{display:none !important}`;
  if (style.hideOnMobile === true || (style.hideOnMobile as unknown) === 'true') rules.push(`@media (max-width:${bp - 0.02}px){${hiddenRule}}`);
  if (style.hideOnDesktop === true || (style.hideOnDesktop as unknown) === 'true') rules.push(`@media (min-width:${bp}px){${hiddenRule}}`);
  return rules.join('\n');
}

const POSITION: Record<string, { self: string; abs: string }> = {
  'top-left': {
    self: 'align-self:flex-start !important;margin-right:auto !important;margin-left:0 !important;margin-bottom:auto !important;margin-top:0 !important',
    abs: 'top:1.5rem !important;left:1.5rem !important;bottom:auto !important;right:auto !important',
  },
  'top-right': {
    self: 'align-self:flex-end !important;margin-left:auto !important;margin-right:0 !important;margin-bottom:auto !important;margin-top:0 !important',
    abs: 'top:1.5rem !important;right:1.5rem !important;bottom:auto !important;left:auto !important',
  },
  center: {
    self: 'align-self:center !important;margin:auto !important;text-align:center !important',
    abs: 'top:50% !important;left:50% !important;bottom:auto !important;right:auto !important;transform:translate(-50%,-50%) !important',
  },
  'bottom-left': {
    self: 'align-self:flex-start !important;margin-right:auto !important;margin-left:0 !important;margin-top:auto !important;margin-bottom:0 !important',
    abs: 'bottom:1.5rem !important;left:1.5rem !important;top:auto !important;right:auto !important',
  },
  'bottom-right': {
    self: 'align-self:flex-end !important;margin-left:auto !important;margin-right:0 !important;margin-top:auto !important;margin-bottom:0 !important',
    abs: 'bottom:1.5rem !important;right:1.5rem !important;top:auto !important;left:auto !important',
  },
};

/** Declaraciones sueltas saneadas (`color:red; padding: 4px`). */
function sanitizeDeclarations(css: unknown): string {
  const s = sanitizeCss(String(css ?? '')).replace(/[{}]/g, '');
  return s
    .split(';')
    .map((d) => d.trim())
    .filter((d) => /^-{0,2}[a-z][\w-]*\s*:/.test(d))
    .join(';');
}

/** Hermanos que cuentan para el índice de `tagSectionElements` (dom.ts): sin chrome del editor ni <style>/<script>. */
const COUNTED_SIBLINGS = ':not(style,script,template,noscript,.cms-ui,.cms-builder-ui)';
const AUTO_PATH = /^[a-z][a-z0-9-]*\.\d+(?:>[a-z][a-z0-9-]*\.\d+)*$/;

/**
 * Selector estructural para un id automático (`<sección>::div.0>h2.1`). El atributo `data-el-id`
 * de esos elementos lo pone JavaScript al hidratar; sin este selector el estilo llegaba tarde y el
 * visitante veía primero el diseño original y luego el salto. `:nth-child(n of S)` cuenta los
 * mismos hermanos que `tagSectionElements`.
 */
export function autoElementSelector(secSel: string, key: string, elId: string): string | null {
  const prefix = `${key}::`;
  if (!elId.startsWith(prefix)) return null;
  const path = elId.slice(prefix.length);
  if (!AUTO_PATH.test(path)) return null;
  const steps = path.split('>').map((seg) => {
    const dot = seg.lastIndexOf('.');
    return `${seg.slice(0, dot)}:nth-child(${Number(seg.slice(dot + 1)) + 1} of ${COUNTED_SIBLINGS})`;
  });
  return `${secSel} > ${steps.join(' > ')}`;
}

/** Reglas de `_elementStyles` (por `[data-el-id]` y, para ids automáticos, también por posición). */
export function buildElementStylesCss(key: string, elementStyles: Record<string, ElementStyle> | undefined | null, opts: SectionCssOptions = {}): string {
  if (!elementStyles || typeof elementStyles !== 'object') return '';
  const secSel = opts.selector || sectionSelector(key);
  const rules: string[] = [];
  for (const [elId, st] of Object.entries(elementStyles)) {
    if (!st || typeof st !== 'object') continue;
    // Reglas separadas, no una lista de selectores: un navegador sin `:nth-child(of)` descartaría la lista entera.
    const selectors = [`${secSel} [data-el-id="${cssAttr(elId)}"]`];
    const structural = autoElementSelector(secSel, key, elId);
    if (structural) selectors.push(structural);
    for (const sel of selectors) rules.push(...elementRules(sel, st));
  }
  return rules.join('\n');
}

function elementRules(sel: string, st: ElementStyle): string[] {
  const rules: string[] = [];
  {
    const props: string[] = [];
    const bg = cssValue(st.backgroundColor);
    if (bg) props.push(`background-color:${bg} !important`);
    const fg = cssValue(st.textColor);
    if (fg) props.push(`color:${fg} !important`);
    const pos = st.positionPreset ? POSITION[String(st.positionPreset)] : undefined;
    if (pos) {
      props.push(pos.self);
      rules.push(`${sel}.absolute, ${sel}[data-cms-absolute]{${pos.abs}}`);
    }
    const ox = num(st.offsetX) || 0;
    const oy = num(st.offsetY) || 0;
    const sc = num(st.scale) ?? 1;
    if (ox !== 0 || oy !== 0 || sc !== 1) props.push(`transform:translate3d(${ox}px,${oy}px,0)${sc !== 1 ? ` scale(${sc})` : ''} !important`);
    const map: Array<[keyof ElementStyle, string]> = [
      ['width', 'width'],
      ['maxWidth', 'max-width'],
      ['padding', 'padding'],
      ['borderRadius', 'border-radius'],
      ['fontSize', 'font-size'],
      ['border', 'border'],
      ['boxShadow', 'box-shadow'],
    ];
    for (const [k, prop] of map) {
      const v = k === 'width' || k === 'maxWidth' || k === 'borderRadius' || k === 'fontSize' ? cssLength(st[k]) : cssValue(st[k]);
      if (v) props.push(`${prop}:${v} !important`);
    }
    const blur = cssLength(st.backdropBlur);
    if (blur) props.push(`backdrop-filter:blur(${blur}) !important`, `-webkit-backdrop-filter:blur(${blur}) !important`);
    if (st.opacity !== undefined && st.opacity !== '' && num(st.opacity) !== undefined) props.push(`opacity:${num(st.opacity)} !important`);
    if (st.zIndex !== undefined && st.zIndex !== '' && num(st.zIndex) !== undefined) props.push(`z-index:${Math.round(num(st.zIndex)!)} !important`);
    if (st.hidden === true) props.push('display:none !important');
    const custom = sanitizeDeclarations(st.customCss);
    if (custom) props.push(custom);
    if (props.length) rules.push(`${sel}{${props.join(';')}}`);
    if (fg) rules.push(`${sel} :is(p,span,h1,h2,h3,h4,h5,h6,div,a,li){color:${fg} !important}`);
  }
  return rules;
}

/**
 * CSS completo de una sección: `_style` + `_elementStyles` + `_customCss` acotado.
 * Devuelve '' si no hay nada que aplicar (no hace falta emitir `<style>`).
 */
export function buildSectionCss(section: SectionCssInput, opts: SectionCssOptions = {}): string {
  const data = (section?.data || {}) as SectionData;
  const sel = opts.selector || sectionSelector(section.key);
  const parts = [
    buildSectionStyleCss(section.key, data._style, { ...opts, selector: sel }),
    buildElementStylesCss(section.key, data._elementStyles, { ...opts, selector: sel }),
    typeof data._customCss === 'string' ? scopeCss(data._customCss, sel) : '',
  ];
  return parts.filter(Boolean).join('\n');
}

/** CSS de varias secciones (p. ej. para emitir un único `<style>` en el servidor). */
export function buildSectionsCss(sections: SectionCssInput[], opts: SectionCssOptions = {}): string {
  return sections.map((s) => buildSectionCss(s, opts)).filter(Boolean).join('\n');
}

/** Ancla de la sección: `_style.anchorId` o el campo `anchor` del catálogo (sin `#`). */
export function sectionAnchor(data: SectionData | undefined | null): string {
  const raw = String(data?._style?.anchorId || data?.anchor || '').trim().replace(/^#/, '');
  return raw.replace(/[^\w-]/g, '-').replace(/^-+|-+$/g, '');
}

/** true si `_style.hideOnMobile`/`hideOnDesktop` ocultan la sección en ambos tamaños. */
export function sectionHiddenEverywhere(data: SectionData | undefined | null): boolean {
  const st = data?._style;
  return Boolean(st && st.hideOnMobile === true && st.hideOnDesktop === true);
}
